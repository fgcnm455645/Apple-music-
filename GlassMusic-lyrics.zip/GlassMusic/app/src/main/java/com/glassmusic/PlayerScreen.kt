package com.glassmusic

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Choreographer
import android.provider.Settings
import android.text.TextUtils
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.core.graphics.ColorUtils
import androidx.media3.common.C
import androidx.media3.common.Player
import kotlin.math.roundToInt

/** Full-screen Now Playing, laid out from measurements of Apple Music's player. Slides up over everything. */
class PlayerScreen(private val act: MainActivity) {
    val view = FrameLayout(act)
    var isOpen = false
        private set

    private val bg = CoverBackgroundView(act)
    private val fullMask = FadeMaskLayout(act)
    private val fullCover = ImageView(act)
    private val shade = View(act)
    private val content = LinearLayout(act)
    private val dragZone = View(act)
    private val handle = View(act)
    private val coverHolder = FrameLayout(act)
    private val info = LinearLayout(act)
    private val controls = LinearLayout(act)

    // lyrics
    private val lyrics = LyricsView(act)
    private val lyricHeader = LinearLayout(act)
    private val miniCover = SquareImageView(act)
    private val lTitle = TextView(act)
    private val lArtist = TextView(act)
    private val lMoreBox = FrameLayout(act)
    private val lMoreIcon = ImageView(act)
    private val lyricsHl = View(act)
    private var lyricsOn = false
    private var lyricsSongId = -1L
    private var lyricsReady = false
    private var lyricsSkip = 0
    private var lyricsToken = 0
    private var lastPos = 0L
    private var lastPosAt = 0L

    private val cover = SquareImageView(act)
    private val title = TextView(act)
    private val artist = TextView(act)
    private val star = ImageView(act)
    private val starBox = FrameLayout(act)
    private val moreBox = FrameLayout(act)
    private val moreIcon = ImageView(act)
    private val seek = GlassSeekBar(act)
    private val elapsed = TextView(act)
    private val remaining = TextView(act)
    private val prev = ImageView(act)
    private val play = ImageView(act)
    private val next = ImageView(act)
    private val volume = GlassSeekBar(act)
    private val volLow = ImageView(act)
    private val volHigh = ImageView(act)
    private val lyricsBtn = ImageView(act)
    private val airBtn = ImageView(act)
    private val queueBtn = ImageView(act)

    private val handler = Handler(Looper.getMainLooper())
    private val audio = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var shownSongId = -1L
    private var coverSize = 0

    private val tick = object : Runnable {
        override fun run() {
            if (!isOpen) return
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isOpen || !lyricsOn) return
            lyrics.onPosition(smoothPosition())
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    /** Player position with a little extrapolation so the highlight moves every frame, not every few ms-updates. */
    private fun smoothPosition(): Long {
        val c = Playback.controller ?: return 0L
        val p = c.currentPosition
        val now = SystemClock.elapsedRealtime()
        if (p != lastPos) {
            lastPos = p
            lastPosAt = now
        }
        val d = now - lastPosAt
        return if (c.isPlaying && d in 1L..1000L) p + d else p
    }

    private fun fmtTime(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(s / 60, s % 60)
    }

    private fun cell(img: ImageView, iconRes: Int, sizeDp: Int, onClick: () -> Unit): FrameLayout {
        img.setImageResource(iconRes)
        val c = FrameLayout(act)
        c.addView(img, FrameLayout.LayoutParams(act.dp(sizeDp), act.dp(sizeDp), Gravity.CENTER))
        c.setOnClickListener { onClick() }
        return c
    }

    private fun circleCell(box: FrameLayout, img: ImageView, iconRes: Int, glyphDp: Int, onClick: () -> Unit) {
        img.setImageResource(iconRes)
        box.addView(img, FrameLayout.LayoutParams(act.dp(glyphDp), act.dp(glyphDp), Gravity.CENTER))
        box.setOnClickListener { onClick() }
    }

    init {
        val screenW = act.resources.displayMetrics.widthPixels
        // Apple Music: the cover spans 88% of the width
        coverSize = (screenW * 0.882f).toInt()

        view.addView(bg, FrameLayout.LayoutParams(-1, -1))

        // "Cover Full Screen" style: big sharp cover that fades into the blurred cover behind it
        val big = (screenW * 1.63f).toInt()
        fullCover.scaleType = ImageView.ScaleType.CENTER_CROP
        fullMask.invert = true
        fullMask.fadeStart = 0.49f
        fullMask.fadeEnd = 0.78f
        fullMask.addView(fullCover, FrameLayout.LayoutParams(big, big, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = act.dp(11)
        })
        view.addView(fullMask, FrameLayout.LayoutParams(-1, -1))
        shade.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x00000000, 0x00000000, 0x77000000)
        )
        view.addView(shade, FrameLayout.LayoutParams(-1, -1))
        fullMask.visibility = View.GONE
        shade.visibility = View.GONE

        content.orientation = LinearLayout.VERTICAL
        content.gravity = Gravity.CENTER_HORIZONTAL
        view.addView(content, FrameLayout.LayoutParams(-1, -1))

        // drag handle (Apple: small, 37dp wide)
        content.addView(handle, LinearLayout.LayoutParams(act.dp(37), act.dp(5)).apply { topMargin = act.dp(63) })

        // cover
        cover.round(act.dp(8).toFloat())
        cover.elevation = act.dp(20).toFloat()
        coverHolder.clipChildren = false
        coverHolder.addView(cover, FrameLayout.LayoutParams(-1, -1))
        content.addView(coverHolder, LinearLayout.LayoutParams(coverSize, coverSize).apply { topMargin = act.dp(28) })

        // title / artist + star + more
        title.tsz(22f)
        title.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        artist.tsz(20f)
        artist.maxLines = 1
        artist.ellipsize = TextUtils.TruncateAt.END
        val texts = LinearLayout(act)
        texts.orientation = LinearLayout.VERTICAL
        texts.addView(title)
        texts.addView(artist)

        circleCell(starBox, star, R.drawable.ic_cu_star, 15) {
            val s = act.currentSong()
            if (s != null) {
                Prefs.toggleFavorite(s.id)
                updateStar()
                act.refreshHome()
            }
        }
        circleCell(moreBox, moreIcon, R.drawable.ic_cu_ellipsis, 14) { showMoreMenu() }

        info.orientation = LinearLayout.HORIZONTAL
        info.gravity = Gravity.CENTER_VERTICAL
        info.addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = act.dp(8) })
        info.addView(starBox, LinearLayout.LayoutParams(act.dp(28), act.dp(28)).apply { marginEnd = act.dp(19) })
        info.addView(moreBox, LinearLayout.LayoutParams(act.dp(28), act.dp(28)))
        content.addView(info, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = act.dp(60)
            marginStart = act.dp(32)
            marginEnd = act.dp(34)
        })

        // lyrics mode: small cover + title/artist + more, then the lyrics themselves
        miniCover.round(act.dp(8).toFloat())
        lTitle.tsz(20f)
        lTitle.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        lTitle.maxLines = 1
        lTitle.ellipsize = TextUtils.TruncateAt.END
        lArtist.tsz(18f)
        lArtist.maxLines = 1
        lArtist.ellipsize = TextUtils.TruncateAt.END
        val lTexts = LinearLayout(act)
        lTexts.orientation = LinearLayout.VERTICAL
        lTexts.addView(lTitle)
        lTexts.addView(lArtist)
        circleCell(lMoreBox, lMoreIcon, R.drawable.ic_cu_ellipsis, 14) { showMoreMenu() }
        lyricHeader.orientation = LinearLayout.HORIZONTAL
        lyricHeader.gravity = Gravity.CENTER_VERTICAL
        lyricHeader.addView(miniCover, LinearLayout.LayoutParams(act.dp(56), act.dp(56)))
        lyricHeader.addView(lTexts, LinearLayout.LayoutParams(0, -2, 1f).apply {
            marginStart = act.dp(14)
            marginEnd = act.dp(8)
        })
        lyricHeader.addView(lMoreBox, LinearLayout.LayoutParams(act.dp(28), act.dp(28)))
        lyricHeader.visibility = View.GONE
        content.addView(lyricHeader, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = act.dp(16)
            marginStart = act.dp(32)
            marginEnd = act.dp(34)
        })
        lyrics.visibility = View.GONE
        lyrics.onSeek = { ms ->
            Playback.controller?.seekTo(ms)
            lastPos = -1L
            lyrics.onPosition(ms)
        }
        content.addView(lyrics, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = act.dp(6) })

        // progress
        seek.thicknessDp = 7
        seek.onChange = { f ->
            val d = Playback.controller?.duration ?: C.TIME_UNSET
            if (d > 0) {
                elapsed.text = fmtTime((f * d).toLong())
                remaining.text = "-" + fmtTime(d - (f * d).toLong())
            }
        }
        seek.onRelease = { f ->
            val c = Playback.controller
            val d = c?.duration ?: C.TIME_UNSET
            if (c != null && d > 0) c.seekTo((f * d).toLong())
        }
        content.addView(seek, LinearLayout.LayoutParams(-1, act.dp(24)).apply {
            topMargin = act.dp(9)
            marginStart = act.dp(32)
            marginEnd = act.dp(33)
        })
        elapsed.tsz(13f)
        remaining.tsz(13f)
        remaining.gravity = Gravity.END
        val times = LinearLayout(act)
        times.orientation = LinearLayout.HORIZONTAL
        times.addView(elapsed, LinearLayout.LayoutParams(0, -2, 1f))
        times.addView(remaining, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(times, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = act.dp(1)
            marginStart = act.dp(32)
            marginEnd = act.dp(33)
        })

        // transport: centers at 92 / 205 / 318 dp like Apple Music
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER
        controls.addView(cell(prev, R.drawable.ic_cu_rewind, 42) { Playback.controller?.seekToPrevious() },
            LinearLayout.LayoutParams(0, act.dp(90), 1f))
        controls.addView(cell(play, R.drawable.ic_cu_play, 40) {
            val c = Playback.controller
            if (c != null) {
                if (c.isPlaying) c.pause() else c.play()
            }
        }, LinearLayout.LayoutParams(0, act.dp(90), 1f))
        controls.addView(cell(next, R.drawable.ic_cu_forward, 42) { Playback.controller?.seekToNext() },
            LinearLayout.LayoutParams(0, act.dp(90), 1f))
        content.addView(controls, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            marginStart = act.dp(36)
            marginEnd = act.dp(36)
        })

        // volume
        volLow.setImageResource(R.drawable.ic_cu_spk_low)
        volHigh.setImageResource(R.drawable.ic_cu_spk_high)
        volume.thicknessDp = 7
        volume.onChange = { f ->
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (f * max).roundToInt(), 0)
        }
        val volRow = LinearLayout(act)
        volRow.orientation = LinearLayout.HORIZONTAL
        volRow.gravity = Gravity.CENTER_VERTICAL
        volRow.addView(volLow, LinearLayout.LayoutParams(act.dp(13), act.dp(13)))
        volRow.addView(volume, LinearLayout.LayoutParams(0, act.dp(24), 1f).apply {
            marginStart = act.dp(16)
            marginEnd = act.dp(10)
        })
        volRow.addView(volHigh, LinearLayout.LayoutParams(act.dp(22), act.dp(22)))
        content.addView(volRow, LinearLayout.LayoutParams(-1, -2).apply {
            marginStart = act.dp(37)
            marginEnd = act.dp(35)
            bottomMargin = act.dp(8)
        })

        // bottom icons: lyrics, output, queue
        val bottom = LinearLayout(act)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER
        val lyricsCell = cell(lyricsBtn, R.drawable.ic_cu_quote, 24) { setLyricsMode(!lyricsOn) }
        lyricsCell.addView(lyricsHl, 0, FrameLayout.LayoutParams(act.dp(46), act.dp(38), Gravity.CENTER))
        lyricsHl.visibility = View.GONE
        bottom.addView(lyricsCell, LinearLayout.LayoutParams(0, act.dp(56), 1f))
        bottom.addView(cell(airBtn, R.drawable.ic_air, 26) { openOutputPicker() },
            LinearLayout.LayoutParams(0, act.dp(56), 1f))
        bottom.addView(cell(queueBtn, R.drawable.ic_io_list, 22) { act.openQueue() },
            LinearLayout.LayoutParams(0, act.dp(56), 1f))
        content.addView(bottom, LinearLayout.LayoutParams(-1, -2).apply {
            marginStart = act.dp(36)
            marginEnd = act.dp(36)
        })

        // swipe-down zone over the handle and the cover
        view.addView(dragZone, FrameLayout.LayoutParams(-1, act.dp(200), Gravity.TOP))
        setupDrag()

        view.isClickable = true
        applyInsets()
        refreshBackground(false)
    }

    private fun setupDrag() {
        var startY = 0f
        var tracker: VelocityTracker? = null
        dragZone.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startY = e.rawY
                    tracker = VelocityTracker.obtain().also { it.addMovement(e) }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    tracker?.addMovement(e)
                    view.translationY = (e.rawY - startY).coerceAtLeast(0f)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    tracker?.computeCurrentVelocity(1000)
                    val vy = tracker?.yVelocity ?: 0f
                    tracker?.recycle()
                    tracker = null
                    if (view.translationY > view.height * 0.22f || vy > 1500f) {
                        hide()
                    } else {
                        view.animate().translationY(0f).setDuration(200).start()
                    }
                    true
                }
                else -> false
            }
        }
    }

    fun applyInsets() {
        content.setPadding(0, 0, 0, maxOf(act.dp(30), act.bottomInset + act.dp(8)))
        (dragZone.layoutParams as FrameLayout.LayoutParams).height =
            if (lyricsOn) act.dp(63 + 5 + 14) else act.dp(63 + 5 + 28 + 8) + coverSize
        dragZone.requestLayout()
    }

    // ---------------------------------------------------------------- appearance

    private fun lightMode(): Boolean = Prefs.playerBg == 0 && act.onLightBg()

    private fun withAlpha(color: Int, alpha: Float): Int = ColorUtils.setAlphaComponent(color, (alpha * 255).toInt())

    fun applyColors() {
        val fg = if (lightMode()) act.fg1() else Color.WHITE
        val fg2 = withAlpha(fg, 0.62f)
        title.setTextColor(fg)
        artist.setTextColor(fg2)
        elapsed.setTextColor(fg2)
        remaining.setTextColor(fg2)
        seek.setColors(fg, withAlpha(fg, 0.30f))
        volume.setColors(fg, withAlpha(fg, 0.30f))
        val tintFg = ColorStateList.valueOf(fg)
        listOf(prev, play, next, star, airBtn, queueBtn, moreIcon, lMoreIcon).forEach { it.imageTintList = tintFg }
        lTitle.setTextColor(fg)
        lArtist.setTextColor(fg2)
        lyrics.setColor(fg)
        lMoreBox.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(withAlpha(fg, 0.20f))
        }
        updateLyricsBtn(fg)
        val tint2 = ColorStateList.valueOf(fg2)
        volLow.imageTintList = tint2
        volHigh.imageTintList = tint2
        airBtn.alpha = 0.8f
        queueBtn.alpha = 0.8f
        val circle = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(withAlpha(fg, 0.20f))
        }
        starBox.background = circle
        moreBox.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(withAlpha(fg, 0.20f))
        }
        handle.background = GradientDrawable().apply {
            cornerRadius = act.dp(3).toFloat()
            setColor(withAlpha(fg, 0.40f))
        }
    }

    fun refreshBackground(animate: Boolean) {
        val style = Prefs.playerBg
        if (style == 1) {
            val c = act.songColorOrNull()
            val bottom: Int
            if (c != null) {
                val hsl = FloatArray(3)
                ColorUtils.colorToHSL(c, hsl)
                bottom = ColorUtils.HSLToColor(floatArrayOf(hsl[0], hsl[1].coerceIn(0.25f, 0.45f), 0.20f))
            } else {
                bottom = 0xFF2A2A2E.toInt()
            }
            bg.setColors(0xFF111012.toInt(), bottom, animate)
            bg.setCover(null, animate)
            bg.setShade(0)
        } else if (style == 2) {
            bg.setColors(0xFF111012.toInt(), 0xFF2A2A2E.toInt(), animate)
            bg.setCover(act.blurredCover(), animate)
            bg.setShade(0x33000000)
        } else {
            act.styleBackground(bg, animate)
        }
        updateFullCover()
        applyColors()
    }

    private fun updateFullCover() {
        val song = act.currentSong()
        val want = Prefs.playerBg == 2 && song != null && !lyricsOn
        val vis = if (want) View.VISIBLE else View.GONE
        fullMask.visibility = vis
        shade.visibility = vis
        cover.visibility = if (want) View.INVISIBLE else View.VISIBLE
        if (want && song != null) {
            val id = song.id
            CoverLoader.bitmap(act, song, 1024) { b ->
                if (b != null && act.currentSong()?.id == id) fullCover.setImageBitmap(b)
            }
        }
    }

    // ---------------------------------------------------------------- open / close

    fun show() {
        if (isOpen) return
        isOpen = true
        act.onPlayerOpened()
        applyInsets()
        view.visibility = View.VISIBLE
        view.translationY = act.resources.displayMetrics.heightPixels.toFloat()
        view.animate().translationY(0f).setDuration(340).setInterpolator(DecelerateInterpolator()).start()
        update()
        handler.post(tick)
        if (lyricsOn) startFrames()
    }

    fun hide() {
        if (!isOpen) return
        isOpen = false
        handler.removeCallbacks(tick)
        stopFrames()
        view.animate()
            .translationY(act.resources.displayMetrics.heightPixels.toFloat())
            .setDuration(280)
            .withEndAction { view.visibility = View.GONE }
            .start()
        act.onPlayerClosed()
    }

    /** Re-reads the current song and state from the controller. */
    fun update() {
        val c = Playback.controller
        val song = act.currentSong()
        if (song != null && song.id != shownSongId) {
            shownSongId = song.id
            title.text = song.title
            artist.text = song.artist
            lTitle.text = song.title
            lArtist.text = song.artist
            CoverLoader.load(act, song, 1024, cover)
            CoverLoader.load(act, song, 256, miniCover)
            updateFullCover()
            lyricsSkip = 0
            lyricsReady = false
            if (lyricsOn) loadLyrics(false)
        }
        updateStar()
        val playing = c?.isPlaying == true
        play.setImageResource(if (playing) R.drawable.ic_cu_pause else R.drawable.ic_cu_play)
        val s = if (playing) 1f else 0.88f
        cover.animate().scaleX(s).scaleY(s).setDuration(320).start()
        prev.alpha = if (c != null && c.hasPreviousMediaItem()) 1f else 0.35f
        next.alpha = if (c != null && c.hasNextMediaItem()) 1f else 0.35f
        updateProgress()
    }

    private fun updateStar() {
        val s = act.currentSong()
        val fav = s != null && Prefs.favorites.contains(s.id)
        star.setImageResource(if (fav) R.drawable.ic_cu_star_fill else R.drawable.ic_cu_star)
    }

    private fun updateProgress() {
        val c = Playback.controller ?: return
        val d = c.duration
        val p = c.currentPosition
        if (d > 0 && !seek.isDragging) {
            seek.progress = p.toFloat() / d
            elapsed.text = fmtTime(p)
            remaining.text = "-" + fmtTime(d - p)
        }
        if (!volume.isDragging) {
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            if (max > 0) volume.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
        }
    }

    // ---------------------------------------------------------------- lyrics

    private fun startFrames() {
        Choreographer.getInstance().removeFrameCallback(frame)
        Choreographer.getInstance().postFrameCallback(frame)
    }

    private fun stopFrames() {
        Choreographer.getInstance().removeFrameCallback(frame)
    }

    private fun updateLyricsBtn(fg: Int = if (lightMode()) act.fg1() else Color.WHITE) {
        if (lyricsOn) {
            val dark = if (Color.luminance(fg) > 0.5f) 0xFF2A2A2E.toInt() else Color.WHITE
            lyricsHl.background = GradientDrawable().apply {
                cornerRadius = act.dp(10).toFloat()
                setColor(withAlpha(fg, 0.85f))
            }
            lyricsHl.visibility = View.VISIBLE
            lyricsBtn.imageTintList = ColorStateList.valueOf(dark)
            lyricsBtn.alpha = 1f
        } else {
            lyricsHl.visibility = View.GONE
            lyricsBtn.imageTintList = ColorStateList.valueOf(fg)
            lyricsBtn.alpha = 0.8f
        }
    }

    private fun setLyricsMode(on: Boolean) {
        if (lyricsOn == on) return
        lyricsOn = on
        coverHolder.visibility = if (on) View.GONE else View.VISIBLE
        info.visibility = if (on) View.GONE else View.VISIBLE
        lyricHeader.visibility = if (on) View.VISIBLE else View.GONE
        lyrics.visibility = if (on) View.VISIBLE else View.GONE
        val lp = controls.layoutParams as LinearLayout.LayoutParams
        if (on) {
            lp.height = act.dp(90)
            lp.weight = 0f
        } else {
            lp.height = 0
            lp.weight = 1f
        }
        controls.layoutParams = lp
        updateFullCover()
        updateLyricsBtn()
        applyInsets()
        if (on) {
            val song = act.currentSong()
            if (song != null) {
                lTitle.text = song.title
                lArtist.text = song.artist
                CoverLoader.load(act, song, 256, miniCover)
            }
            lyricHeader.alpha = 0f
            lyricHeader.animate().alpha(1f).setDuration(260).start()
            lyrics.alpha = 0f
            lyrics.animate().alpha(1f).setDuration(320).start()
            loadLyrics(false)
            if (isOpen) startFrames()
        } else {
            stopFrames()
        }
    }

    private fun loadLyrics(force: Boolean) {
        val song = act.currentSong() ?: return
        if (!force && lyricsReady && lyricsSongId == song.id) return
        lyricsSongId = song.id
        lyricsReady = false
        val token = ++lyricsToken
        lyrics.offsetMs = Prefs.lyricOffset(song.id).toLong()
        lyrics.showStatus("Loading lyrics…")
        LyricsRepository.load(act, song, lyricsSkip, force) { r ->
            if (token != lyricsToken || !lyricsOn) return@load
            when (r.status) {
                LyricsRepository.Status.OK -> {
                    val l = r.lyrics
                    if (l != null) {
                        lyrics.setLyrics(l)
                        lyricsReady = true
                        lyrics.onPosition(smoothPosition())
                    }
                }
                LyricsRepository.Status.INSTRUMENTAL -> lyrics.showStatus("Instrumental")
                LyricsRepository.Status.OFFLINE ->
                    lyrics.showStatus("Couldn’t reach the lyrics service.\nCheck your connection and try again from the ··· menu.")
                LyricsRepository.Status.NOT_FOUND ->
                    lyrics.showStatus("No lyrics found for this song.\nTry ··· › Try another version.")
            }
        }
    }

    private fun shiftLyrics(song: Song, deltaMs: Int) {
        val v = Prefs.lyricOffset(song.id) + deltaMs
        Prefs.setLyricOffset(song.id, v)
        lyrics.offsetMs = v.toLong()
        lyrics.onPosition(smoothPosition())
    }

    private fun showMoreMenu() {
        val c = Playback.controller ?: return
        val repeat = when (c.repeatMode) {
            Player.REPEAT_MODE_ALL -> "Repeat: All"
            Player.REPEAT_MODE_ONE -> "Repeat: One"
            else -> "Repeat: Off"
        }
        val shuffle = if (c.shuffleModeEnabled) "Shuffle: On" else "Shuffle: Off"
        val song = act.currentSong()
        PopupMenu(act, if (lyricsOn) lMoreBox else moreBox).apply {
            menu.add(0, 1, 0, repeat)
            menu.add(0, 2, 1, shuffle)
            if (lyricsOn && song != null) {
                val off = Prefs.lyricOffset(song.id)
                menu.add(0, 3, 2, "Lyrics later  +0.5s")
                menu.add(0, 4, 3, "Lyrics earlier  −0.5s")
                if (off != 0) menu.add(0, 5, 4, "Reset lyrics timing (now %+.1fs)".format(off / 1000.0))
                menu.add(0, 6, 5, "Try another version")
                menu.add(0, 7, 6, "Reload lyrics")
            }
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    1 -> c.repeatMode = when (c.repeatMode) {
                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                        else -> Player.REPEAT_MODE_OFF
                    }
                    2 -> c.shuffleModeEnabled = !c.shuffleModeEnabled
                    3 -> if (song != null) shiftLyrics(song, 500)
                    4 -> if (song != null) shiftLyrics(song, -500)
                    5 -> if (song != null) shiftLyrics(song, -Prefs.lyricOffset(song.id))
                    6 -> {
                        lyricsSkip++
                        loadLyrics(true)
                    }
                    7 -> {
                        lyricsSkip = 0
                        loadLyrics(true)
                    }
                }
                true
            }
            show()
        }
    }

    private fun openOutputPicker() {
        val attempts = listOf(
            Intent("com.android.settings.panel.action.MEDIA_OUTPUT")
                .putExtra("com.android.settings.panel.extra.PACKAGE_NAME", act.packageName),
            Intent(Settings.Panel.ACTION_VOLUME),
            Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
        )
        for (intent in attempts) {
            try {
                act.startActivity(intent)
                return
            } catch (e: Exception) {
            }
        }
    }
}
