package com.glassmusic

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore

object MusicRepository {
    @Volatile var songs: List<Song> = emptyList()
    @Volatile var byId: Map<Long, Song> = emptyMap()
    @Volatile var folders: List<Folder> = emptyList()

    fun load(context: Context) {
        val list = ArrayList<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.DURATION} >= 20000 AND " +
            "${MediaStore.Audio.Media.IS_RINGTONE} = 0 AND " +
            "${MediaStore.Audio.Media.IS_NOTIFICATION} = 0 AND " +
            "${MediaStore.Audio.Media.IS_ALARM} = 0"

        context.contentResolver.query(collection, projection, selection, null, null)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val iData = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val iDate = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) {
                val path = c.getString(iData) ?: ""
                val lower = path.lowercase()
                // skip voice recordings and call recordings
                if (lower.contains("/recordings/") || lower.contains("/call/") ||
                    lower.contains("voice recorder") || lower.contains("/voice/")
                ) continue
                val id = c.getLong(iId)
                var artist = c.getString(iArtist) ?: "Unknown Artist"
                if (artist == "<unknown>") artist = "Unknown Artist"
                list.add(
                    Song(
                        id = id,
                        title = c.getString(iTitle) ?: "Unknown",
                        artist = artist,
                        album = c.getString(iAlbum) ?: "",
                        albumId = c.getLong(iAlbumId),
                        folderPath = path.substringBeforeLast('/', ""),
                        dateAdded = c.getLong(iDate),
                        durationMs = c.getLong(iDur),
                        uri = ContentUris.withAppendedId(collection, id),
                        path = path
                    )
                )
            }
        }

        songs = list
        byId = list.associateBy { it.id }
        folders = list.groupBy { it.folderPath }
            .map { (path, s) ->
                Folder(path, path.substringAfterLast('/').ifEmpty { "Unknown" },
                    s.sortedBy { it.title.lowercase() })
            }
            .sortedBy { it.name.lowercase() }
    }

    fun sorted(mode: Int): List<Song> = when (mode) {
        1 -> songs.sortedWith(compareBy({ it.artist.lowercase() }, { it.title.lowercase() }))
        2 -> songs.sortedByDescending { it.dateAdded }
        else -> songs.sortedBy { it.title.lowercase() }
    }
}
