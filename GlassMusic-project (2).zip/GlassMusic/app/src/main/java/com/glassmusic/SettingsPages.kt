package com.glassmusic

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// ------------------------------------------------------------------ small UI kit

fun settingsCard(act: MainActivity, owner: Any, radiusDp: Int = 24): LinearLayout {
    val card = LinearLayout(act)
    card.orientation = LinearLayout.VERTICAL
    card.layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
        marginStart = act.dp(19)
        marginEnd = act.dp(19)
        topMargin = act.dp(14)
    }
    act.themed(owner) {
        card.background = GradientDrawable().apply {
            setColor(act.surface())
            cornerRadius = act.dp(radiusDp).toFloat()
        }
    }
    return card
}

fun rowDivider(act: MainActivity, owner: Any, startDp: Int = 18): View {
    val v = View(act)
    v.layoutParams = LinearLayout.LayoutParams(-1, 2).apply { marginStart = act.dp(startDp) }
    act.themed(owner) { v.setBackgroundColor(act.fgDivider()) }
    return v
}

private fun textColumn(
    act: MainActivity,
    owner: Any,
    title: String,
    subtitle: String?
): LinearLayout {
    val t = TextView(act)
    t.text = title
    t.tsz(18f)
    val col = LinearLayout(act)
    col.orientation = LinearLayout.VERTICAL
    col.addView(t)
    var s: TextView? = null
    if (subtitle != null) {
        s = TextView(act)
        s.text = subtitle
        s.tsz(13.5f)
        col.addView(s)
    }
    act.themed(owner) {
        t.setTextColor(act.fg1())
        s?.setTextColor(act.fg2())
    }
    return col
}

fun switchRow(
    act: MainActivity,
    owner: Any,
    title: String,
    subtitle: String?,
    checked: Boolean,
    onChange: (Boolean) -> Unit
): LinearLayout {
    val texts = textColumn(act, owner, title, subtitle)
    val sw = makeGlassToggle(act, checked, onChange)
    val row = LinearLayout(act)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(act.dp(18), act.dp(14), act.dp(16), act.dp(14))
    row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = act.dp(10) })
    val d = act.resources.displayMetrics.density
    row.addView(sw, LinearLayout.LayoutParams(-2, -2).apply {
        topMargin = -(15 * d).toInt()
        bottomMargin = -(15 * d).toInt()
        rightMargin = -(20 * d).toInt()
    })
    return row
}

fun navRow(
    act: MainActivity,
    owner: Any,
    title: String,
    subtitle: String?,
    onClick: () -> Unit
): LinearLayout {
    val texts = textColumn(act, owner, title, subtitle)
    val chev = ImageView(act)
    chev.setImageResource(R.drawable.ic_cu_chevron)
    act.themed(owner) { chev.imageTintList = ColorStateList.valueOf(act.fg2()) }
    val row = LinearLayout(act)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(act.dp(18), act.dp(16), act.dp(16), act.dp(16))
    row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = act.dp(10) })
    row.addView(chev, LinearLayout.LayoutParams(act.dp(14), act.dp(22)))
    row.setOnClickListener { onClick() }
    return row
}

// ------------------------------------------------------------------ generic sub page

/** A settings sub page: gradient background, glass back button, centered title, scrolling content. */
class SubPage(
    private val act: MainActivity,
    titleText: String,
    build: (SubPage, LinearLayout) -> Unit
) : FrameLayout(act), InsetsAware {

    private val bgv = act.newBackground(this)
    private val scroll = ScrollView(act)
    private val col = LinearLayout(act)
    private val title = TextView(act)

    init {
        addView(bgv, LayoutParams(-1, -1))

        col.orientation = LinearLayout.VERTICAL
        scroll.addView(col, LinearLayout.LayoutParams(-1, -2))
        scroll.clipToPadding = false
        scroll.isVerticalScrollBarEnabled = false
        addView(scroll, LayoutParams(-1, -1))

        title.text = titleText
        title.tsz(24f)
        title.typeface = Typeface.DEFAULT_BOLD
        title.gravity = Gravity.CENTER
        addView(title, LayoutParams(-1, -2, Gravity.TOP))
        act.themed(this) { title.setTextColor(act.fg1()) }

        build(this, col)
        applyInsets()
    }

    fun rebuild(build: (SubPage, LinearLayout) -> Unit) {
        col.removeAllViews()
        act.dropThemed(this)
        act.themed(this) { act.styleBackground(bgv, false) }
        act.themed(this) { title.setTextColor(act.fg1()) }
        build(this, col)
    }

    override fun applyInsets() {
        val top = maxOf(act.topInset + act.dp(10), act.dp(43))
        (title.layoutParams as LayoutParams).topMargin = top + act.dp(16)
        title.requestLayout()
        scroll.setPadding(0, top + act.dp(61 + 6), 0, act.contentBottomPad())
    }

    override fun retint() {}

    override fun onRemoved() {
        act.dropThemed(this)
    }
}

// ------------------------------------------------------------------ concrete pages

fun openThemePage(act: MainActivity) {
    act.pushOverlay(SubPage(act, "Theme") { page, col ->
        val card = settingsCard(act, page)
        card.addView(switchRow(act, page, "Dynamic Theme", "The app theme animates based on the currently playing song", Prefs.dynamicTheme) {
            Prefs.dynamicTheme = it
            act.applyTheme()
        })
        card.addView(rowDivider(act, page))
        card.addView(switchRow(act, page, "Dark Mode", "Pure black AMOLED background", Prefs.darkMode) {
            Prefs.darkMode = it
            act.applyTheme()
        })
        card.addView(rowDivider(act, page))
        card.addView(switchRow(act, page, "Use System Theme", "Follow the phone's dark mode", Prefs.useSystemTheme) {
            Prefs.useSystemTheme = it
            act.applyTheme()
        })
        col.addView(card)
    })
}

fun openAppUiPage(act: MainActivity) {
    act.pushOverlay(SubPage(act, "App UI") { page, col ->
        val card = settingsCard(act, page)
        card.addView(navRow(act, page, "Player Screen Background", "Selected background will be shown in Player Screen") {
            openBackgroundPicker(act)
        })
        card.addView(rowDivider(act, page))
        card.addView(switchRow(
            act, page, "Enable Liquid Glass",
            "It might have performance impact on lower end phones, use it based on your preference",
            Prefs.liquidGlass
        ) {
            Prefs.liquidGlass = it
            act.applyTheme()
        })
        card.addView(rowDivider(act, page))
        card.addView(switchRow(act, page, "Minimize Bars on Scroll", "The tab bar collapses when you scroll down", Prefs.collapseBars) {
            Prefs.collapseBars = it
            if (!it) act.setCollapsed(false)
        })
        card.addView(rowDivider(act, page))
        card.addView(switchRow(act, page, "Hide Status Bar", "Full immersive screen", Prefs.hideStatusBar) {
            Prefs.hideStatusBar = it
            act.applySystemBars()
        })
        col.addView(card)
    })
}

fun openOthersPage(act: MainActivity) {
    act.pushOverlay(SubPage(act, "Others") { page, col ->
        val card = settingsCard(act, page)
        card.addView(navRow(act, page, "Hidden Folders", "Choose folders to hide from the Home screen") {
            openHiddenFoldersPage(act)
        })
        col.addView(card)
    })
}

fun openAboutPage(act: MainActivity) {
    act.pushOverlay(SubPage(act, "About") { page, col ->
        val card = settingsCard(act, page)
        val tv = TextView(act)
        tv.text = "Glass Music 2.0\n\nLiquid glass effect: AndroidLiquidGlass by Kyant (Apache License 2.0)."
        tv.tsz(16f)
        tv.setPadding(act.dp(18), act.dp(18), act.dp(18), act.dp(18))
        act.themed(page) { tv.setTextColor(act.fg1()) }
        card.addView(tv)
        col.addView(card)
    })
}

fun openHiddenFoldersPage(act: MainActivity) {
    act.pushOverlay(SubPage(act, "Hidden Folders") { page, col ->
        val card = settingsCard(act, page)
        val folders = MusicRepository.folders
        if (folders.isEmpty()) {
            val tv = TextView(act)
            tv.text = "No folders found"
            tv.tsz(16f)
            tv.setPadding(act.dp(18), act.dp(18), act.dp(18), act.dp(18))
            act.themed(page) { tv.setTextColor(act.fg2()) }
            card.addView(tv)
        }
        val hidden = Prefs.hiddenFolders.toMutableSet()
        folders.forEachIndexed { i, f ->
            if (i > 0) card.addView(rowDivider(act, page))
            val n = f.songs.size
            card.addView(switchRow(act, page, f.name, if (n == 1) "1 song" else "$n songs", hidden.contains(f.path)) { on ->
                if (on) hidden.add(f.path) else hidden.remove(f.path)
                Prefs.hiddenFolders = hidden.toSet()
                act.refreshHome()
            })
        }
        col.addView(card)
    })
}

fun openBackgroundPicker(act: MainActivity) {
    act.pushOverlay(SubPage(act, "Player Screen") { page, col ->
        buildPicker(act, page, col)
    })
}

private fun buildPicker(act: MainActivity, page: SubPage, col: LinearLayout) {
    val names = listOf("OS Music 26", "Dark Gradient", "Cover Full Screen")
    val tops = intArrayOf(0xFFC4915E.toInt(), 0xFF121014.toInt(), 0xFF8FB4CC.toInt())
    val bottoms = intArrayOf(0xFF8A5C36.toInt(), 0xFF3A2B44.toInt(), 0xFF2B2430.toInt())
    val screenW = act.resources.displayMetrics.widthPixels
    val gap = act.dp(16)
    val cardW = (screenW - act.dp(19) * 2 - gap) / 2
    val cardH = (cardW * 1.45f).toInt()

    fun card(i: Int): View {
        val box = FrameLayout(act)
        box.layoutParams = LinearLayout.LayoutParams(cardW, cardH)
        val selected = Prefs.playerBg == i
        val bg = View(act)
        bg.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(tops[i], bottoms[i])).apply {
            cornerRadius = act.dp(26).toFloat()
            if (selected) setStroke(act.dp(4), Color.WHITE)
        }
        box.addView(bg, FrameLayout.LayoutParams(-1, -1))
        if (i != 2) {
            val mock = View(act)
            mock.background = GradientDrawable().apply {
                setColor(Color.argb(150, 255, 255, 255))
                cornerRadius = act.dp(14).toFloat()
            }
            box.addView(mock, FrameLayout.LayoutParams((cardW * 0.74f).toInt(), (cardW * 0.74f).toInt(), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = act.dp(22)
            })
        }
        val label = TextView(act)
        label.text = names[i]
        label.tsz(15f)
        label.setTextColor(Color.WHITE)
        label.gravity = Gravity.CENTER
        box.addView(label, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = act.dp(14) })
        if (selected) {
            val check = ImageView(act)
            check.setImageResource(R.drawable.ic_cu_check)
            check.imageTintList = ColorStateList.valueOf(Color.BLACK)
            val p = act.dp(11)
            check.setPadding(p, p, p, p)
            check.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.WHITE)
            }
            box.addView(check, FrameLayout.LayoutParams(act.dp(52), act.dp(52), Gravity.CENTER))
        }
        box.setOnClickListener {
            Prefs.playerBg = i
            act.refreshPlayerBackground()
            page.rebuild { p, c -> buildPicker(act, p, c) }
        }
        return box
    }

    var i = 0
    while (i < 3) {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
            marginStart = act.dp(19)
            marginEnd = act.dp(19)
            topMargin = act.dp(16)
        }
        row.addView(card(i))
        if (i + 1 < 3) {
            val c2 = card(i + 1)
            (c2.layoutParams as LinearLayout.LayoutParams).marginStart = gap
            row.addView(c2)
        }
        col.addView(row)
        i += 2
    }
}

// ------------------------------------------------------------------ main Settings tab

class SettingsPage(private val act: MainActivity) {
    private val scroll = ScrollView(act)
    private val col = LinearLayout(act)
    val view: View get() = scroll

    private fun glyphBox(color: Int, iconRes: Int, glyphDp: Int): FrameLayout {
        val box = FrameLayout(act)
        box.background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = act.dp(11).toFloat()
        }
        val img = ImageView(act)
        img.setImageResource(iconRes)
        img.imageTintList = ColorStateList.valueOf(Color.WHITE)
        box.addView(img, FrameLayout.LayoutParams(act.dp(glyphDp), act.dp(glyphDp), Gravity.CENTER))
        return box
    }

    private fun listRow(color: Int, iconRes: Int, glyphDp: Int, label: String, onClick: () -> Unit): LinearLayout {
        val tv = TextView(act)
        tv.text = label
        tv.tsz(19f)
        act.themed(this) { tv.setTextColor(act.fg1()) }
        val chev = ImageView(act)
        chev.setImageResource(R.drawable.ic_cu_chevron)
        act.themed(this) { chev.imageTintList = ColorStateList.valueOf(act.fg2()) }
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(act.dp(18), act.dp(9), act.dp(18), act.dp(9))
        row.addView(glyphBox(color, iconRes, glyphDp), LinearLayout.LayoutParams(act.dp(43), act.dp(43)))
        row.addView(tv, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = act.dp(20) })
        row.addView(chev, LinearLayout.LayoutParams(act.dp(12), act.dp(20)))
        row.setOnClickListener { onClick() }
        return row
    }

    init {
        col.orientation = LinearLayout.VERTICAL
        scroll.addView(col, LinearLayout.LayoutParams(-1, -2))
        scroll.clipToPadding = false
        scroll.isVerticalScrollBarEnabled = false
        scroll.setOnScrollChangeListener { _, _, y, _, oldY ->
            act.onListScrolled(2, y - oldY, y)
        }

        // header card
        val header = settingsCard(act, this, 48)
        (header.layoutParams as LinearLayout.LayoutParams).topMargin = act.dp(48)
        header.gravity = Gravity.CENTER_HORIZONTAL
        header.setPadding(act.dp(24), act.dp(14), act.dp(24), act.dp(14))
        val title = TextView(act)
        title.text = "Settings"
        title.tsz(22f)
        title.typeface = Typeface.DEFAULT_BOLD
        title.gravity = Gravity.CENTER
        val gearBox = FrameLayout(act)
        gearBox.background = GradientDrawable().apply {
            setColor(Color.argb(190, 150, 150, 158))
            cornerRadius = act.dp(22).toFloat()
        }
        val gear = ImageView(act)
        gear.setImageResource(R.drawable.ic_cu_gear)
        gear.imageTintList = ColorStateList.valueOf(Color.argb(235, 255, 248, 236))
        gearBox.addView(gear, FrameLayout.LayoutParams(act.dp(50), act.dp(50), Gravity.CENTER))
        val general = TextView(act)
        general.text = "General"
        general.tsz(28f)
        general.typeface = Typeface.DEFAULT_BOLD
        general.gravity = Gravity.CENTER
        val desc = TextView(act)
        desc.text = "Manage your overall setup and preferences for Glass Music, such as Themes, Color modes, Music playback settings etc."
        desc.tsz(17f)
        desc.gravity = Gravity.CENTER_HORIZONTAL
        act.themed(this) {
            title.setTextColor(act.fg1())
            general.setTextColor(act.fg1())
            desc.setTextColor(act.fg2())
        }
        header.addView(title, LinearLayout.LayoutParams(-1, -2))
        header.addView(gearBox, LinearLayout.LayoutParams(act.dp(80), act.dp(80)).apply { topMargin = act.dp(6) })
        header.addView(general, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(4) })
        header.addView(desc, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(8) })
        col.addView(header)

        // list card
        val list = settingsCard(act, this, 40)
        (list.layoutParams as LinearLayout.LayoutParams).topMargin = act.dp(24)
        list.addView(listRow(0xFF007AFF.toInt(), R.drawable.ic_cu_sun, 28, "Theme") { openThemePage(act) })
        list.addView(rowDivider(act, this, 82))
        list.addView(listRow(0xFFFF9500.toInt(), R.drawable.ic_cu_phone, 24, "App UI") { openAppUiPage(act) })
        list.addView(rowDivider(act, this, 82))
        list.addView(listRow(0xFF8E8E93.toInt(), R.drawable.ic_mat_misc, 28, "Others") { openOthersPage(act) })
        list.addView(rowDivider(act, this, 82))
        list.addView(listRow(0xFFB5B5BC.toInt(), R.drawable.ic_mat_info, 28, "About") { openAboutPage(act) })
        col.addView(list)
    }

    fun retint() {}

    fun offset(): Int = scroll.scrollY

    fun applyInsets() {
        scroll.setPadding(0, act.topInset, 0, act.contentBottomPad())
    }
}
