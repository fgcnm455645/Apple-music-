package com.glassmusic

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/** Thin Apple-style progress / volume bar. [progress] is a 0..1 fraction. */
class GlassSeekBar(context: Context) : View(context) {
    var progress: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }
    var onChange: ((Float) -> Unit)? = null
    var onRelease: ((Float) -> Unit)? = null
    var isDragging = false
        private set

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(80, 255, 255, 255) }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val h = if (isDragging) context.dp(10).toFloat() else context.dp(6).toFloat()
        val cy = height / 2f
        val r = h / 2f
        rect.set(0f, cy - r, width.toFloat(), cy + r)
        canvas.drawRoundRect(rect, r, r, trackPaint)
        rect.set(0f, cy - r, width * progress, cy + r)
        canvas.drawRoundRect(rect, r, r, fillPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                isDragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                update(event.x)
            }
            MotionEvent.ACTION_MOVE -> update(event.x)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                update(event.x)
                isDragging = false
                invalidate()
                onRelease?.invoke(progress)
            }
        }
        return true
    }

    private fun update(x: Float) {
        if (width == 0) return
        progress = x / width
        onChange?.invoke(progress)
    }
}
