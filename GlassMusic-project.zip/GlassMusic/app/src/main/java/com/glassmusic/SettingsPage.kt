package com.glassmusic

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat

class SettingsPage(private val act: MainActivity) {
    private val scroll = ScrollView(act)
    private val col = LinearLayout(act)
    private lateinit var darkRow: View
    private lateinit var darkSwitch: SwitchCompat
    val view: View get() = scroll

    init {
        col.orientation = LinearLayout.VERTICAL
        scroll.addView(col, LinearLayout.LayoutParams(-1, -2))
        scroll.clipToPadding = false
        scroll.isVerticalScrollBarEnabled = false

        col.addView(TextView(act).apply {
            text = "Settings"
            textSize = 40f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(act.dp(20), act.dp(84), act.dp(20), act.dp(14))
        })

        col.addView(sectionLabel("Theme"))
        val themeCard = card()
        themeCard.addView(switchRow("Dynamic Theme", "The app colors follow the playing song", Prefs.dynamicTheme) {
            Prefs.dynamicTheme = it
            act.applyTheme()
        })
        themeCard.addView(divider())
        val dark = switchRow("Dark Mode", null, Prefs.darkMode) {
            Prefs.darkMode = it
            act.applyTheme()
        }
        darkRow = dark
        darkSwitch = dark.getChildAt(1) as SwitchCompat
        themeCard.addView(dark)
        themeCard.addView(divider())
        themeCard.addView(switchRow("Use System Theme", "Follow the phone's dark mode", Prefs.useSystemTheme) {
            Prefs.useSystemTheme = it
            updateDarkEnabled()
            act.applyTheme()
        })
        col.addView(themeCard)
        updateDarkEnabled()

        col.addView(sectionLabel("App UI"))
        val uiCard = card()
        uiCard.addView(switchRow(
            "Enable Liquid Glass",
            "Lens refraction on the bars. Turn off if the app feels slow",
            Prefs.liquidGlass
        ) {
            Prefs.liquidGlass = it
            act.applyTheme()
        })
        uiCard.addView(divider())
        uiCard.addView(switchRow("Hide Status Bar", "Full immersive screen", Prefs.hideStatusBar) {
            Prefs.hideStatusBar = it
            act.applySystemBars()
        })
        col.addView(uiCard)

        col.addView(sectionLabel("About"))
        val about = card()
        about.addView(TextView(act).apply {
            text = "Glass Music 1.0\nLiquid glass effect: Liquid-Glass-Android by pandadog (MIT License)"
            textSize = 14f
            setTextColor(Color.argb(200, 255, 255, 255))
            setPadding(act.dp(18), act.dp(16), act.dp(18), act.dp(16))
        })
        col.addView(about)
    }

    private fun updateDarkEnabled() {
        darkSwitch.isEnabled = !Prefs.useSystemTheme
        darkRow.alpha = if (Prefs.useSystemTheme) 0.45f else 1f
    }

    private fun sectionLabel(text: String) = TextView(act).apply {
        this.text = text
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.argb(170, 255, 255, 255))
        setPadding(act.dp(32), act.dp(18), act.dp(20), act.dp(8))
    }

    private fun card() = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable().apply {
            setColor(Color.argb(56, 255, 255, 255))
            cornerRadius = act.dp(22).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
            marginStart = act.dp(20)
            marginEnd = act.dp(20)
        }
    }

    private fun divider() = View(act).apply {
        setBackgroundColor(Color.argb(40, 255, 255, 255))
        layoutParams = LinearLayout.LayoutParams(-1, 1).apply { marginStart = act.dp(18) }
    }

    private fun switchRow(
        title: String,
        subtitle: String?,
        checked: Boolean,
        onChange: (Boolean) -> Unit
    ): LinearLayout {
        val texts = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(act).apply {
                text = title
                textSize = 17f
                setTextColor(Color.WHITE)
            })
            if (subtitle != null) {
                addView(TextView(act).apply {
                    text = subtitle
                    textSize = 13f
                    setTextColor(Color.argb(165, 255, 255, 255))
                })
            }
        }
        val sw = SwitchCompat(act).apply {
            isChecked = checked
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(0xFF34C759.toInt(), 0x66FFFFFF)
            )
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }
        return LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(act.dp(18), act.dp(14), act.dp(16), act.dp(14))
            addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = act.dp(10) })
            addView(sw, LinearLayout.LayoutParams(-2, -2))
        }
    }

    fun applyInsets() {
        scroll.setPadding(0, act.topInset, 0, act.contentBottomPad())
    }
}
