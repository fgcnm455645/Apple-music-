package com.glassmusic

import android.graphics.Color
import android.graphics.Typeface
import android.text.TextUtils
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HomePage(private val act: MainActivity) {
    private val rv = RecyclerView(act)
    private val adapter = HomeAdapter(act)
    val view: View get() = rv

    init {
        val lm = GridLayoutManager(act, 2)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int = adapter.spanAt(position)
        }
        rv.layoutManager = lm
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.overScrollMode = View.OVER_SCROLL_NEVER
    }

    fun refresh() {
        adapter.setData(MusicRepository.folders, Prefs.recents.mapNotNull { MusicRepository.byId[it] })
    }

    fun applyInsets() {
        rv.setPadding(act.dp(12), act.topInset, act.dp(12), act.contentBottomPad())
    }
}

private sealed class Row {
    object Title : Row()
    class Section(val text: String) : Row()
    object Recents : Row()
    class FolderRow(val folder: Folder) : Row()
}

private class SimpleVH(view: View) : RecyclerView.ViewHolder(view)

private class FolderVH(
    view: View,
    val cover: SquareImageView,
    val name: TextView,
    val count: TextView
) : RecyclerView.ViewHolder(view)

class HomeAdapter(private val act: MainActivity) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private var rows: List<Row> = emptyList()
    private val recentAdapter = RecentAdapter(act)

    fun setData(folders: List<Folder>, recents: List<Song>) {
        val r = ArrayList<Row>()
        r.add(Row.Title)
        if (recents.isNotEmpty()) {
            r.add(Row.Section("Recently Played  \u203A"))
            r.add(Row.Recents)
        }
        if (folders.isNotEmpty()) {
            r.add(Row.Section("Folders"))
            folders.forEach { r.add(Row.FolderRow(it)) }
        }
        rows = r
        recentAdapter.submit(recents)
        notifyDataSetChanged()
    }

    fun spanAt(position: Int): Int = if (rows.getOrNull(position) is Row.FolderRow) 1 else 2

    override fun getItemCount() = rows.size

    override fun getItemViewType(position: Int): Int = when (rows[position]) {
        is Row.Title -> 0
        is Row.Section -> 1
        is Row.Recents -> 2
        is Row.FolderRow -> 3
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val ctx = parent.context
        when (viewType) {
            0 -> {
                val tv = TextView(ctx).apply {
                    text = "Listen Now"
                    textSize = 40f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    setPadding(act.dp(8), act.dp(84), act.dp(8), act.dp(6))
                    layoutParams = RecyclerView.LayoutParams(-1, -2)
                }
                return SimpleVH(tv)
            }
            1 -> {
                val tv = TextView(ctx).apply {
                    textSize = 22f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    setPadding(act.dp(8), act.dp(22), act.dp(8), act.dp(10))
                    layoutParams = RecyclerView.LayoutParams(-1, -2)
                }
                return SimpleVH(tv)
            }
            2 -> {
                val list = RecyclerView(ctx).apply {
                    layoutManager = LinearLayoutManager(ctx, LinearLayoutManager.HORIZONTAL, false)
                    adapter = recentAdapter
                    clipToPadding = false
                    overScrollMode = View.OVER_SCROLL_NEVER
                    setPadding(act.dp(8), 0, act.dp(8), 0)
                    layoutParams = RecyclerView.LayoutParams(-1, -2)
                }
                return SimpleVH(list)
            }
            else -> {
                val cover = SquareImageView(ctx).apply { round(act.dp(20).toFloat()) }
                val name = TextView(ctx).apply {
                    textSize = 16f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.WHITE)
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                }
                val count = TextView(ctx).apply {
                    textSize = 13f
                    setTextColor(Color.argb(170, 255, 255, 255))
                    maxLines = 1
                }
                val tile = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = RecyclerView.LayoutParams(-1, -2).apply {
                        setMargins(act.dp(8), 0, act.dp(8), act.dp(16))
                    }
                    addView(cover, LinearLayout.LayoutParams(-1, -2))
                    addView(name, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(8) })
                    addView(count, LinearLayout.LayoutParams(-1, -2))
                }
                return FolderVH(tile, cover, name, count)
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val row = rows[position]
        when {
            row is Row.Section && holder is SimpleVH -> (holder.itemView as TextView).text = row.text
            row is Row.FolderRow && holder is FolderVH -> {
                val folder = row.folder
                holder.name.text = folder.name
                val n = folder.songs.size
                holder.count.text = if (n == 1) "1 song" else "$n songs"
                CoverLoader.load(act, folder.songs.firstOrNull(), act.dp(180), holder.cover)
                holder.itemView.setOnClickListener { act.openFolder(folder) }
            }
        }
    }
}

class RecentAdapter(private val act: MainActivity) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private var songs: List<Song> = emptyList()

    fun submit(list: List<Song>) {
        songs = list
        notifyDataSetChanged()
    }

    private class VH(
        view: View,
        val cover: ImageView,
        val title: TextView,
        val artist: TextView
    ) : RecyclerView.ViewHolder(view)

    override fun getItemCount() = songs.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val ctx = parent.context
        val cover = ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        val play = ImageView(ctx).apply { setImageResource(R.drawable.ic_play) }
        val card = FrameLayout(ctx).apply {
            round(act.dp(14).toFloat())
            addView(cover, FrameLayout.LayoutParams(-1, -1))
            addView(play, FrameLayout.LayoutParams(act.dp(30), act.dp(30), android.view.Gravity.CENTER))
        }
        val title = TextView(ctx).apply {
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val artist = TextView(ctx).apply {
            textSize = 12f
            setTextColor(Color.argb(170, 255, 255, 255))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = RecyclerView.LayoutParams(act.dp(132), -2).apply { marginEnd = act.dp(10) }
            addView(card, LinearLayout.LayoutParams(act.dp(132), act.dp(78)))
            addView(title, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(6) })
            addView(artist, LinearLayout.LayoutParams(-1, -2))
        }
        return VH(box, cover, title, artist)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val vh = holder as VH
        val song = songs[position]
        vh.title.text = song.title
        vh.artist.text = song.artist
        CoverLoader.load(act, song, act.dp(132), vh.cover)
        vh.itemView.setOnClickListener {
            val i = vh.bindingAdapterPosition
            if (i >= 0) Playback.play(act, songs, i)
        }
    }
}
