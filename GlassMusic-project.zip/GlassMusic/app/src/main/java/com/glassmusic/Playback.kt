package com.glassmusic

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlin.random.Random

/** Thin client around the media session service. */
object Playback {
    var controller: MediaController? = null
        private set
    private val pending = ArrayList<(MediaController) -> Unit>()
    private var connecting = false

    fun whenReady(context: Context, block: (MediaController) -> Unit) {
        val c = controller
        if (c != null && c.isConnected) {
            block(c)
            return
        }
        controller = null
        pending.add(block)
        if (connecting) return
        connecting = true
        val app = context.applicationContext
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                val mc = future.get()
                controller = mc
                connecting = false
                val list = ArrayList(pending)
                pending.clear()
                list.forEach { it(mc) }
            } catch (e: Exception) {
                connecting = false
                pending.clear()
            }
        }, ContextCompat.getMainExecutor(app))
    }

    private fun toItem(song: Song): MediaItem =
        MediaItem.Builder()
            .setMediaId(song.id.toString())
            .setUri(song.uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(song.title)
                    .setArtist(song.artist)
                    .setAlbumTitle(song.album)
                    .setArtworkUri(Uri.parse("content://media/external/audio/albumart/${song.albumId}"))
                    .build()
            )
            .build()

    fun play(context: Context, songs: List<Song>, start: Int, shuffle: Boolean = false) {
        if (songs.isEmpty()) return
        whenReady(context) { c ->
            val startIndex = if (shuffle) Random.nextInt(songs.size) else start.coerceIn(0, songs.size - 1)
            c.shuffleModeEnabled = shuffle
            c.setMediaItems(songs.map { toItem(it) }, startIndex, 0L)
            c.prepare()
            c.play()
        }
    }

    fun playNext(context: Context, song: Song) {
        whenReady(context) { c ->
            if (c.mediaItemCount == 0) {
                c.setMediaItems(listOf(toItem(song)))
                c.prepare()
                c.play()
            } else {
                c.addMediaItem(c.currentMediaItemIndex + 1, toItem(song))
                Toast.makeText(context, "Playing next", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun addToQueue(context: Context, songs: List<Song>) {
        if (songs.isEmpty()) return
        whenReady(context) { c ->
            val items = songs.map { toItem(it) }
            if (c.mediaItemCount == 0) {
                c.setMediaItems(items)
                c.prepare()
                c.play()
            } else {
                c.addMediaItems(items)
                Toast.makeText(context, "Added to queue", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
