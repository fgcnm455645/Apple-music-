package com.glassmusic

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.media3.common.C
import androidx.media3.common.Player
import kotlin.math.roundToInt

/** Full-screen Now Playing, laid out like Apple Music. Slides up over everything. */
class PlayerScreen(private val act: MainActivity) {
    val view = FrameLayout(act)
    var isOpen = false
        private set

    private val bg = GradientBackgroundView(act)
    private val content = LinearLayout(act)
    private val dragZone = View(act)

    private val cover = SquareImageView(act)
    private val title = TextView(act)
    private val artist = TextView(act)
    private val more = ImageView(act)
    private val seek = GlassSeekBar(act)
    private val elapsed = TextView(act)
    private val remaining = TextView(act)
    private val prev = ImageView(act)
    private val play = ImageView(act)
    private val next = ImageView(act)
    private val volume = GlassSeekBar(act)
    private val shuffleBtn = ImageView(act)
    private val outputBtn = ImageView(act)
    private val queueBtn = ImageView(act)

    private val handler = Handler(Looper.getMainLooper())
    private val audio = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var shownSongId = -1L
    private var coverSize = 0

    private val tick = object : Runnable {
        override fun run() {
            if (!isOpen) return
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    init {
        val white = ColorStateList.valueOf(Color.WHITE)
        val screenW = act.resources.displayMetrics.widthPixels
        coverSize = screenW - act.dp(56)

        view.addView(bg, FrameLayout.LayoutParams(-1, -1))

        content.orientation = LinearLayout.VERTICAL
        content.gravity = Gravity.CENTER_HORIZONTAL
        view.addView(content, FrameLayout.LayoutParams(-1, -1))

        // drag handle
        val handle = View(act).apply {
            background = GradientDrawable().apply {
                setColor(Color.argb(120, 255, 255, 255))
                cornerRadius = act.dp(3).toFloat()
            }
        }
        content.addView(handle, LinearLayout.LayoutParams(act.dp(42), act.dp(5)).apply {
            topMargin = act.dp(8)
            bottomMargin = act.dp(20)
        })

        // cover
        cover.round(act.dp(22).toFloat())
        cover.elevation = act.dp(18).toFloat()
        val coverHolder = FrameLayout(act).apply {
            clipChildren = false
            clipToPadding = false
            addView(cover, FrameLayout.LayoutParams(-1, -1))
        }
        content.addView(coverHolder, LinearLayout.LayoutParams(coverSize, coverSize))

        // title row
        title.textSize = 24f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.WHITE)
        title.maxLines = 2
        title.ellipsize = TextUtils.TruncateAt.END
        artist.textSize = 20f
        artist.setTextColor(Color.argb(190, 255, 255, 255))
        artist.maxLines = 1
        artist.ellipsize = TextUtils.TruncateAt.END
        val texts = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            addView(title)
            addView(artist)
        }
        more.setImageResource(R.drawable.ic_more)
        more.imageTintList = white
        more.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(60, 255, 255, 255))
        }
        val mp = act.dp(9)
        more.setPadding(mp, mp, mp, mp)
        more.setOnClickListener { showMoreMenu() }
        val info = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = act.dp(12) })
            addView(more, LinearLayout.LayoutParams(act.dp(40), act.dp(40)))
        }
        content.addView(info, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(26) })

        // progress
        seek.onChange = { f ->
            val d = Playback.controller?.duration ?: C.TIME_UNSET
            if (d > 0) elapsed.text = fmt((f * d).toLong())
        }
        seek.onRelease = { f ->
            val c = Playback.controller
            val d = c?.duration ?: C.TIME_UNSET
            if (c != null && d > 0) c.seekTo((f * d).toLong())
        }
        content.addView(seek, LinearLayout.LayoutParams(-1, act.dp(28)).apply { topMargin = act.dp(14) })

        elapsed.textSize = 13f
        elapsed.setTextColor(Color.argb(170, 255, 255, 255))
        remaining.textSize = 13f
        remaining.setTextColor(Color.argb(170, 255, 255, 255))
        remaining.gravity = Gravity.END
        val times = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(elapsed, LinearLayout.LayoutParams(0, -2, 1f))
            addView(remaining, LinearLayout.LayoutParams(0, -2, 1f))
        }
        content.addView(times, LinearLayout.LayoutParams(-1, -2))

        // transport controls
        prev.setImageResource(R.drawable.ic_prev)
        play.setImageResource(R.drawable.ic_play)
        next.setImageResource(R.drawable.ic_next)
        listOf(prev, play, next).forEach { it.imageTintList = white }
        prev.setOnClickListener { Playback.controller?.seekToPrevious() }
        next.setOnClickListener { Playback.controller?.seekToNext() }
        play.setOnClickListener {
            val c = Playback.controller
            if (c != null) {
                if (c.isPlaying) c.pause() else c.play()
            }
        }
        val controls = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(centered(prev, 50), LinearLayout.LayoutParams(0, -2, 1f))
            addView(centered(play, 74), LinearLayout.LayoutParams(0, -2, 1f))
            addView(centered(next, 50), LinearLayout.LayoutParams(0, -2, 1f))
        }
        content.addView(controls, LinearLayout.LayoutParams(-1, 0, 1f))

        // volume
        val volLow = ImageView(act).apply {
            setImageResource(R.drawable.ic_vol_low)
            imageTintList = ColorStateList.valueOf(Color.argb(190, 255, 255, 255))
        }
        val volHigh = ImageView(act).apply {
            setImageResource(R.drawable.ic_vol_high)
            imageTintList = ColorStateList.valueOf(Color.argb(190, 255, 255, 255))
        }
        volume.onChange = { f ->
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (f * max).roundToInt(), 0)
        }
        val volRow = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(volLow, LinearLayout.LayoutParams(act.dp(20), act.dp(20)))
            addView(volume, LinearLayout.LayoutParams(0, act.dp(28), 1f).apply {
                marginStart = act.dp(12)
                marginEnd = act.dp(12)
            })
            addView(volHigh, LinearLayout.LayoutParams(act.dp(22), act.dp(22)))
        }
        content.addView(volRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = act.dp(14) })

        // bottom icons
        shuffleBtn.setImageResource(R.drawable.ic_shuffle)
        outputBtn.setImageResource(R.drawable.ic_output)
        queueBtn.setImageResource(R.drawable.ic_queue)
        listOf(shuffleBtn, outputBtn, queueBtn).forEach { it.imageTintList = white }
        shuffleBtn.setOnClickListener {
            val c = Playback.controller
            if (c != null) {
                c.shuffleModeEnabled = !c.shuffleModeEnabled
                refreshButtons()
            }
        }
        outputBtn.setOnClickListener { openOutputPicker() }
        queueBtn.setOnClickListener { act.openQueue() }
        val bottom = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(centered(shuffleBtn, 28), LinearLayout.LayoutParams(0, act.dp(56), 1f))
            addView(centered(outputBtn, 28), LinearLayout.LayoutParams(0, act.dp(56), 1f))
            addView(centered(queueBtn, 28), LinearLayout.LayoutParams(0, act.dp(56), 1f))
        }
        content.addView(bottom, LinearLayout.LayoutParams(-1, -2))

        // swipe-down zone over the handle and the cover
        view.addView(dragZone, FrameLayout.LayoutParams(-1, act.dp(200), Gravity.TOP))
        setupDrag()

        view.isClickable = true
        applyInsets()
    }

    private fun centered(icon: ImageView, sizeDp: Int): FrameLayout {
        val box = FrameLayout(act)
        val tap = act.dp(10)
        icon.setPadding(tap, tap, tap, tap)
        box.addView(icon, FrameLayout.LayoutParams(act.dp(sizeDp) + tap * 2, act.dp(sizeDp) + tap * 2, Gravity.CENTER))
        return box
    }

    private fun setupDrag() {
        var startY = 0f
        var tracker: VelocityTracker? = null
        dragZone.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startY = e.rawY
                    tracker = VelocityTracker.obtain().also { it.addMovement(e) }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    tracker?.addMovement(e)
                    view.translationY = (e.rawY - startY).coerceAtLeast(0f)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    tracker?.computeCurrentVelocity(1000)
                    val vy = tracker?.yVelocity ?: 0f
                    tracker?.recycle()
                    tracker = null
                    if (view.translationY > view.height * 0.22f || vy > 1500f) {
                        hide()
                    } else {
                        view.animate().translationY(0f).setDuration(200).start()
                    }
                    true
                }
                else -> false
            }
        }
    }

    fun applyInsets() {
        content.setPadding(act.dp(28), act.topInset + act.dp(4), act.dp(28), act.bottomInset + act.dp(8))
        (dragZone.layoutParams as FrameLayout.LayoutParams).height =
            act.topInset + act.dp(4 + 33) + coverSize + act.dp(10)
        dragZone.requestLayout()
    }

    fun setColors(top: Int, bottom: Int, animate: Boolean) {
        bg.setColors(top, bottom, animate)
    }

    fun show() {
        if (isOpen) return
        isOpen = true
        applyInsets()
        view.visibility = View.VISIBLE
        view.translationY = act.resources.displayMetrics.heightPixels.toFloat()
        view.animate().translationY(0f).setDuration(340).setInterpolator(DecelerateInterpolator()).start()
        update()
        handler.post(tick)
    }

    fun hide() {
        if (!isOpen) return
        isOpen = false
        handler.removeCallbacks(tick)
        view.animate()
            .translationY(act.resources.displayMetrics.heightPixels.toFloat())
            .setDuration(280)
            .withEndAction { view.visibility = View.GONE }
            .start()
        act.onPlayerClosed()
    }

    /** Re-reads the current song and state from the controller. */
    fun update() {
        val c = Playback.controller
        val song = act.currentSong()
        if (song != null && song.id != shownSongId) {
            shownSongId = song.id
            title.text = song.title
            artist.text = song.artist
            CoverLoader.load(act, song, 1024, cover)
        }
        val playing = c?.isPlaying == true
        play.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        val s = if (playing) 1f else 0.88f
        cover.animate().scaleX(s).scaleY(s).setDuration(320).start()
        refreshButtons()
        updateProgress()
    }

    private fun refreshButtons() {
        val c = Playback.controller
        shuffleBtn.alpha = if (c?.shuffleModeEnabled == true) 1f else 0.5f
    }

    private fun updateProgress() {
        val c = Playback.controller ?: return
        val d = c.duration
        val p = c.currentPosition
        if (d > 0 && !seek.isDragging) {
            seek.progress = p.toFloat() / d
            elapsed.text = fmt(p)
            remaining.text = "-" + fmt(d - p)
        }
        if (!volume.isDragging) {
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            if (max > 0) volume.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
        }
    }

    private fun showMoreMenu() {
        val c = Playback.controller ?: return
        val label = when (c.repeatMode) {
            Player.REPEAT_MODE_ALL -> "Repeat: All"
            Player.REPEAT_MODE_ONE -> "Repeat: One"
            else -> "Repeat: Off"
        }
        PopupMenu(act, more).apply {
            menu.add(0, 1, 0, label)
            setOnMenuItemClickListener {
                c.repeatMode = when (c.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
                true
            }
            show()
        }
    }

    private fun openOutputPicker() {
        val attempts = listOf(
            Intent("com.android.settings.panel.action.MEDIA_OUTPUT")
                .putExtra("com.android.settings.panel.extra.PACKAGE_NAME", act.packageName),
            Intent(Settings.Panel.ACTION_VOLUME),
            Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
        )
        for (intent in attempts) {
            try {
                act.startActivity(intent)
                return
            } catch (e: Exception) {
            }
        }
    }
}
