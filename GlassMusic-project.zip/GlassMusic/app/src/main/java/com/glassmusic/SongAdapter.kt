package com.glassmusic

import android.content.res.ColorStateList
import android.graphics.Color
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** Song list with an optional header view (used for big titles and folder headers). */
class SongAdapter(
    private val act: MainActivity,
    private val coverDp: Int,
    private val whiteText: Boolean = false
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var songs: List<Song> = emptyList()
        private set
    var header: View? = null
    var onSongClick: ((list: List<Song>, index: Int) -> Unit)? = null

    fun submit(list: List<Song>) {
        songs = list
        notifyDataSetChanged()
    }

    private fun c1() = if (whiteText) Color.WHITE else act.fg1()
    private fun c2() = if (whiteText) Color.argb(170, 255, 255, 255) else act.fg2()
    private fun cDiv() = if (whiteText) Color.argb(50, 255, 255, 255) else act.fgDivider()

    private class VH(
        view: View,
        val cover: ImageView?,
        val title: TextView?,
        val artist: TextView?,
        val more: ImageView?,
        val divider: View?
    ) : RecyclerView.ViewHolder(view)

    private fun headerCount() = if (header != null) 1 else 0

    override fun getItemCount() = songs.size + headerCount()

    override fun getItemViewType(position: Int) = if (header != null && position == 0) 0 else 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        if (viewType == 0) {
            val h = header!!
            (h.parent as? ViewGroup)?.removeView(h)
            h.layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            return VH(h, null, null, null, null, null)
        }
        val ctx = parent.context
        val coverPx = act.dp(coverDp)

        val cover = ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            round(act.dp(8).toFloat())
        }
        val title = TextView(ctx).apply {
            textSize = 17f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val artist = TextView(ctx).apply {
            textSize = 15f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val texts = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            addView(title)
            addView(artist)
        }
        val more = ImageView(ctx).apply {
            setImageResource(R.drawable.ic_cu_ellipsis)
            val p = act.dp(14)
            setPadding(p, p, p, p)
        }
        val content = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(act.dp(19), act.dp(10), act.dp(14), act.dp(10))
            addView(cover, LinearLayout.LayoutParams(coverPx, coverPx))
            addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = act.dp(18)
                marginEnd = act.dp(4)
            })
            addView(more, LinearLayout.LayoutParams(act.dp(46), act.dp(46)))
        }
        val divider = View(ctx)
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            addView(content)
            addView(divider, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 2).apply {
                marginStart = act.dp(19) + coverPx + act.dp(18)
            })
        }
        return VH(row, cover, title, artist, more, divider)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val vh = holder as VH
        if (vh.title == null) return
        val index = position - headerCount()
        val song = songs[index]
        vh.title.text = song.title
        vh.title.setTextColor(c1())
        vh.artist!!.text = song.artist
        vh.artist.setTextColor(c2())
        vh.more!!.imageTintList = ColorStateList.valueOf(c1())
        vh.divider!!.setBackgroundColor(cDiv())
        CoverLoader.load(act, song, act.dp(coverDp) * 2, vh.cover!!)
        vh.itemView.setOnClickListener {
            val i = vh.bindingAdapterPosition - headerCount()
            if (i >= 0 && i < songs.size) onSongClick?.invoke(songs, i)
        }
        vh.more.setOnClickListener { anchor ->
            val i = vh.bindingAdapterPosition - headerCount()
            if (i < 0 || i >= songs.size) return@setOnClickListener
            val s = songs[i]
            PopupMenu(act, anchor).apply {
                menu.add(0, 1, 0, "Play Next")
                menu.add(0, 2, 1, "Add to Queue")
                setOnMenuItemClickListener { item ->
                    if (item.itemId == 1) Playback.playNext(act, s) else Playback.addToQueue(act, listOf(s))
                    true
                }
                show()
            }
        }
    }
}
