package com.glassmusic

import android.graphics.Color
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** Song list with an optional header view (used for big titles and folder headers). */
class SongAdapter(
    private val act: MainActivity,
    private val coverDp: Int
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var songs: List<Song> = emptyList()
        private set
    var header: View? = null
    var onSongClick: ((list: List<Song>, index: Int) -> Unit)? = null

    fun submit(list: List<Song>) {
        songs = list
        notifyDataSetChanged()
    }

    private class VH(
        view: View,
        val cover: ImageView?,
        val title: TextView?,
        val artist: TextView?,
        val more: ImageView?
    ) : RecyclerView.ViewHolder(view)

    private fun headerCount() = if (header != null) 1 else 0

    override fun getItemCount() = songs.size + headerCount()

    override fun getItemViewType(position: Int) = if (header != null && position == 0) 0 else 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        if (viewType == 0) {
            val h = header!!
            (h.parent as? ViewGroup)?.removeView(h)
            h.layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            return VH(h, null, null, null, null)
        }
        val ctx = parent.context
        val coverPx = act.dp(coverDp)

        val cover = ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            round(act.dp(8).toFloat())
        }
        val title = TextView(ctx).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val artist = TextView(ctx).apply {
            setTextColor(Color.argb(170, 255, 255, 255))
            textSize = 14f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val texts = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            addView(title)
            addView(artist)
        }
        val more = ImageView(ctx).apply {
            setImageResource(R.drawable.ic_more)
            imageTintList = android.content.res.ColorStateList.valueOf(Color.argb(210, 255, 255, 255))
            setPadding(act.dp(10), act.dp(10), act.dp(10), act.dp(10))
        }
        val content = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(act.dp(20), act.dp(8), act.dp(10), act.dp(8))
            addView(cover, LinearLayout.LayoutParams(coverPx, coverPx))
            addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = act.dp(14)
                marginEnd = act.dp(4)
            })
            addView(more, LinearLayout.LayoutParams(act.dp(44), act.dp(44)))
        }
        val divider = View(ctx).apply { setBackgroundColor(Color.argb(50, 255, 255, 255)) }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            addView(content)
            addView(divider, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1).apply {
                marginStart = act.dp(20) + coverPx + act.dp(14)
            })
        }
        return VH(row, cover, title, artist, more)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val vh = holder as VH
        if (vh.title == null) return
        val index = position - headerCount()
        val song = songs[index]
        vh.title.text = song.title
        vh.artist!!.text = song.artist
        CoverLoader.load(act, song, act.dp(coverDp) * 2, vh.cover!!)
        vh.itemView.setOnClickListener {
            val i = vh.bindingAdapterPosition - headerCount()
            if (i >= 0 && i < songs.size) onSongClick?.invoke(songs, i)
        }
        vh.more!!.setOnClickListener { anchor ->
            val i = vh.bindingAdapterPosition - headerCount()
            if (i < 0 || i >= songs.size) return@setOnClickListener
            val s = songs[i]
            PopupMenu(act, anchor).apply {
                menu.add(0, 1, 0, "Play Next")
                menu.add(0, 2, 1, "Add to Queue")
                setOnMenuItemClickListener { item ->
                    if (item.itemId == 1) Playback.playNext(act, s) else Playback.addToQueue(act, listOf(s))
                    true
                }
                show()
            }
        }
    }
}
