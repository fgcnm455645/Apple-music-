package com.glassmusic

import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** The Library tab: every song on the phone, directly. */
class LibraryPage(private val act: MainActivity) {
    private val rv = RecyclerView(act)
    private val adapter = SongAdapter(act, 72)
    val view: View get() = rv

    init {
        val title = TextView(act).apply {
            text = "Library"
            textSize = 40f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(act.dp(20), act.dp(84), act.dp(20), act.dp(10))
        }
        adapter.header = title
        adapter.onSongClick = { list, i -> Playback.play(act, list, i) }
        rv.layoutManager = LinearLayoutManager(act)
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.overScrollMode = View.OVER_SCROLL_NEVER
    }

    fun refresh() {
        adapter.submit(MusicRepository.sorted(Prefs.sortMode))
    }

    fun applyInsets() {
        rv.setPadding(0, act.topInset, 0, act.contentBottomPad())
    }
}
