package com.glassmusic

import android.graphics.Typeface
import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** The Library tab: every song on the phone, directly (hidden folders do not affect it). */
class LibraryPage(private val act: MainActivity) {
    private val rv = RecyclerView(act)
    private val adapter = SongAdapter(act, 73)
    val view: View get() = rv

    init {
        val title = TextView(act).apply {
            text = "Library"
            textSize = 40f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(act.dp(19), act.dp(84), act.dp(19), act.dp(10))
        }
        act.themed(this) { title.setTextColor(act.fg1()) }
        adapter.header = title
        adapter.onSongClick = { list, i -> Playback.play(act, list, i) }
        rv.layoutManager = LinearLayoutManager(act)
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.overScrollMode = View.OVER_SCROLL_NEVER
        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                act.onListScrolled(1, dy, recyclerView.computeVerticalScrollOffset())
            }
        })
    }

    fun refresh() {
        adapter.submit(MusicRepository.sorted(Prefs.sortMode))
    }

    fun retint() {
        adapter.notifyDataSetChanged()
    }

    fun offset(): Int = rv.computeVerticalScrollOffset()

    fun applyInsets() {
        rv.setPadding(0, act.topInset, 0, act.contentBottomPad())
    }
}
