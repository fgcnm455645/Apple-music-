package com.glassmusic

import android.graphics.Color
import androidx.core.graphics.ColorUtils

object ColorEngine {
    val DEFAULT: Int = Color.parseColor("#8A74B0")

    /** Returns [top, bottom] gradient colors derived from a cover color. */
    fun gradient(base: Int, dark: Boolean): IntArray {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(base, hsl)
        return if (dark) {
            val s = hsl[1].coerceIn(0.25f, 0.5f)
            intArrayOf(
                ColorUtils.HSLToColor(floatArrayOf(hsl[0], s, 0.24f)),
                ColorUtils.HSLToColor(floatArrayOf(hsl[0], s, 0.12f))
            )
        } else {
            val s = hsl[1].coerceIn(0.22f, 0.5f)
            intArrayOf(
                ColorUtils.HSLToColor(floatArrayOf(hsl[0], s, 0.52f)),
                ColorUtils.HSLToColor(floatArrayOf(hsl[0], s, 0.40f))
            )
        }
    }

    /** A darker accent of the cover color (used for text on white buttons). */
    fun accent(base: Int): Int {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(base, hsl)
        return ColorUtils.HSLToColor(floatArrayOf(hsl[0], hsl[1].coerceIn(0.3f, 0.7f), 0.30f))
    }
}
