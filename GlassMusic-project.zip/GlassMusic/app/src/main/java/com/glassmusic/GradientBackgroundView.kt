package com.glassmusic

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.core.graphics.ColorUtils

/** Full-size vertical gradient that animates between colors. */
class GradientBackgroundView(context: Context) : View(context) {
    private val paint = Paint()
    private var top = ColorEngine.DEFAULT
    private var bottom = ColorEngine.DEFAULT
    private var anim: ValueAnimator? = null

    fun setColors(newTop: Int, newBottom: Int, animate: Boolean) {
        anim?.cancel()
        if (!animate || width == 0) {
            top = newTop
            bottom = newBottom
            rebuild()
            invalidate()
            return
        }
        val fromTop = top
        val fromBottom = bottom
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700
            interpolator = DecelerateInterpolator()
            addUpdateListener { a ->
                val f = a.animatedFraction
                top = ColorUtils.blendARGB(fromTop, newTop, f)
                bottom = ColorUtils.blendARGB(fromBottom, newBottom, f)
                rebuild()
                invalidate()
            }
            start()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuild()
    }

    private fun rebuild() {
        paint.shader = LinearGradient(0f, 0f, 0f, height.toFloat(), top, bottom, Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }
}
