package com.glassmusic

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import com.example.liquidglass.LiquidGlassFab
import com.example.liquidglass.LiquidGlassTabBar
import com.example.liquidglass.LiquidGlassView
import android.content.res.ColorStateList

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var bg: GradientBackgroundView
    private lateinit var pagesHost: FrameLayout
    private lateinit var home: HomePage
    private lateinit var library: LibraryPage
    private lateinit var settings: SettingsPage
    private lateinit var miniPlayer: LiquidGlassView
    private lateinit var miniCover: ImageView
    private lateinit var miniTitle: TextView
    private lateinit var miniArtist: TextView
    private lateinit var miniPlay: ImageView
    private lateinit var tabBar: LiquidGlassTabBar
    private lateinit var searchFab: LiquidGlassFab
    private lateinit var sortFab: LiquidGlassFab
    private lateinit var permissionView: LinearLayout
    private lateinit var player: PlayerScreen

    private val glassViews = ArrayList<LiquidGlassView>()
    private val overlays = ArrayList<View>()

    var topInset = 0
        private set
    var bottomInset = 0
        private set
    var imeInset = 0
        private set

    private var songColor: Int? = null
    private var currentTab = 0
    private var loaded = false
    private var loading = false
    private var currentSongId = -1L

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { onPermissionResult() }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            updateMiniPlay()
            player.update()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            onSongChanged(songOf(mediaItem), true)
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            player.update()
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false

        buildUi()
        setContentView(root)
        applySystemBars()
        applyTheme(false)
        selectTab(0)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleBack()
            }
        })

        if (hasAudio()) loadMusic() else askPermissions()
    }

    override fun onResume() {
        super.onResume()
        if (!loaded && !loading && hasAudio()) {
            permissionView.visibility = View.GONE
            loadMusic()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyTheme(false)
    }

    override fun onDestroy() {
        Playback.controller?.removeListener(playerListener)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        root = FrameLayout(this)
        root.clipChildren = false

        bg = GradientBackgroundView(this)
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))

        pagesHost = FrameLayout(this)
        root.addView(pagesHost, FrameLayout.LayoutParams(-1, -1))
        home = HomePage(this)
        library = LibraryPage(this)
        settings = SettingsPage(this)
        pagesHost.addView(home.view, FrameLayout.LayoutParams(-1, -1))
        pagesHost.addView(library.view, FrameLayout.LayoutParams(-1, -1))
        pagesHost.addView(settings.view, FrameLayout.LayoutParams(-1, -1))

        buildPermissionView()
        buildMiniPlayer()
        buildBars()

        player = PlayerScreen(this)
        root.addView(player.view, FrameLayout.LayoutParams(-1, -1))
        player.view.visibility = View.GONE

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            topInset = bars.top
            bottomInset = bars.bottom
            imeInset = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            applyInsets()
            WindowInsetsCompat.CONSUMED
        }
        applyInsets()
    }

    private fun buildPermissionView() {
        val msg = TextView(this).apply {
            text = "Allow access to your music to see your songs"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        val btn = TextView(this).apply {
            text = "Allow access"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(14), dp(28), dp(14))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = 999f
            }
            setOnClickListener {
                if (shouldShowRequestPermissionRationale(audioPermission())) {
                    askPermissions()
                } else {
                    startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                    )
                }
            }
        }
        permissionView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(40), 0, dp(40), 0)
            addView(msg, LinearLayout.LayoutParams(-2, -2))
            addView(btn, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(24) })
            visibility = View.GONE
        }
        root.addView(permissionView, FrameLayout.LayoutParams(-1, -1))
    }

    private fun buildMiniPlayer() {
        miniPlayer = LiquidGlassView(this)
        registerGlass(miniPlayer)

        miniCover = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            round(dp(9).toFloat())
        }
        miniTitle = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        miniArtist = TextView(this).apply {
            setTextColor(Color.argb(190, 255, 255, 255))
            textSize = 13f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(miniTitle)
            addView(miniArtist)
        }
        miniPlay = ImageView(this).apply {
            setImageResource(R.drawable.ic_play)
            imageTintList = ColorStateList.valueOf(Color.WHITE)
            setPadding(dp(9), dp(9), dp(9), dp(9))
            setOnClickListener {
                val c = Playback.controller
                if (c != null) {
                    if (c.isPlaying) c.pause() else c.play()
                }
            }
        }
        val miniNext = ImageView(this).apply {
            setImageResource(R.drawable.ic_next)
            imageTintList = ColorStateList.valueOf(Color.WHITE)
            setPadding(dp(9), dp(9), dp(9), dp(9))
            setOnClickListener { Playback.controller?.seekToNext() }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(8), 0)
            addView(miniCover, LinearLayout.LayoutParams(dp(40), dp(40)))
            addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply {
                marginStart = dp(12)
                marginEnd = dp(6)
            })
            addView(miniPlay, LinearLayout.LayoutParams(dp(44), dp(44)))
            addView(miniNext, LinearLayout.LayoutParams(dp(44), dp(44)))
        }
        miniPlayer.addView(row, FrameLayout.LayoutParams(-1, -1))
        miniPlayer.setOnClickListener { player.show() }
        miniPlayer.visibility = View.GONE
        root.addView(miniPlayer, FrameLayout.LayoutParams(-1, dp(56), Gravity.BOTTOM))
    }

    private fun buildBars() {
        tabBar = LiquidGlassTabBar(this)
        registerGlass(tabBar)
        tabBar.setTabs(
            listOf(
                LiquidGlassTabBar.TabItem("Home", icon(R.drawable.ic_home)),
                LiquidGlassTabBar.TabItem("Library", icon(R.drawable.ic_library)),
                LiquidGlassTabBar.TabItem("Settings", icon(R.drawable.ic_settings))
            )
        )
        tabBar.selectedTintColor = Color.WHITE
        tabBar.onTabSelected = { selectTab(it) }
        root.addView(tabBar, FrameLayout.LayoutParams(dp(280), -2, Gravity.BOTTOM or Gravity.START))

        searchFab = LiquidGlassFab(this)
        registerGlass(searchFab)
        searchFab.setIconResource(R.drawable.ic_search)
        searchFab.setIconTint(Color.WHITE)
        searchFab.setOnClickListener { openSearch() }
        root.addView(searchFab, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.BOTTOM or Gravity.END))

        sortFab = LiquidGlassFab(this)
        registerGlass(sortFab)
        sortFab.setIconResource(R.drawable.ic_sort)
        sortFab.setIconTint(Color.WHITE)
        sortFab.setOnClickListener { showSortMenu() }
        sortFab.visibility = View.GONE
        root.addView(sortFab, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.TOP or Gravity.END))
    }

    private fun icon(res: Int) = ContextCompat.getDrawable(this, res)!!.mutate()

    private fun applyInsets() {
        val m = dp(19)
        val base = bottomInset + dp(12)
        (tabBar.layoutParams as FrameLayout.LayoutParams).apply {
            width = resources.displayMetrics.widthPixels - m * 2 - dp(64) - dp(8)
            marginStart = m
            bottomMargin = base
        }
        (searchFab.layoutParams as FrameLayout.LayoutParams).apply {
            marginEnd = m
            bottomMargin = base
        }
        (miniPlayer.layoutParams as FrameLayout.LayoutParams).apply {
            marginStart = m
            marginEnd = m
            bottomMargin = base + dp(64) + dp(8)
        }
        (sortFab.layoutParams as FrameLayout.LayoutParams).apply {
            marginEnd = m
            topMargin = topInset + dp(14)
        }
        tabBar.requestLayout()
        searchFab.requestLayout()
        miniPlayer.requestLayout()
        sortFab.requestLayout()

        home.applyInsets()
        library.applyInsets()
        settings.applyInsets()
        player.applyInsets()
        overlays.forEach { (it as? InsetsAware)?.applyInsets() }
    }

    /** Bottom padding that keeps list content clear of the floating bars. */
    fun contentBottomPad(): Int = bottomInset + dp(12) + dp(64) + dp(8) + dp(56) + dp(24)

    // ---------------------------------------------------------------- theme

    fun isDark(): Boolean =
        if (Prefs.useSystemTheme) {
            (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        } else {
            Prefs.darkMode
        }

    private fun baseColor(): Int =
        if (Prefs.dynamicTheme) (songColor ?: ColorEngine.DEFAULT) else ColorEngine.DEFAULT

    fun currentGradient(): IntArray = ColorEngine.gradient(baseColor(), isDark())

    private fun glassTintColor(): Int {
        val g = currentGradient()
        return ColorUtils.setAlphaComponent(ColorUtils.blendARGB(g[0], Color.WHITE, 0.3f), 0x38)
    }

    fun styleGlass(v: LiquidGlassView) {
        v.enableDynamicBackground = true
        v.collectFrameStats = false
        v.useShaderPipeline = Prefs.liquidGlass
        v.glassTint = glassTintColor()
    }

    private fun registerGlass(v: LiquidGlassView) {
        styleGlass(v)
        glassViews.add(v)
    }

    fun applyTheme(animate: Boolean = true) {
        val g = currentGradient()
        bg.setColors(g[0], g[1], animate)
        player.setColors(g[0], g[1], animate)
        val tint = glassTintColor()
        glassViews.forEach {
            it.glassTint = tint
            it.useShaderPipeline = Prefs.liquidGlass
        }
    }

    fun applySystemBars() {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.isAppearanceLightStatusBars = false
        c.isAppearanceLightNavigationBars = false
        if (Prefs.hideStatusBar) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.statusBars())
        } else {
            c.show(WindowInsetsCompat.Type.statusBars())
        }
    }

    // ---------------------------------------------------------------- navigation

    private fun selectTab(i: Int) {
        currentTab = i
        home.view.visibility = if (i == 0) View.VISIBLE else View.GONE
        library.view.visibility = if (i == 1) View.VISIBLE else View.GONE
        settings.view.visibility = if (i == 2) View.VISIBLE else View.GONE
        updateSortVisibility()
    }

    private fun updateSortVisibility() {
        sortFab.visibility =
            if (currentTab == 1 && overlays.isEmpty() && !player.isOpen) View.VISIBLE else View.GONE
    }

    private fun handleBack() {
        when {
            player.isOpen -> player.hide()
            overlays.isNotEmpty() -> popOverlay()
            currentTab != 0 -> tabBar.selectedIndex = 0
            else -> finish()
        }
    }

    fun pushOverlay(v: View) {
        root.addView(v, root.indexOfChild(miniPlayer), FrameLayout.LayoutParams(-1, -1))
        overlays.add(v)
        v.translationX = resources.displayMetrics.widthPixels.toFloat()
        v.animate().translationX(0f).setDuration(300).setInterpolator(DecelerateInterpolator()).start()
        updateSortVisibility()
    }

    fun popOverlay() {
        if (overlays.isEmpty()) return
        val v = overlays.removeAt(overlays.size - 1)
        WindowCompat.getInsetsController(window, root).hide(WindowInsetsCompat.Type.ime())
        updateSortVisibility()
        v.animate()
            .translationX(resources.displayMetrics.widthPixels.toFloat())
            .setDuration(250)
            .withEndAction { root.removeView(v) }
            .start()
    }

    fun openFolder(folder: Folder) {
        pushOverlay(FolderPage(this, folder))
    }

    private fun openSearch() {
        pushOverlay(
            ListPage(this, "Search", MusicRepository.sorted(0), true) { list, i ->
                Playback.play(this, list, i)
            }
        )
    }

    fun openQueue() {
        val c = Playback.controller ?: return
        val list = ArrayList<Song>()
        for (i in 0 until c.mediaItemCount) {
            val s = songOf(c.getMediaItemAt(i))
            if (s != null) list.add(s)
        }
        player.hide()
        pushOverlay(
            ListPage(this, "Up Next", list, false) { _, i ->
                c.seekToDefaultPosition(i)
                c.play()
            }
        )
    }

    fun onPlayerClosed() {
        updateSortVisibility()
    }

    private fun showSortMenu() {
        PopupMenu(this, sortFab).apply {
            menu.add(0, 0, 0, "Title")
            menu.add(0, 1, 1, "Artist")
            menu.add(0, 2, 2, "Recently Added")
            setOnMenuItemClickListener {
                Prefs.sortMode = it.itemId
                library.refresh()
                true
            }
            show()
        }
    }

    // ---------------------------------------------------------------- permission + data

    private fun audioPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudio(): Boolean =
        ContextCompat.checkSelfPermission(this, audioPermission()) == PackageManager.PERMISSION_GRANTED

    private fun askPermissions() {
        val perms = ArrayList<String>()
        perms.add(audioPermission())
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(perms.toTypedArray())
    }

    private fun onPermissionResult() {
        if (hasAudio()) {
            permissionView.visibility = View.GONE
            loadMusic()
        } else {
            permissionView.visibility = View.VISIBLE
        }
    }

    private fun loadMusic() {
        if (loading) return
        loading = true
        Thread {
            var ok = true
            try {
                MusicRepository.load(applicationContext)
            } catch (e: Exception) {
                ok = false
            }
            runOnUiThread {
                loading = false
                loaded = ok
                home.refresh()
                library.refresh()
                connectPlayback()
            }
        }.start()
    }

    // ---------------------------------------------------------------- playback state

    fun songOf(item: MediaItem?): Song? =
        item?.mediaId?.toLongOrNull()?.let { MusicRepository.byId[it] }

    fun currentSong(): Song? = songOf(Playback.controller?.currentMediaItem)

    private fun connectPlayback() {
        Playback.whenReady(this) { c ->
            c.removeListener(playerListener)
            c.addListener(playerListener)
            onSongChanged(songOf(c.currentMediaItem), false)
            updateMiniPlay()
        }
    }

    private fun updateMiniPlay() {
        val playing = Playback.controller?.isPlaying == true
        miniPlay.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun onSongChanged(song: Song?, record: Boolean) {
        if (song == null) {
            currentSongId = -1L
            songColor = null
            miniPlayer.visibility = View.GONE
            applyTheme(true)
            return
        }
        currentSongId = song.id
        miniPlayer.visibility = View.VISIBLE
        miniTitle.text = song.title
        miniArtist.text = song.artist
        CoverLoader.load(this, song, dp(48), miniCover)
        CoverLoader.color(this, song) { c ->
            if (currentSongId == song.id) {
                songColor = c
                applyTheme(true)
            }
        }
        if (record) {
            Prefs.addRecent(song.id)
            home.refresh()
        }
        player.update()
    }
}
