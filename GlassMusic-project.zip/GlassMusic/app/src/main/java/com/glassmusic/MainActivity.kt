package com.glassmusic

import android.Manifest
import android.animation.ValueAnimator
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import com.example.liquidglass.LiquidGlassFab
import com.example.liquidglass.LiquidGlassTabBar
import com.example.liquidglass.LiquidGlassView

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var bg: GradientBackgroundView
    private lateinit var pagesHost: FrameLayout
    private lateinit var home: HomePage
    private lateinit var library: LibraryPage
    private lateinit var settings: SettingsPage
    private lateinit var miniPlayer: LiquidGlassView
    private lateinit var miniCover: ImageView
    private lateinit var miniTitle: TextView
    private lateinit var miniArtist: TextView
    private lateinit var miniPlay: ImageView
    private lateinit var miniPrev: ImageView
    private lateinit var miniNext: ImageView
    private lateinit var tabBar: LiquidGlassTabBar
    private lateinit var miniTab: LiquidGlassFab
    private lateinit var searchFab: LiquidGlassFab
    private lateinit var sortFab: LiquidGlassFab
    private lateinit var profileFab: LiquidGlassFab
    private lateinit var topTitle: TextView
    private lateinit var permissionView: LinearLayout
    private lateinit var player: PlayerScreen

    private val glassViews = ArrayList<LiquidGlassView>()
    private val overlays = ArrayList<View>()
    private val themeBlocks = HashMap<Any, ArrayList<() -> Unit>>()

    var topInset = 0
        private set
    var bottomInset = 0
        private set
    var imeInset = 0
        private set

    private var songColor: Int? = null
    private var currentTab = 0
    private var loaded = false
    private var loading = false
    private var currentSongId = -1L

    private var collapsed = false
    private var barsProgress = 0f
    private var barsAnimator: ValueAnimator? = null

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { onPermissionResult() }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            updateMiniPlay()
            player.update()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            onSongChanged(songOf(mediaItem), true)
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            player.update()
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false

        buildUi()
        setContentView(root)
        applySystemBars()
        applyTheme(false)
        selectTab(0)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleBack()
            }
        })

        if (hasAudio()) loadMusic() else askPermissions()
    }

    override fun onResume() {
        super.onResume()
        if (!loaded && !loading && hasAudio()) {
            permissionView.visibility = View.GONE
            loadMusic()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyTheme(false)
    }

    override fun onDestroy() {
        Playback.controller?.removeListener(playerListener)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- theme colors

    fun isDark(): Boolean =
        if (Prefs.useSystemTheme) {
            (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        } else {
            Prefs.darkMode
        }

    private fun dynamicActive(): Boolean = Prefs.dynamicTheme && songColor != null

    /** True when the background is the plain light theme (dark text and icons on top). */
    fun onLightBg(): Boolean = !isDark() && !dynamicActive()

    fun fg1(): Int = if (onLightBg()) 0xFF111114.toInt() else Color.WHITE
    fun fg2(): Int = if (onLightBg()) 0x99111114.toInt() else 0xB3FFFFFF.toInt()
    fun fgDivider(): Int = if (onLightBg()) 0x22000000 else 0x33FFFFFF
    fun surface(): Int = if (onLightBg()) 0xB3FFFFFF.toInt() else 0x26FFFFFF

    fun songColorOrNull(): Int? = songColor

    fun currentGradient(): IntArray {
        val c = songColor
        return if (Prefs.dynamicTheme && c != null) {
            ColorEngine.gradient(c, isDark())
        } else if (isDark()) {
            intArrayOf(0xFF000000.toInt(), 0xFF000000.toInt())
        } else {
            intArrayOf(0xFFF3F3F8.toInt(), 0xFFD8D8E4.toInt())
        }
    }

    private fun glassTintColor(): Int {
        if (onLightBg()) return 0x66FFFFFF
        val g = currentGradient()
        return ColorUtils.setAlphaComponent(ColorUtils.blendARGB(g[0], Color.WHITE, 0.3f), 0x38)
    }

    fun themed(owner: Any, block: () -> Unit) {
        block()
        themeBlocks.getOrPut(owner) { ArrayList() }.add(block)
    }

    fun dropThemed(owner: Any) {
        themeBlocks.remove(owner)
    }

    fun styleGlass(v: LiquidGlassView) {
        v.enableDynamicBackground = true
        v.collectFrameStats = false
        v.useShaderPipeline = Prefs.liquidGlass
        v.glassTint = glassTintColor()
    }

    private fun registerGlass(v: LiquidGlassView) {
        styleGlass(v)
        glassViews.add(v)
    }

    /** Creates a glass circle button whose icon glyph is [glyphDp] wide inside a [sizeDp] circle. */
    fun makeFab(iconRes: Int, glyphDp: Int, sizeDp: Int): LiquidGlassFab {
        val fab = LiquidGlassFab(this)
        styleGlass(fab)
        fab.setIconResource(iconRes)
        fab.imageView.layoutParams = FrameLayout.LayoutParams(dp(glyphDp), dp(glyphDp), Gravity.CENTER)
        fab.minimumWidth = dp(sizeDp)
        fab.minimumHeight = dp(sizeDp)
        return fab
    }

    fun applyTheme(animate: Boolean = true) {
        val g = currentGradient()
        bg.setColors(g[0], g[1], animate)
        val tint = glassTintColor()
        glassViews.forEach {
            it.glassTint = tint
            it.useShaderPipeline = Prefs.liquidGlass
        }
        ArrayList(themeBlocks.values).forEach { list -> ArrayList(list).forEach { it() } }
        home.retint()
        library.retint()
        settings.retint()
        overlays.forEach { (it as? InsetsAware)?.retint() }
        player.refreshBackground(animate)
        topTitle.setTextColor(fg1())
        miniTitle.setTextColor(fg1())
        miniArtist.setTextColor(fg2())
        val iconTint = ColorStateList.valueOf(fg1())
        listOf(miniPlay, miniPrev, miniNext).forEach { it.imageTintList = iconTint }
    }

    fun refreshPlayerBackground() {
        player.refreshBackground(true)
    }

    fun refreshHome() {
        home.refresh()
    }

    fun applySystemBars() {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.isAppearanceLightStatusBars = onLightBg()
        c.isAppearanceLightNavigationBars = onLightBg()
        if (Prefs.hideStatusBar) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.statusBars())
        } else {
            c.show(WindowInsetsCompat.Type.statusBars())
        }
    }

    // ---------------------------------------------------------------- UI construction

    private fun buildUi() {
        root = FrameLayout(this)
        root.clipChildren = false

        bg = GradientBackgroundView(this)
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))

        pagesHost = FrameLayout(this)
        root.addView(pagesHost, FrameLayout.LayoutParams(-1, -1))
        home = HomePage(this)
        library = LibraryPage(this)
        settings = SettingsPage(this)
        pagesHost.addView(home.view, FrameLayout.LayoutParams(-1, -1))
        pagesHost.addView(library.view, FrameLayout.LayoutParams(-1, -1))
        pagesHost.addView(settings.view, FrameLayout.LayoutParams(-1, -1))

        buildPermissionView()
        buildMiniPlayer()
        buildBars()

        player = PlayerScreen(this)
        root.addView(player.view, FrameLayout.LayoutParams(-1, -1))
        player.view.visibility = View.GONE

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            topInset = bars.top
            bottomInset = bars.bottom
            imeInset = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            applyInsets()
            WindowInsetsCompat.CONSUMED
        }
        applyInsets()
    }

    private fun buildPermissionView() {
        val msg = TextView(this)
        msg.text = "Allow access to your music to see your songs"
        msg.textSize = 18f
        msg.gravity = Gravity.CENTER
        themed(msg) { msg.setTextColor(fg1()) }
        val btn = TextView(this)
        btn.text = "Allow access"
        btn.textSize = 17f
        btn.typeface = Typeface.DEFAULT_BOLD
        btn.setTextColor(Color.BLACK)
        btn.gravity = Gravity.CENTER
        btn.setPadding(dp(28), dp(14), dp(28), dp(14))
        btn.background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = 999f
        }
        btn.setOnClickListener {
            if (shouldShowRequestPermissionRationale(audioPermission())) {
                askPermissions()
            } else {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        }
        permissionView = LinearLayout(this)
        permissionView.orientation = LinearLayout.VERTICAL
        permissionView.gravity = Gravity.CENTER
        permissionView.setPadding(dp(40), 0, dp(40), 0)
        permissionView.addView(msg, LinearLayout.LayoutParams(-2, -2))
        permissionView.addView(btn, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(24) })
        permissionView.visibility = View.GONE
        root.addView(permissionView, FrameLayout.LayoutParams(-1, -1))
    }

    private fun smallIcon(res: Int, glyphDp: Int, onClick: () -> Unit): ImageView {
        val v = ImageView(this)
        v.setImageResource(res)
        val pad = (dp(44) - dp(glyphDp)) / 2
        v.setPadding(pad, pad, pad, pad)
        v.setOnClickListener { onClick() }
        return v
    }

    private fun buildMiniPlayer() {
        miniPlayer = LiquidGlassView(this)
        registerGlass(miniPlayer)

        miniCover = ImageView(this)
        miniCover.scaleType = ImageView.ScaleType.CENTER_CROP
        miniCover.round(dp(8).toFloat())
        miniTitle = TextView(this)
        miniTitle.textSize = 16f
        miniTitle.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        miniTitle.maxLines = 1
        miniTitle.ellipsize = TextUtils.TruncateAt.END
        miniArtist = TextView(this)
        miniArtist.textSize = 14f
        miniArtist.maxLines = 1
        miniArtist.ellipsize = TextUtils.TruncateAt.END
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.addView(miniTitle)
        texts.addView(miniArtist)

        miniPrev = smallIcon(R.drawable.ic_cu_rewind, 24) { Playback.controller?.seekToPrevious() }
        miniPlay = smallIcon(R.drawable.ic_cu_play, 21) {
            val c = Playback.controller
            if (c != null) {
                if (c.isPlaying) c.pause() else c.play()
            }
        }
        miniNext = smallIcon(R.drawable.ic_cu_forward, 24) { Playback.controller?.seekToNext() }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(20), 0, dp(6), 0)
        row.addView(miniCover, LinearLayout.LayoutParams(dp(34), dp(34)))
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply {
            marginStart = dp(9)
            marginEnd = dp(4)
        })
        row.addView(miniPrev, LinearLayout.LayoutParams(dp(44), dp(44)))
        row.addView(miniPlay, LinearLayout.LayoutParams(dp(44), dp(44)))
        row.addView(miniNext, LinearLayout.LayoutParams(dp(44), dp(44)))
        miniPlayer.addView(row, FrameLayout.LayoutParams(-1, -1))
        miniPlayer.setOnClickListener { player.show() }
        miniPlayer.visibility = View.GONE
        root.addView(miniPlayer, FrameLayout.LayoutParams(-1, dp(53), Gravity.BOTTOM))
    }

    private fun tabIcon(res: Int, glyphDp: Int, boxDp: Int) =
        PaddedIcon(ContextCompat.getDrawable(this, res)!!.mutate(), glyphDp.toFloat() / boxDp)

    private fun buildBars() {
        val box = 36
        tabBar = LiquidGlassTabBar(this)
        registerGlass(tabBar)
        tabBar.tabIconBoxDp = box
        tabBar.setTabs(
            listOf(
                LiquidGlassTabBar.TabItem("Home", tabIcon(R.drawable.ic_fa_house, 35, box)),
                LiquidGlassTabBar.TabItem("Library", tabIcon(R.drawable.ic_cu_albums, 34, box)),
                LiquidGlassTabBar.TabItem("Settings", tabIcon(R.drawable.ic_cu_gear, 31, box))
            )
        )
        tabBar.onTabSelected = { selectTab(it) }
        root.addView(tabBar, FrameLayout.LayoutParams(dp(285), dp(78), Gravity.BOTTOM or Gravity.START))

        // small circle that replaces the tab bar when it is collapsed
        miniTab = makeFab(R.drawable.ic_fa_house, 22, 46)
        glassViews.add(miniTab)
        miniTab.setOnClickListener { setCollapsed(false) }
        miniTab.alpha = 0f
        miniTab.visibility = View.GONE
        root.addView(miniTab, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.BOTTOM or Gravity.START))

        searchFab = makeFab(R.drawable.ic_cu_search, 24, 78)
        glassViews.add(searchFab)
        searchFab.setOnClickListener { openSearch() }
        root.addView(searchFab, FrameLayout.LayoutParams(dp(78), dp(78), Gravity.BOTTOM or Gravity.END))

        sortFab = makeFab(R.drawable.ic_cu_filter, 27, 61)
        glassViews.add(sortFab)
        sortFab.setOnClickListener { showSortMenu() }
        sortFab.visibility = View.GONE
        root.addView(sortFab, FrameLayout.LayoutParams(dp(61), dp(61), Gravity.TOP or Gravity.END))

        profileFab = makeFab(R.drawable.ic_cu_person, 26, 61)
        glassViews.add(profileFab)
        profileFab.setOnClickListener { tabBar.selectedIndex = 2 }
        root.addView(profileFab, FrameLayout.LayoutParams(dp(61), dp(61), Gravity.TOP or Gravity.END))

        topTitle = TextView(this)
        topTitle.textSize = 18f
        topTitle.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        topTitle.gravity = Gravity.CENTER
        topTitle.alpha = 0f
        root.addView(topTitle, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
    }

    // ---------------------------------------------------------------- layout + bars animation

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    private fun topButtonsMargin(): Int = maxOf(topInset + dp(10), dp(43))

    private fun bottomBase(): Int = maxOf(bottomInset + dp(10), dp(45))

    private fun applyInsets() {
        val m = dp(19)
        val top = topButtonsMargin()
        (sortFab.layoutParams as FrameLayout.LayoutParams).apply { marginEnd = m; topMargin = top }
        (profileFab.layoutParams as FrameLayout.LayoutParams).apply { marginEnd = m; topMargin = top }
        (topTitle.layoutParams as FrameLayout.LayoutParams).topMargin = top + dp(16)
        sortFab.requestLayout()
        profileFab.requestLayout()
        topTitle.requestLayout()
        applyBarsProgress(barsProgress)

        home.applyInsets()
        library.applyInsets()
        settings.applyInsets()
        player.applyInsets()
        overlays.forEach { (it as? InsetsAware)?.applyInsets() }
    }

    /** Bottom padding that keeps list content clear of the floating bars. */
    fun contentBottomPad(): Int = bottomBase() + dp(78) + dp(8) + dp(53) + dp(24)

    /** p = 0: full bars, p = 1: collapsed (tab circle, mini player in the middle, small search). */
    private fun applyBarsProgress(p: Float) {
        barsProgress = p
        val m = dp(19)
        val gap = dp(10)
        val base = bottomBase()
        val screenW = resources.displayMetrics.widthPixels
        val fullBar = screenW - m * 2 - dp(78) - gap
        val circle = dp(46)

        (tabBar.layoutParams as FrameLayout.LayoutParams).apply {
            width = lerp(fullBar.toFloat(), circle.toFloat(), p).toInt()
            height = lerp(dp(78).toFloat(), circle.toFloat(), p).toInt()
            marginStart = m
            bottomMargin = base
        }
        tabBar.alpha = (1f - p * 2.2f).coerceIn(0f, 1f)
        tabBar.visibility = if (tabBar.alpha <= 0f) View.INVISIBLE else View.VISIBLE
        tabBar.requestLayout()

        (miniTab.layoutParams as FrameLayout.LayoutParams).apply {
            marginStart = m
            bottomMargin = base
        }
        miniTab.alpha = ((p - 0.5f) * 2f).coerceIn(0f, 1f)
        miniTab.visibility = if (miniTab.alpha <= 0f) View.GONE else View.VISIBLE
        miniTab.requestLayout()

        (searchFab.layoutParams as FrameLayout.LayoutParams).apply {
            val s = lerp(dp(78).toFloat(), circle.toFloat(), p).toInt()
            width = s
            height = s
            marginEnd = m
            bottomMargin = base
        }
        searchFab.requestLayout()

        (miniPlayer.layoutParams as FrameLayout.LayoutParams).apply {
            marginStart = m + lerp(0f, (circle + dp(8)).toFloat(), p).toInt()
            marginEnd = m + lerp(0f, (circle + dp(8)).toFloat(), p).toInt()
            height = lerp(dp(53).toFloat(), circle.toFloat(), p).toInt()
            bottomMargin = lerp((base + dp(78) + dp(8)).toFloat(), base.toFloat(), p).toInt()
        }
        miniPlayer.requestLayout()
        val extra = (1f - p * 2f).coerceIn(0f, 1f)
        miniPrev.alpha = extra
        miniNext.alpha = extra
        miniPrev.visibility = if (extra <= 0f) View.GONE else View.VISIBLE
        miniNext.visibility = if (extra <= 0f) View.GONE else View.VISIBLE
    }

    fun setCollapsed(value: Boolean) {
        if (collapsed == value) return
        collapsed = value
        barsAnimator?.cancel()
        val from = barsProgress
        val to = if (value) 1f else 0f
        barsAnimator = ValueAnimator.ofFloat(from, to).apply {
            duration = 340
            interpolator = DecelerateInterpolator()
            addUpdateListener { a -> applyBarsProgress(a.animatedValue as Float) }
            start()
        }
    }

    /** Called by every scrolling list. [source] is the tab index, or -1 for pushed pages. */
    fun onListScrolled(source: Int, dy: Int, offset: Int) {
        if (source == currentTab && overlays.isEmpty()) updateTopTitle(offset)
        if (!Prefs.collapseBars) return
        if (offset <= dp(8)) {
            setCollapsed(false)
        } else if (dy > dp(2)) {
            setCollapsed(true)
        } else if (dy < -dp(2)) {
            setCollapsed(false)
        }
    }

    private fun updateTopTitle(offset: Int) {
        val start = dp(70).toFloat()
        topTitle.alpha = ((offset - start) / dp(40)).coerceIn(0f, 1f)
    }

    // ---------------------------------------------------------------- navigation

    private fun selectTab(i: Int) {
        currentTab = i
        home.view.visibility = if (i == 0) View.VISIBLE else View.GONE
        library.view.visibility = if (i == 1) View.VISIBLE else View.GONE
        settings.view.visibility = if (i == 2) View.VISIBLE else View.GONE
        topTitle.text = when (i) {
            0 -> "Listen Now"
            1 -> "Library"
            else -> "Settings"
        }
        val tabIcon = when (i) {
            0 -> R.drawable.ic_fa_house
            1 -> R.drawable.ic_cu_albums
            else -> R.drawable.ic_cu_gear
        }
        miniTab.setIconResource(tabIcon)
        val off = when (i) {
            0 -> home.offset()
            1 -> library.offset()
            else -> settings.offset()
        }
        updateTopTitle(off)
        if (off <= dp(8)) setCollapsed(false)
        updateTopButtons()
    }

    private fun updateTopButtons() {
        val free = overlays.isEmpty() && !player.isOpen
        sortFab.visibility = if (currentTab == 1 && free) View.VISIBLE else View.GONE
        profileFab.visibility = if (currentTab == 0 && free) View.VISIBLE else View.GONE
        topTitle.visibility = if (free) View.VISIBLE else View.GONE
    }

    private fun handleBack() {
        when {
            player.isOpen -> player.hide()
            overlays.isNotEmpty() -> popOverlay()
            currentTab != 0 -> tabBar.selectedIndex = 0
            else -> finish()
        }
    }

    fun pushOverlay(v: View) {
        root.addView(v, root.indexOfChild(miniPlayer), FrameLayout.LayoutParams(-1, -1))
        overlays.add(v)
        v.translationX = resources.displayMetrics.widthPixels.toFloat()
        v.animate().translationX(0f).setDuration(300).setInterpolator(DecelerateInterpolator()).start()
        updateTopButtons()
    }

    fun popOverlay() {
        if (overlays.isEmpty()) return
        val v = overlays.removeAt(overlays.size - 1)
        WindowCompat.getInsetsController(window, root).hide(WindowInsetsCompat.Type.ime())
        updateTopButtons()
        v.animate()
            .translationX(resources.displayMetrics.widthPixels.toFloat())
            .setDuration(250)
            .withEndAction {
                (v as? InsetsAware)?.onRemoved()
                root.removeView(v)
            }
            .start()
    }

    fun openFolder(folder: Folder) {
        pushOverlay(FolderPage(this, folder))
    }

    private fun openSearch() {
        pushOverlay(
            ListPage(this, "Search", MusicRepository.sorted(0), true) { list, i ->
                Playback.play(this, list, i)
            }
        )
    }

    fun openQueue() {
        val c = Playback.controller ?: return
        val list = ArrayList<Song>()
        for (i in 0 until c.mediaItemCount) {
            val s = songOf(c.getMediaItemAt(i))
            if (s != null) list.add(s)
        }
        player.hide()
        pushOverlay(
            ListPage(this, "Up Next", list, false) { _, i ->
                c.seekToDefaultPosition(i)
                c.play()
            }
        )
    }

    fun onPlayerClosed() {
        updateTopButtons()
    }

    private fun showSortMenu() {
        PopupMenu(this, sortFab).apply {
            menu.add(0, 0, 0, "Title")
            menu.add(0, 1, 1, "Artist")
            menu.add(0, 2, 2, "Recently Added")
            setOnMenuItemClickListener {
                Prefs.sortMode = it.itemId
                library.refresh()
                true
            }
            show()
        }
    }

    // ---------------------------------------------------------------- permission + data

    private fun audioPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudio(): Boolean =
        ContextCompat.checkSelfPermission(this, audioPermission()) == PackageManager.PERMISSION_GRANTED

    private fun askPermissions() {
        val perms = ArrayList<String>()
        perms.add(audioPermission())
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(perms.toTypedArray())
    }

    private fun onPermissionResult() {
        if (hasAudio()) {
            permissionView.visibility = View.GONE
            loadMusic()
        } else {
            permissionView.visibility = View.VISIBLE
        }
    }

    private fun loadMusic() {
        if (loading) return
        loading = true
        Thread {
            var ok = true
            try {
                MusicRepository.load(applicationContext)
            } catch (e: Exception) {
                ok = false
            }
            runOnUiThread {
                loading = false
                loaded = ok
                home.refresh()
                library.refresh()
                connectPlayback()
            }
        }.start()
    }

    // ---------------------------------------------------------------- playback state

    fun songOf(item: MediaItem?): Song? =
        item?.mediaId?.toLongOrNull()?.let { MusicRepository.byId[it] }

    fun currentSong(): Song? = songOf(Playback.controller?.currentMediaItem)

    private fun connectPlayback() {
        Playback.whenReady(this) { c ->
            c.removeListener(playerListener)
            c.addListener(playerListener)
            onSongChanged(songOf(c.currentMediaItem), false)
            updateMiniPlay()
        }
    }

    private fun updateMiniPlay() {
        val playing = Playback.controller?.isPlaying == true
        miniPlay.setImageResource(if (playing) R.drawable.ic_cu_pause else R.drawable.ic_cu_play)
    }

    private fun onSongChanged(song: Song?, record: Boolean) {
        if (song == null) {
            currentSongId = -1L
            songColor = null
            miniPlayer.visibility = View.GONE
            applyTheme(true)
            return
        }
        currentSongId = song.id
        miniPlayer.visibility = View.VISIBLE
        miniTitle.text = song.title
        miniArtist.text = song.artist
        CoverLoader.load(this, song, dp(48), miniCover)
        CoverLoader.color(this, song) { c ->
            if (currentSongId == song.id) {
                songColor = c
                applyTheme(true)
                applySystemBars()
            }
        }
        if (record) Prefs.addRecent(song.id)
        player.update()
    }
}
