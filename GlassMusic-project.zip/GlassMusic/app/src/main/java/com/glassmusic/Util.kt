package com.glassmusic

import android.content.Context
import android.graphics.Outline
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.ImageView

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun View.round(radiusPx: Float) {
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }
    clipToOutline = true
}

fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

/** ImageView that is always as tall as it is wide. */
class SquareImageView(context: Context) : ImageView(context) {
    init {
        scaleType = ScaleType.CENTER_CROP
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, widthMeasureSpec)
        val m = measuredWidth
        setMeasuredDimension(m, m)
    }
}

/** Draws [inner] centered inside its bounds at [fraction] of the box (used to size glyphs inside tab icons). */
class PaddedIcon(private val inner: android.graphics.drawable.Drawable, private val fraction: Float) :
    android.graphics.drawable.Drawable() {

    override fun draw(canvas: android.graphics.Canvas) {
        val b = bounds
        val w = (b.width() * fraction).toInt()
        val h = (b.height() * fraction).toInt()
        val l = b.left + (b.width() - w) / 2
        val t = b.top + (b.height() - h) / 2
        inner.setBounds(l, t, l + w, t + h)
        inner.draw(canvas)
    }

    override fun setAlpha(alpha: Int) {
        inner.alpha = alpha
    }

    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
        inner.colorFilter = colorFilter
    }

    override fun setTintList(tint: android.content.res.ColorStateList?) {
        inner.setTintList(tint)
    }

    override fun setTintMode(tintMode: android.graphics.PorterDuff.Mode?) {
        inner.setTintMode(tintMode)
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT

    override fun getIntrinsicWidth(): Int = 100
    override fun getIntrinsicHeight(): Int = 100
}
