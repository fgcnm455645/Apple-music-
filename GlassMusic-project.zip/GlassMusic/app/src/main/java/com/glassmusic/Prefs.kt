package com.glassmusic

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(context: Context) {
        if (!::sp.isInitialized) {
            sp = context.applicationContext.getSharedPreferences("glassmusic", Context.MODE_PRIVATE)
        }
    }

    var dynamicTheme: Boolean
        get() = sp.getBoolean("dynamic", true)
        set(v) { sp.edit().putBoolean("dynamic", v).apply() }

    var darkMode: Boolean
        get() = sp.getBoolean("dark", false)
        set(v) { sp.edit().putBoolean("dark", v).apply() }

    var useSystemTheme: Boolean
        get() = sp.getBoolean("system", false)
        set(v) { sp.edit().putBoolean("system", v).apply() }

    var liquidGlass: Boolean
        get() = sp.getBoolean("glass", true)
        set(v) { sp.edit().putBoolean("glass", v).apply() }

    var hideStatusBar: Boolean
        get() = sp.getBoolean("hidebar", false)
        set(v) { sp.edit().putBoolean("hidebar", v).apply() }

    var sortMode: Int
        get() = sp.getInt("sort", 0)
        set(v) { sp.edit().putInt("sort", v).apply() }

    var recents: List<Long>
        get() = (sp.getString("recents", "") ?: "").split(',').mapNotNull { it.toLongOrNull() }
        set(v) { sp.edit().putString("recents", v.joinToString(",")).apply() }

    fun addRecent(id: Long) {
        val list = recents.toMutableList()
        list.remove(id)
        list.add(0, id)
        recents = list.take(12)
    }
}
