package com.glassmusic

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.liquidglass.LiquidGlassFab

interface InsetsAware {
    fun applyInsets()
}

private fun circleBackground(color: Int) = GradientDrawable().apply {
    shape = GradientDrawable.OVAL
    setColor(color)
}

/** Plain song list pushed on top of the tabs: search results or the play queue. */
class ListPage(
    private val act: MainActivity,
    titleText: String,
    songs: List<Song>,
    private val search: Boolean,
    onClick: (List<Song>, Int) -> Unit
) : FrameLayout(act), InsetsAware {

    private val bgv = GradientBackgroundView(act)
    private val rv = RecyclerView(act)
    private val adapter = SongAdapter(act, 56)
    private val back = LiquidGlassFab(act)
    private val all = songs
    private var searchField: EditText? = null

    init {
        val g = act.currentGradient()
        bgv.setColors(g[0], g[1], false)
        addView(bgv, LayoutParams(-1, -1))

        val header = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(act.dp(20), act.dp(6), act.dp(20), act.dp(12))
            addView(TextView(act).apply {
                text = titleText
                textSize = 34f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            })
        }
        if (search) {
            val et = EditText(act).apply {
                hint = "Songs, artists, albums"
                setHintTextColor(Color.argb(150, 255, 255, 255))
                setTextColor(Color.WHITE)
                textSize = 17f
                isSingleLine = true
                imeOptions = EditorInfo.IME_ACTION_SEARCH
                background = GradientDrawable().apply {
                    setColor(Color.argb(60, 255, 255, 255))
                    cornerRadius = 999f
                }
                setPadding(act.dp(18), act.dp(12), act.dp(18), act.dp(12))
                doAfterTextChanged { filter(it?.toString().orEmpty()) }
            }
            searchField = et
            header.addView(et, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(10) })
        }

        adapter.header = header
        adapter.onSongClick = onClick
        adapter.submit(songs)
        rv.layoutManager = LinearLayoutManager(act)
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.overScrollMode = OVER_SCROLL_NEVER
        addView(rv, LayoutParams(-1, -1))

        act.styleGlass(back)
        back.setIconResource(R.drawable.ic_back)
        back.setIconTint(Color.WHITE)
        back.setOnClickListener { act.popOverlay() }
        addView(back, LayoutParams(act.dp(56), act.dp(56), Gravity.TOP or Gravity.START))

        applyInsets()

        if (search) {
            rv.postDelayed({
                searchField?.requestFocus()
                val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(searchField, InputMethodManager.SHOW_IMPLICIT)
            }, 350)
        }
    }

    private fun filter(q: String) {
        val t = q.trim().lowercase()
        adapter.submit(
            if (t.isEmpty()) all
            else all.filter {
                it.title.lowercase().contains(t) ||
                    it.artist.lowercase().contains(t) ||
                    it.album.lowercase().contains(t)
            }
        )
    }

    override fun applyInsets() {
        (back.layoutParams as LayoutParams).apply {
            topMargin = act.topInset + act.dp(12)
            marginStart = act.dp(18)
        }
        back.requestLayout()
        val bottom = maxOf(act.contentBottomPad(), act.imeInset + act.dp(16))
        rv.setPadding(0, act.topInset + act.dp(12 + 56 + 2), 0, bottom)
    }
}

/** Apple Music style folder page: big cover, cover color background, track list. */
class FolderPage(
    private val act: MainActivity,
    private val folder: Folder
) : FrameLayout(act), InsetsAware {

    private val bgv = GradientBackgroundView(act)
    private val rv = RecyclerView(act)
    private val adapter = SongAdapter(act, 56)
    private val back = LiquidGlassFab(act)
    private val cover = SquareImageView(act)
    private val playText = TextView(act)
    private val playIcon = ImageView(act)

    init {
        val g = act.currentGradient()
        bgv.setColors(g[0], g[1], false)
        addView(bgv, LayoutParams(-1, -1))

        val screenW = resources.displayMetrics.widthPixels
        val coverSize = (screenW * 0.66f).toInt()

        cover.round(act.dp(24).toFloat())
        cover.elevation = act.dp(14).toFloat()

        val title = TextView(act).apply {
            text = folder.name
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        val totalMin = (folder.songs.sumOf { it.durationMs } / 60000L).toInt()
        val n = folder.songs.size
        val subtitle = TextView(act).apply {
            text = (if (n == 1) "1 song" else "$n songs") + " \u2022 $totalMin min"
            textSize = 16f
            setTextColor(Color.argb(190, 255, 255, 255))
            gravity = Gravity.CENTER
        }

        val shuffleBtn = ImageView(act).apply {
            setImageResource(R.drawable.ic_shuffle)
            imageTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            background = circleBackground(Color.argb(60, 255, 255, 255))
            val p = act.dp(16)
            setPadding(p, p, p, p)
            setOnClickListener { Playback.play(act, folder.songs, 0, true) }
        }
        val addBtn = ImageView(act).apply {
            setImageResource(R.drawable.ic_add)
            imageTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            background = circleBackground(Color.argb(60, 255, 255, 255))
            val p = act.dp(16)
            setPadding(p, p, p, p)
            setOnClickListener { Playback.addToQueue(act, folder.songs) }
        }
        playIcon.setImageResource(R.drawable.ic_play)
        playText.text = "Play"
        playText.textSize = 18f
        playText.typeface = Typeface.DEFAULT_BOLD
        val accent = ColorEngine.accent(ColorEngine.DEFAULT)
        playText.setTextColor(accent)
        playIcon.imageTintList = android.content.res.ColorStateList.valueOf(accent)
        val playBtn = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(Color.argb(235, 255, 255, 255))
                cornerRadius = 999f
            }
            addView(playIcon, LinearLayout.LayoutParams(act.dp(22), act.dp(22)))
            addView(playText, LinearLayout.LayoutParams(-2, -2).apply { marginStart = act.dp(6) })
            setOnClickListener { Playback.play(act, folder.songs, 0) }
        }
        val buttons = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(shuffleBtn, LinearLayout.LayoutParams(act.dp(56), act.dp(56)))
            addView(playBtn, LinearLayout.LayoutParams(0, act.dp(56), 1f).apply {
                marginStart = act.dp(12)
                marginEnd = act.dp(12)
            })
            addView(addBtn, LinearLayout.LayoutParams(act.dp(56), act.dp(56)))
        }

        val header = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(act.dp(20), act.dp(4), act.dp(20), act.dp(16))
            clipChildren = false
            clipToPadding = false
            addView(cover, LinearLayout.LayoutParams(coverSize, coverSize))
            addView(title, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(22) })
            addView(subtitle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(2) })
            addView(buttons, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(18) })
        }

        val first = folder.songs.firstOrNull()
        CoverLoader.load(act, first, 1024, cover)
        if (first != null) {
            CoverLoader.color(act, first) { c ->
                if (c != null) {
                    val gg = ColorEngine.gradient(c, act.isDark())
                    bgv.setColors(gg[0], gg[1], true)
                    val a = ColorEngine.accent(c)
                    playText.setTextColor(a)
                    playIcon.imageTintList = android.content.res.ColorStateList.valueOf(a)
                }
            }
        }

        adapter.header = header
        adapter.onSongClick = { list, i -> Playback.play(act, list, i) }
        adapter.submit(folder.songs)
        rv.layoutManager = LinearLayoutManager(act)
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.clipChildren = false
        rv.overScrollMode = OVER_SCROLL_NEVER
        addView(rv, LayoutParams(-1, -1))

        act.styleGlass(back)
        back.setIconResource(R.drawable.ic_back)
        back.setIconTint(Color.WHITE)
        back.setOnClickListener { act.popOverlay() }
        addView(back, LayoutParams(act.dp(56), act.dp(56), Gravity.TOP or Gravity.START))

        applyInsets()
    }

    override fun applyInsets() {
        (back.layoutParams as LayoutParams).apply {
            topMargin = act.topInset + act.dp(12)
            marginStart = act.dp(18)
        }
        back.requestLayout()
        rv.setPadding(0, act.topInset + act.dp(56), 0, act.contentBottomPad())
    }
}
