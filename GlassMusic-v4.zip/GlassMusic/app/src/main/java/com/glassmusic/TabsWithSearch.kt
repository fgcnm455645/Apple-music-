package com.glassmusic

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseOut
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.fastCoerceIn
import androidx.compose.ui.util.fastRoundToInt
import androidx.compose.ui.util.lerp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberCombinedBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.catalog.components.LiquidButton
import com.kyant.backdrop.catalog.components.LocalIsLensCopy
import com.kyant.backdrop.catalog.components.LocalLiquidBottomTabScale
import com.kyant.backdrop.catalog.utils.DampedDragAnimation
import com.kyant.backdrop.catalog.utils.InteractiveHighlight
import com.kyant.backdrop.catalog.utils.inspectDragGestures
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.backdrop.highlight.Highlight
import com.kyant.backdrop.shadow.InnerShadow
import com.kyant.backdrop.shadow.Shadow
import com.kyant.shapes.Capsule
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sign

/** Positions (px) of the four lens slots: three tabs inside the capsule + the search circle. */
private class TabsGeo(
    val inset: Float,
    val tabW: Float,
    val total: Float,
    val capsuleW: Float,
    val gap: Float,
    val searchSize: Float
) {
    private val c2: Float get() = inset + 2.5f * tabW
    private val c3: Float get() = capsuleW + gap + searchSize / 2f
    private val searchLensW: Float get() = searchSize - 2f * inset

    /** Distance between the last tab center and the search center. */
    val searchSegment: Float get() = c3 - c2

    fun centerOf(v: Float): Float =
        if (v <= 2f) inset + (v + 0.5f) * tabW
        else c2 + (c3 - c2) * (v - 2f).coerceAtMost(1f)

    fun widthOf(v: Float): Float =
        if (v <= 2f) tabW
        else tabW + (searchLensW - tabW) * (v - 2f).coerceAtMost(1f)
}

/**
 * The tab capsule and the round search button with ONE glass lens that can travel between them:
 * drag the lens from the tabs onto search (release = open search), or press search and drag the lens
 * left onto a tab. While the search page is open the lens rests on the search button.
 *
 * Slots: 0..2 = tabs, 3 = search. Sizes are in px.
 */
@Composable
fun TabsWithSearch(
    selectedIndex: () -> Int,
    onSelected: (Int) -> Unit,
    backdrop: Backdrop,
    capsuleW: Float,
    capsuleH: Float,
    gap: Float,
    searchSize: Float,
    isLightTheme: Boolean,
    accentColor: Color,
    containerColor: Color,
    modifier: Modifier = Modifier,
    searchIcon: @Composable () -> Unit,
    content: @Composable RowScope.() -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        val density = LocalDensity.current
        fun dpOf(px: Float): Dp = with(density) { px.toDp() }

        val inset = with(density) { 4f.dp.toPx() }
        val total = capsuleW + gap + searchSize
        val geoState = rememberUpdatedState(
            TabsGeo(inset, (capsuleW - 2f * inset) / 3f, total, capsuleW, gap, searchSize)
        )
        val selectedState = rememberUpdatedState(selectedIndex)
        val onSelectedState = rememberUpdatedState(onSelected)

        val tabsBackdrop = rememberLayerBackdrop()
        val animationScope = rememberCoroutineScope()
        val offsetAnimation = remember { Animatable(0f) }
        val panelOffset by remember(density) {
            derivedStateOf {
                val fraction = (offsetAnimation.value / geoState.value.total).fastCoerceIn(-1f, 1f)
                with(density) {
                    4f.dp.toPx() * fraction.sign * EaseOut.transform(abs(fraction))
                }
            }
        }

        var currentIndex by remember { mutableIntStateOf(selectedIndex()) }

        val stopDrag: DampedDragAnimation.() -> Unit = {
            val targetIndex = targetValue.fastRoundToInt().fastCoerceIn(0, 3)
            currentIndex = targetIndex
            animateToValue(targetIndex.toFloat())
            animationScope.launch {
                offsetAnimation.animateTo(0f, spring(1f, 300f, 0.5f))
            }
        }
        val dragBy: DampedDragAnimation.(Offset) -> Unit = { dragAmount ->
            val g = geoState.value
            val unit =
                if (targetValue > 2f || (targetValue >= 2f && dragAmount.x > 0f)) g.searchSegment else g.tabW
            updateValue((targetValue + dragAmount.x / unit).fastCoerceIn(0f, 3f))
            animationScope.launch {
                offsetAnimation.snapTo(offsetAnimation.value + dragAmount.x)
            }
        }

        val dampedDragAnimation = remember(animationScope) {
            DampedDragAnimation(
                animationScope = animationScope,
                initialValue = selectedIndex().toFloat(),
                valueRange = 0f..3f,
                visibilityThreshold = 0.001f,
                initialScale = 1f,
                pressedScale = 78f / 56f,
                onDragStarted = {},
                onDragStopped = { stopDrag() },
                onDrag = { _, dragAmount -> dragBy(dragAmount) }
            )
        }

        LaunchedEffect(Unit) {
            snapshotFlow { selectedState.value() }
                .collectLatest { index -> currentIndex = index }
        }
        LaunchedEffect(dampedDragAnimation) {
            snapshotFlow { currentIndex }
                .drop(1)
                .collectLatest { index ->
                    dampedDragAnimation.animateToValue(index.toFloat())
                    onSelectedState.value(index)
                }
        }

        val interactiveHighlight = remember(animationScope) {
            InteractiveHighlight(
                animationScope = animationScope,
                position = { size, _ ->
                    Offset(
                        geoState.value.centerOf(dampedDragAnimation.value) + panelOffset,
                        size.height / 2f
                    )
                }
            )
        }

        // pressing the search button puts the lens on it right away; dragging then slides the lens left
        val searchDrag = Modifier.pointerInput(dampedDragAnimation) {
            inspectDragGestures(
                onDragStart = {
                    dampedDragAnimation.updateValue(3f)
                    dampedDragAnimation.press()
                },
                onDragEnd = {
                    dampedDragAnimation.stopDrag()
                    dampedDragAnimation.release()
                },
                onDragCancel = {
                    dampedDragAnimation.stopDrag()
                    dampedDragAnimation.release()
                }
            ) { _, dragAmount ->
                if (dragAmount != Offset.Zero) dampedDragAnimation.dragBy(dragAmount)
            }
        }

        val boxH = max(capsuleH, searchSize)
        val searchX = capsuleW + gap
        val lensH = capsuleH - 2f * inset

        Box(
            modifier
                .width(dpOf(total))
                .height(dpOf(boxH)),
            contentAlignment = Alignment.BottomStart
        ) {
            // ------------------------------------------------ the visible capsule with the tabs
            Row(
                Modifier
                    .align(Alignment.BottomStart)
                    .graphicsLayer { translationX = panelOffset }
                    .drawBackdrop(
                        backdrop = backdrop,
                        shape = { Capsule() },
                        effects = {
                            vibrancy()
                            blur(2f.dp.toPx())
                            lens(12f.dp.toPx(), 24f.dp.toPx())
                        },
                        layerBlock = {
                            val progress = dampedDragAnimation.pressProgress
                            val scale = lerp(1f, 1f + 16f.dp.toPx() / size.width, progress)
                            scaleX = scale
                            scaleY = scale
                        },
                        onDrawSurface = { drawRect(containerColor) }
                    )
                    .then(interactiveHighlight.modifier)
                    .height(dpOf(capsuleH))
                    .width(dpOf(capsuleW))
                    .padding(4f.dp),
                verticalAlignment = Alignment.CenterVertically,
                content = content
            )

            // ------------------------------------------------ the visible search circle
            LiquidButton(
                onClick = {},
                backdrop = backdrop,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .offset { IntOffset(searchX.roundToInt(), 0) }
                    .size(dpOf(searchSize))
                    .then(searchDrag),
                isInteractive = true,
                surfaceColor = containerColor,
                height = dpOf(searchSize),
                horizontalPadding = 0.dp
            ) {
                searchIcon()
            }

            // ------------------------------------------------ invisible copy used by the lens
            CompositionLocalProvider(
                LocalLiquidBottomTabScale provides {
                    lerp(1f, 1.2f, dampedDragAnimation.pressProgress)
                },
                LocalIsLensCopy provides true
            ) {
                Box(
                    Modifier
                        .clearAndSetSemantics {}
                        .alpha(0f)
                        .layerBackdrop(tabsBackdrop)
                        .width(dpOf(total))
                        .height(dpOf(boxH)),
                    contentAlignment = Alignment.BottomStart
                ) {
                    Row(
                        Modifier
                            .align(Alignment.BottomStart)
                            .padding(bottom = 4f.dp)
                            .graphicsLayer { translationX = panelOffset }
                            .drawBackdrop(
                                backdrop = backdrop,
                                shape = { Capsule() },
                                effects = {
                                    val progress = dampedDragAnimation.pressProgress
                                    vibrancy()
                                    blur(8f.dp.toPx())
                                    lens(24f.dp.toPx() * progress, 24f.dp.toPx() * progress)
                                },
                                highlight = {
                                    val progress = dampedDragAnimation.pressProgress
                                    Highlight.Default.copy(alpha = progress)
                                },
                                onDrawSurface = { drawRect(containerColor) }
                            )
                            .then(interactiveHighlight.modifier)
                            .height(dpOf(lensH))
                            .width(dpOf(capsuleW))
                            .padding(horizontal = 4f.dp)
                            .graphicsLayer(colorFilter = ColorFilter.tint(accentColor)),
                        verticalAlignment = Alignment.CenterVertically,
                        content = content
                    )
                    Box(
                        Modifier
                            .align(Alignment.BottomStart)
                            .offset { IntOffset(searchX.roundToInt(), 0) }
                            .drawBackdrop(
                                backdrop = backdrop,
                                shape = { Capsule() },
                                effects = {
                                    val progress = dampedDragAnimation.pressProgress
                                    vibrancy()
                                    blur(8f.dp.toPx())
                                    lens(24f.dp.toPx() * progress, 24f.dp.toPx() * progress)
                                },
                                highlight = {
                                    val progress = dampedDragAnimation.pressProgress
                                    Highlight.Default.copy(alpha = progress)
                                },
                                onDrawSurface = { drawRect(containerColor) }
                            )
                            .size(dpOf(searchSize))
                            .graphicsLayer(colorFilter = ColorFilter.tint(accentColor)),
                        contentAlignment = Alignment.Center
                    ) {
                        searchIcon()
                    }
                }
            }

            // ------------------------------------------------ the lens itself
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(bottom = 4f.dp)
                    .graphicsLayer {
                        val g = geoState.value
                        translationX = g.centerOf(dampedDragAnimation.value) - g.tabW / 2f + panelOffset
                    }
                    .then(interactiveHighlight.gestureModifier)
                    .then(dampedDragAnimation.modifier)
                    .drawBackdrop(
                        backdrop = rememberCombinedBackdrop(backdrop, tabsBackdrop),
                        shape = { Capsule() },
                        effects = {
                            val progress = dampedDragAnimation.pressProgress
                            lens(
                                10f.dp.toPx() * progress,
                                14f.dp.toPx() * progress,
                                chromaticAberration = true
                            )
                        },
                        highlight = {
                            val progress = dampedDragAnimation.pressProgress
                            Highlight.Default.copy(alpha = progress)
                        },
                        shadow = {
                            val progress = dampedDragAnimation.pressProgress
                            Shadow(alpha = progress)
                        },
                        innerShadow = {
                            val progress = dampedDragAnimation.pressProgress
                            InnerShadow(
                                radius = 8f.dp * progress,
                                alpha = progress
                            )
                        },
                        layerBlock = {
                            val g = geoState.value
                            scaleX = dampedDragAnimation.scaleX
                            scaleY = dampedDragAnimation.scaleY
                            val velocity = dampedDragAnimation.velocity / 10f
                            scaleX /= 1f - (velocity * 0.75f).fastCoerceIn(-0.2f, 0.2f)
                            scaleY *= 1f - (velocity * 0.25f).fastCoerceIn(-0.2f, 0.2f)
                            // a bit narrower on the round search button
                            scaleX *= g.widthOf(dampedDragAnimation.value) / g.tabW
                        },
                        onDrawSurface = {
                            val progress = dampedDragAnimation.pressProgress
                            drawRect(
                                if (isLightTheme) Color.Black.copy(0.1f)
                                else Color.White.copy(0.1f),
                                alpha = 1f - progress
                            )
                            drawRect(Color.Black.copy(alpha = 0.03f * progress))
                        }
                    )
                    .height(dpOf(lensH))
                    .width(dpOf(geoState.value.tabW))
            )
        }
    }
}
