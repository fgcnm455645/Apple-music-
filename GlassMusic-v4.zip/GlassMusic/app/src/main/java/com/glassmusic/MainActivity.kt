package com.glassmusic

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import java.io.File
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var bg: CoverBackgroundView
    private lateinit var pagesHost: FrameLayout
    private lateinit var home: HomePage
    private lateinit var library: LibraryPage
    private lateinit var settings: SettingsPage
    private lateinit var topTitle: TextView
    private lateinit var permissionView: LinearLayout
    private lateinit var player: PlayerScreen

    private val ui = BarsUi()
    private val overlays = ArrayList<View>()
    private val themeBlocks = HashMap<Any, ArrayList<() -> Unit>>()

    var topInset = 0
        private set
    var bottomInset = 0
        private set
    var imeInset = 0
        private set

    private var songColor: Int? = null
    private var bgBlur: Bitmap? = null
    private var currentTab = 0
    private var loaded = false
    private var loading = false
    private var currentSongId = -1L
    private var leaving: View? = null
    private var folderOwner: View? = null

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { onPermissionResult() }

    private val photoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveProfilePhoto(uri)
    }

    /** Set by the profile page so it can refresh its picture after a new photo was chosen. */
    var onProfileChanged: (() -> Unit)? = null

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            updateMiniPlay()
            player.update()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            onSongChanged(songOf(mediaItem), true)
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            player.update()
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false

        buildUi()
        loadProfilePhoto()

        val actions = BarActions(
            selectTab = { selectTab(it) },
            openSearch = { openSearch() },
            showPlayer = { player.show() },
            prev = { Playback.controller?.seekToPrevious() },
            playPause = {
                val c = Playback.controller
                if (c != null) {
                    if (c.isPlaying) c.pause() else c.play()
                }
            },
            next = { Playback.controller?.seekToNext() },
            back = { popOverlay() },
            sort = { showSortMenu() },
            profile = { openProfilePage(this) },
            expand = { setCollapsed(false) },
            folderShuffle = { (overlays.lastOrNull() as? FolderPage)?.shuffleAll() },
            folderAdd = { (overlays.lastOrNull() as? FolderPage)?.addAll() }
        )
        setContent {
            val backdrop = rememberLayerBackdrop()
            Box(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxSize().layerBackdrop(backdrop)) {
                    AndroidView(factory = { root }, modifier = Modifier.fillMaxSize())
                }
                GlassOverlay(backdrop, ui, actions)
            }
        }

        applySystemBars()
        applyTheme(false)
        selectTab(0)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleBack()
            }
        })

        if (hasAudio()) loadMusic() else askPermissions()
    }

    override fun onResume() {
        super.onResume()
        if (!loaded && !loading && hasAudio()) {
            permissionView.visibility = View.GONE
            loadMusic()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyTheme(false)
    }

    override fun onDestroy() {
        Playback.controller?.removeListener(playerListener)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- theme colors

    fun isDark(): Boolean =
        if (Prefs.useSystemTheme) {
            (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        } else {
            Prefs.darkMode
        }

    private fun dynamicActive(): Boolean = Prefs.dynamicTheme && songColor != null

    /** True when the background is the plain light theme (dark text and icons on top). */
    fun onLightBg(): Boolean = !isDark() && !dynamicActive()

    fun fg1(): Int = if (onLightBg()) 0xFF111114.toInt() else Color.WHITE
    fun fg2(): Int = if (onLightBg()) 0x99111114.toInt() else 0xB3FFFFFF.toInt()
    fun fgDivider(): Int = if (onLightBg()) 0x22000000 else 0x33FFFFFF
    fun surface(): Int = if (onLightBg()) 0xB3FFFFFF.toInt() else 0x26FFFFFF

    fun songColorOrNull(): Int? = songColor

    fun blurredCover(): Bitmap? = bgBlur

    /** Gradient + (in dynamic mode) the smooth blurred cover of the playing song. */
    fun styleBackground(view: CoverBackgroundView, animate: Boolean) {
        val g = currentGradient()
        view.setColors(g[0], g[1], animate)
        if (dynamicActive()) {
            view.setCover(bgBlur, animate)
            view.setShade(if (isDark()) 0x66000000 else 0x2E000000)
        } else {
            view.setCover(null, animate)
            view.setShade(0)
        }
    }

    fun newBackground(owner: Any): CoverBackgroundView {
        val v = CoverBackgroundView(this)
        themed(owner) { styleBackground(v, false) }
        return v
    }

    fun currentGradient(): IntArray {
        val c = songColor
        return if (Prefs.dynamicTheme && c != null) {
            ColorEngine.gradient(c, isDark())
        } else if (isDark()) {
            intArrayOf(0xFF000000.toInt(), 0xFF000000.toInt())
        } else {
            intArrayOf(0xFFF3F3F8.toInt(), 0xFFD8D8E4.toInt())
        }
    }

    fun themed(owner: Any, block: () -> Unit) {
        block()
        themeBlocks.getOrPut(owner) { ArrayList() }.add(block)
    }

    fun dropThemed(owner: Any) {
        themeBlocks.remove(owner)
    }

    fun applyTheme(animate: Boolean = true) {
        styleBackground(bg, animate)
        ArrayList(themeBlocks.values).forEach { list -> ArrayList(list).forEach { it() } }
        home.retint()
        library.retint()
        settings.retint()
        overlays.forEach { (it as? InsetsAware)?.retint() }
        player.refreshBackground(animate)
        topTitle.setTextColor(fg1())
        ui.onLight = onLightBg()
        ui.fg = fg1()
    }

    fun refreshPlayerBackground() {
        player.refreshBackground(true)
    }

    fun refreshHome() {
        home.refresh()
    }

    fun applySystemBars() {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.isAppearanceLightStatusBars = onLightBg()
        c.isAppearanceLightNavigationBars = onLightBg()
        if (Prefs.hideStatusBar) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.statusBars())
        } else {
            c.show(WindowInsetsCompat.Type.statusBars())
        }
    }

    // ---------------------------------------------------------------- UI construction

    private fun buildUi() {
        root = FrameLayout(this)
        root.clipChildren = false

        bg = CoverBackgroundView(this)
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))

        pagesHost = FrameLayout(this)
        root.addView(pagesHost, FrameLayout.LayoutParams(-1, -1))
        home = HomePage(this)
        library = LibraryPage(this)
        settings = SettingsPage(this)
        pagesHost.addView(home.view, FrameLayout.LayoutParams(-1, -1))
        pagesHost.addView(library.view, FrameLayout.LayoutParams(-1, -1))
        pagesHost.addView(settings.view, FrameLayout.LayoutParams(-1, -1))

        buildPermissionView()

        topTitle = TextView(this)
        topTitle.tsz(18f)
        topTitle.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        topTitle.gravity = Gravity.CENTER
        topTitle.alpha = 0f
        root.addView(topTitle, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        player = PlayerScreen(this)
        root.addView(player.view, FrameLayout.LayoutParams(-1, -1))
        player.view.visibility = View.GONE

        // read insets from the window itself (the Compose host owns the content view)
        ViewCompat.setOnApplyWindowInsetsListener(window.decorView) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            topInset = bars.top
            bottomInset = bars.bottom
            imeInset = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            ui.topInsetPx = topInset.toFloat()
            ui.bottomInsetPx = bottomInset.toFloat()
            applyInsets()
            ViewCompat.onApplyWindowInsets(v, insets)
        }
        applyInsets()
    }

    private fun buildPermissionView() {
        val msg = TextView(this)
        msg.text = "Allow access to your music to see your songs"
        msg.tsz(18f)
        msg.gravity = Gravity.CENTER
        themed(msg) { msg.setTextColor(fg1()) }
        val btn = TextView(this)
        btn.text = "Allow access"
        btn.tsz(17f)
        btn.typeface = Typeface.DEFAULT_BOLD
        btn.setTextColor(Color.BLACK)
        btn.gravity = Gravity.CENTER
        btn.setPadding(dp(28), dp(14), dp(28), dp(14))
        btn.background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = 999f
        }
        btn.setOnClickListener {
            if (shouldShowRequestPermissionRationale(audioPermission())) {
                askPermissions()
            } else {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        }
        permissionView = LinearLayout(this)
        permissionView.orientation = LinearLayout.VERTICAL
        permissionView.gravity = Gravity.CENTER
        permissionView.setPadding(dp(40), 0, dp(40), 0)
        permissionView.addView(msg, LinearLayout.LayoutParams(-2, -2))
        permissionView.addView(btn, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(24) })
        permissionView.visibility = View.GONE
        root.addView(permissionView, FrameLayout.LayoutParams(-1, -1))
    }

    // ---------------------------------------------------------------- layout

    private fun applyInsets() {
        val top = maxOf(topInset + dp(10), dp(43))
        (topTitle.layoutParams as FrameLayout.LayoutParams).topMargin = top + dp(16)
        topTitle.requestLayout()

        home.applyInsets()
        library.applyInsets()
        settings.applyInsets()
        player.applyInsets()
        overlays.forEach { (it as? InsetsAware)?.applyInsets() }
    }

    /** Bottom padding that keeps list content clear of the floating bars (design px at 1080 wide). */
    fun contentBottomPad(): Int {
        val s = resources.displayMetrics.widthPixels / 1080f
        val base = maxOf(bottomInset + 26f * s, 116f * s)
        return (base + (201f + 22f + 138f + 40f) * s).toInt()
    }

    // ---------------------------------------------------------------- bars collapse

    fun setCollapsed(value: Boolean) {
        ui.collapsed = value
    }

    /** Called by every scrolling list. [source] is the tab index, or -1 for pushed pages. */
    fun onListScrolled(source: Int, dy: Int, offset: Int) {
        if (source == currentTab && overlays.isEmpty()) updateTopTitle(offset)
        if (!Prefs.collapseBars) return
        if (offset <= dp(8)) {
            setCollapsed(false)
        } else if (dy > dp(2)) {
            setCollapsed(true)
        } else if (dy < -dp(2)) {
            setCollapsed(false)
        }
    }

    private fun updateTopTitle(offset: Int) {
        // Home: the big title just scrolls away with the list, nothing is pinned at the top
        if (currentTab == 0) {
            topTitle.alpha = 0f
            return
        }
        val start = (if (currentTab == 2) dp(150) else dp(115)).toFloat()
        topTitle.alpha = ((offset - start) / dp(30)).coerceIn(0f, 1f)
    }

    // ---------------------------------------------------------------- navigation

    fun selectTab(i: Int) {
        // a pushed page (folder, settings sub page, search...) must not block the tab bar
        if (overlays.isNotEmpty()) popAllOverlays()
        currentTab = i
        ui.tab = i
        home.view.visibility = if (i == 0) View.VISIBLE else View.GONE
        library.view.visibility = if (i == 1) View.VISIBLE else View.GONE
        settings.view.visibility = if (i == 2) View.VISIBLE else View.GONE
        topTitle.text = when (i) {
            0 -> "Listen Now"
            1 -> "Library"
            else -> "Settings"
        }
        val off = when (i) {
            0 -> home.offset()
            1 -> library.offset()
            else -> settings.offset()
        }
        updateTopTitle(off)
        if (off <= dp(8)) setCollapsed(false)
        updateTopButtons()
    }

    private fun updateTopButtons() {
        val free = overlays.isEmpty() && !player.isOpen
        ui.overlayCount = overlays.size
        val topPage = overlays.lastOrNull()
        ui.searchOpen = topPage is ListPage && topPage.search
        topTitle.visibility = if (free) View.VISIBLE else View.GONE
    }

    private fun handleBack() {
        when {
            player.isOpen -> player.hide()
            overlays.isNotEmpty() -> popOverlay()
            currentTab != 0 -> selectTab(0)
            else -> finish()
        }
    }

    fun pushOverlay(v: View) {
        root.addView(v, root.indexOfChild(player.view), FrameLayout.LayoutParams(-1, -1))
        overlays.add(v)
        v.translationX = resources.displayMetrics.widthPixels.toFloat()
        v.animate().translationX(0f).setDuration(300).setInterpolator(DecelerateInterpolator()).start()
        updateTopButtons()
    }

    fun popOverlay() {
        if (overlays.isEmpty()) return
        val v = overlays.removeAt(overlays.size - 1)
        WindowCompat.getInsetsController(window, root).hide(WindowInsetsCompat.Type.ime())
        updateTopButtons()
        leaving = v
        v.animate()
            .translationX(resources.displayMetrics.widthPixels.toFloat())
            .setDuration(250)
            .withEndAction {
                if (leaving === v) leaving = null
                (v as? InsetsAware)?.onRemoved()
                root.removeView(v)
            }
            .start()
    }

    /** Closes every pushed page at once (used when a tab is tapped while a sub page is open). */
    private fun popAllOverlays() {
        if (overlays.isEmpty()) return
        WindowCompat.getInsetsController(window, root).hide(WindowInsetsCompat.Type.ime())
        val all = ArrayList(overlays)
        overlays.clear()
        all.forEachIndexed { idx, v ->
            if (idx == all.size - 1) {
                leaving = v
                v.animate()
                    .translationX(resources.displayMetrics.widthPixels.toFloat())
                    .setDuration(250)
                    .withEndAction {
                        if (leaving === v) leaving = null
                        (v as? InsetsAware)?.onRemoved()
                        root.removeView(v)
                    }
                    .start()
            } else {
                (v as? InsetsAware)?.onRemoved()
                root.removeView(v)
            }
        }
        updateTopButtons()
    }

    /** The two glass buttons of a folder page follow the page's placeholders (called every frame). */
    fun reportFolderButtons(page: View, sx: Float, sy: Float, ax: Float, ay: Float, size: Float, attached: Boolean) {
        val active = overlays.lastOrNull() === page || leaving === page
        if (!active) {
            if (folderOwner === page) ui.folderVisible = false
            return
        }
        folderOwner = page
        val h = root.height.toFloat()
        val on = attached && sy < h && sy + size > 0f
        if (on) {
            ui.folderShuffleX = sx
            ui.folderShuffleY = sy
            ui.folderAddX = ax
            ui.folderAddY = ay
            ui.folderSize = size
        }
        if (ui.folderVisible != on) ui.folderVisible = on
    }

    // ---------------------------------------------------------------- player <-> mini player geometry

    class MiniGeo(
        val left: Float,
        val top: Float,
        val w: Float,
        val h: Float,
        val coverLeft: Float,
        val coverTop: Float,
        val coverSize: Float,
        val radius: Float
    ) {
        val cx: Float get() = left + w / 2f
        val cy: Float get() = top + h / 2f
    }

    fun rootHeight(): Float = root.height.toFloat().takeIf { it > 0f } ?: resources.displayMetrics.heightPixels.toFloat()

    /** Where the glass mini player sits (same numbers as GlassOverlay, 1080px design scaled to the screen). */
    fun miniGeometry(): MiniGeo {
        val w = resources.displayMetrics.widthPixels.toFloat()
        val h = rootHeight()
        val s = w / 1080f
        val side = 50f * s
        val barH = 201f * s
        val mini = 138f * s
        val circle = 138f * s
        val midGap = 75f * s
        val base = maxOf(bottomInset.toFloat() + 26f * s, 116f * s)
        val collapsed = ui.collapsed
        val left = side + if (collapsed) circle + midGap else 0f
        val bottom = if (collapsed) base else base + barH + 22f * s
        val top = h - bottom - mini
        val cover = 86f * s
        return MiniGeo(
            left, top, w - 2f * left, mini,
            left + 53f * s, top + (mini - cover) / 2f, cover, 20f * s
        )
    }

    fun playerFrac(): Float = ui.playerFrac

    fun setPlayerFrac(f: Float) {
        ui.playerFrac = f
    }

    fun openFolder(folder: Folder) {
        pushOverlay(FolderPage(this, folder))
    }

    fun openSearch() {
        pushOverlay(
            ListPage(this, "Search", MusicRepository.sorted(0), true) { list, i ->
                Playback.play(this, list, i)
            }
        )
    }

    fun openQueue() {
        val c = Playback.controller ?: return
        val list = ArrayList<Song>()
        for (i in 0 until c.mediaItemCount) {
            val s = songOf(c.getMediaItemAt(i))
            if (s != null) list.add(s)
        }
        player.hide()
        pushOverlay(
            ListPage(this, "Up Next", list, false) { _, i ->
                c.seekToDefaultPosition(i)
                c.play()
            }
        )
    }

    fun onPlayerOpened() {
        ui.playerOpen = true
        updateTopButtons()
    }

    fun onPlayerClosed() {
        ui.playerOpen = false
        updateTopButtons()
    }

    private fun showSortMenu() {
        val names = arrayOf("Title", "Artist", "Recently Added", "Album", "Duration", "File Type", "Folder")
        val pm = PopupMenu(this, root, Gravity.TOP or Gravity.END)
        names.forEachIndexed { i, n ->
            val item = pm.menu.add(1, i, i, n)
            item.isCheckable = true
            item.isChecked = Prefs.sortMode == i
        }
        pm.menu.setGroupCheckable(1, true, true)
        val rev = pm.menu.add(2, 100, 100, "Reverse Order")
        rev.isCheckable = true
        rev.isChecked = Prefs.sortReverse
        pm.setOnMenuItemClickListener { item ->
            if (item.itemId == 100) Prefs.sortReverse = !Prefs.sortReverse else Prefs.sortMode = item.itemId
            library.refresh()
            true
        }
        pm.show()
    }

    // ---------------------------------------------------------------- profile

    fun pickProfilePhoto() {
        photoPicker.launch("image/*")
    }

    private fun profileFile() = File(filesDir, "profile.jpg")

    fun profilePhoto(): Bitmap? =
        if (profileFile().exists()) BitmapFactory.decodeFile(profileFile().absolutePath) else null

    fun loadProfilePhoto() {
        ui.profileImage = profilePhoto()?.asImageBitmap()
    }

    fun removeProfilePhoto() {
        profileFile().delete()
        ui.profileImage = null
        onProfileChanged?.invoke()
    }

    private fun saveProfilePhoto(uri: Uri) {
        Thread {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val raw = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                if (raw != null) {
                    val side = minOf(raw.width, raw.height)
                    val square = Bitmap.createBitmap(raw, (raw.width - side) / 2, (raw.height - side) / 2, side, side)
                    val out = Bitmap.createScaledBitmap(square, 512, 512, true)
                    profileFile().outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                    runOnUiThread {
                        loadProfilePhoto()
                        onProfileChanged?.invoke()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }

    // ---------------------------------------------------------------- permission + data

    private fun audioPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudio(): Boolean =
        ContextCompat.checkSelfPermission(this, audioPermission()) == PackageManager.PERMISSION_GRANTED

    private fun askPermissions() {
        val perms = ArrayList<String>()
        perms.add(audioPermission())
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(perms.toTypedArray())
    }

    private fun onPermissionResult() {
        if (hasAudio()) {
            permissionView.visibility = View.GONE
            loadMusic()
        } else {
            permissionView.visibility = View.VISIBLE
        }
    }

    private fun loadMusic() {
        if (loading) return
        loading = true
        Thread {
            var ok = true
            try {
                MusicRepository.load(applicationContext)
            } catch (e: Exception) {
                ok = false
            }
            runOnUiThread {
                loading = false
                loaded = ok
                home.refresh()
                library.refresh()
                connectPlayback()
            }
        }.start()
    }

    // ---------------------------------------------------------------- playback state

    fun songOf(item: MediaItem?): Song? =
        item?.mediaId?.toLongOrNull()?.let { MusicRepository.byId[it] }

    fun currentSong(): Song? = songOf(Playback.controller?.currentMediaItem)

    private fun connectPlayback() {
        Playback.whenReady(this) { c ->
            c.removeListener(playerListener)
            c.addListener(playerListener)
            onSongChanged(songOf(c.currentMediaItem), false)
            updateMiniPlay()
        }
    }

    private fun updateMiniPlay() {
        ui.isPlaying = Playback.controller?.isPlaying == true
    }

    private fun onSongChanged(song: Song?, record: Boolean) {
        if (song == null) {
            currentSongId = -1L
            songColor = null
            bgBlur = null
            ui.hasSong = false
            ui.cover = null
            applyTheme(true)
            return
        }
        currentSongId = song.id
        ui.hasSong = true
        ui.title = song.title
        ui.artist = song.artist
        CoverLoader.bitmap(this, song, 160) { b ->
            if (currentSongId == song.id) ui.cover = b?.asImageBitmap()
        }
        CoverLoader.color(this, song) { c ->
            if (currentSongId == song.id) {
                songColor = c
                applyTheme(true)
                applySystemBars()
            }
        }
        CoverLoader.blurred(this, song) { b ->
            if (currentSongId == song.id) {
                bgBlur = b
                applyTheme(true)
            }
        }
        if (record) Prefs.addRecent(song.id)
        player.update()
    }
}
