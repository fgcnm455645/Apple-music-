package com.glassmusic

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.os.SystemClock
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import kotlin.math.abs
import kotlin.math.min

/**
 * Apple Music style lyrics: the current line is big and bright, the others are dim and blurred,
 * the active line fills up with the music, and the list follows the song. Tap a line to seek.
 */
class LyricsView(private val act: MainActivity) : FrameLayout(act) {
    private val scroll = ScrollView(act)
    private val list = LinearLayout(act)
    private val status = TextView(act)

    private var lines: List<LyricLine> = emptyList()
    private var views: List<LyricLineView> = emptyList()
    private var synced = false
    private var active = -2
    private var firstPass = true
    private var color = Color.WHITE

    private var touching = false
    private var resumeAt = 0L
    private var pendingResume = false
    private var pendingFollow = false
    private var scrollAnim: ObjectAnimator? = null
    private var stateAnim: ValueAnimator? = null

    /** Lyrics delay in ms: positive makes the lyrics appear later. */
    var offsetMs = 0L

    /** Called with the song position (ms) a tapped line starts at. */
    var onSeek: ((Long) -> Unit)? = null

    init {
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = OVER_SCROLL_NEVER
        scroll.isVerticalFadingEdgeEnabled = true
        scroll.setFadingEdgeLength(act.dp(70))
        scroll.clipToPadding = false
        list.orientation = LinearLayout.VERTICAL
        list.clipChildren = false
        list.clipToPadding = false
        scroll.addView(list, LayoutParams(-1, -2))
        addView(scroll, LayoutParams(-1, -1))

        status.tsz(18f)
        status.gravity = Gravity.CENTER
        status.visibility = GONE
        addView(status, LayoutParams(-1, -2, Gravity.CENTER).apply {
            marginStart = act.dp(40)
            marginEnd = act.dp(40)
        })

        scroll.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    touching = true
                    scrollAnim?.cancel()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    touching = false
                    resumeAt = SystemClock.uptimeMillis() + 3000
                    pendingResume = true
                }
            }
            false
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        list.setPadding(act.dp(32), (h * 0.18f).toInt(), act.dp(32), (h * 0.75f).toInt())
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        if (pendingFollow) {
            pendingFollow = false
            followActive(true)
        }
    }

    fun setColor(c: Int) {
        color = c
        status.setTextColor(ColorUtils.setAlphaComponent(c, 190))
        views.forEach { it.setColorValue(c) }
    }

    fun showStatus(text: String) {
        stateAnim?.cancel()
        scrollAnim?.cancel()
        list.removeAllViews()
        views = emptyList()
        lines = emptyList()
        synced = false
        active = -2
        status.text = text
        status.visibility = VISIBLE
    }

    fun setLyrics(l: Lyrics) {
        stateAnim?.cancel()
        scrollAnim?.cancel()
        status.visibility = GONE
        list.removeAllViews()
        synced = l.synced
        lines = l.lines
        active = -2
        firstPass = true
        pendingResume = false
        val textPx = 34f * act.dpScale()
        val made = ArrayList<LyricLineView>(lines.size)
        for (ln in lines) {
            val v = LyricLineView(act, ln, textPx, synced)
            v.setColorValue(color)
            v.setOnClickListener { if (synced) onSeek?.invoke(ln.timeMs + offsetMs) }
            list.addView(v, LinearLayout.LayoutParams(-1, -2))
            made.add(v)
        }
        val rtlCount = made.count { !it.blank && it.rtl }
        val ltrCount = made.count { !it.blank && !it.rtl }
        if (rtlCount > ltrCount) made.filter { it.blank }.forEach { it.rtl = true }
        views = made
        scroll.scrollTo(0, 0)
    }

    /** Drives everything; call it every frame with the player position. */
    fun onPosition(posMs: Long) {
        if (!synced || views.isEmpty()) return
        val eff = posMs - offsetMs
        var lo = 0
        var hi = lines.size - 1
        var idx = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (lines[mid].timeMs <= eff) {
                idx = mid
                lo = mid + 1
            } else {
                hi = mid - 1
            }
        }
        if (idx != active) applyActive(idx)
        if (idx >= 0) views[idx].setProgress(progressOf(idx, eff))
        if (pendingResume && !touching && SystemClock.uptimeMillis() >= resumeAt) {
            pendingResume = false
            followActive(false)
        }
    }

    private fun progressOf(idx: Int, eff: Long): Float {
        val start = lines[idx].timeMs
        val text = lines[idx].text
        val next = if (idx + 1 < lines.size) lines[idx + 1].timeMs else start + 6000
        val gap = (next - start).coerceAtLeast(1L)
        val dur: Double = if (text.isBlank()) {
            gap.toDouble()
        } else {
            // the line is sung over its estimated length, never stretched across a long pause
            val est = (text.length * 85L).coerceIn(900L, 7000L)
            min(gap * 0.94, est.toDouble())
        }
        return ((eff - start) / dur).toFloat().coerceIn(0f, 1f)
    }

    private fun blurFor(i: Int, idx: Int): Float {
        if (!synced) return 0f
        val d = if (idx < 0) i + 1 else abs(i - idx)
        if (d == 0) return 0f
        return (1.2f + d * 1.3f).coerceAtMost(6f) * act.dpScale()
    }

    private fun applyActive(idx: Int) {
        val old = active
        val instant = firstPass
        firstPass = false
        active = idx
        stateAnim?.cancel()
        val n = views.size
        val lo = (minOf(old, idx).coerceAtLeast(0) - 8).coerceAtLeast(0)
        val hi = (maxOf(old, idx) + 8).coerceAtMost(n - 1)
        val startA = FloatArray(n) { views[it].amount }
        val startB = FloatArray(n) { views[it].blur }
        val targetA = FloatArray(n) { if (it == idx) 1f else 0f }
        val targetB = FloatArray(n) { blurFor(it, idx) }
        for (i in 0 until n) {
            if (instant || i < lo || i > hi) views[i].setState(targetA[i], targetB[i])
        }
        if (!instant && lo <= hi) {
            stateAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 380
                interpolator = DecelerateInterpolator(1.5f)
                addUpdateListener { a ->
                    val f = a.animatedValue as Float
                    for (i in lo..hi) {
                        views[i].setState(
                            startA[i] + (targetA[i] - startA[i]) * f,
                            startB[i] + (targetB[i] - startB[i]) * f
                        )
                    }
                }
                start()
            }
        }
        for (i in 0 until n) if (i != idx) views[i].setProgress(if (i < idx) 1f else 0f)
        followActive(instant)
    }

    private fun followActive(instant: Boolean) {
        if (views.isEmpty()) return
        if (active < 0) {
            scrollToY(0, instant)
            return
        }
        val v = views[active]
        if (v.height == 0) {
            pendingFollow = true
            return
        }
        scrollToY(v.top - list.paddingTop, instant)
    }

    private fun scrollToY(y: Int, instant: Boolean) {
        scrollAnim?.cancel()
        val maxY = (list.height - scroll.height).coerceAtLeast(0)
        val t = y.coerceIn(0, maxY)
        if (instant) {
            scroll.scrollTo(0, t)
            return
        }
        if (touching || SystemClock.uptimeMillis() < resumeAt) {
            pendingResume = true
            return
        }
        scrollAnim = ObjectAnimator.ofInt(scroll, "scrollY", scroll.scrollY, t).apply {
            duration = 520
            interpolator = DecelerateInterpolator(1.8f)
            start()
        }
    }
}

/** One lyric line; draws a dim copy of the text plus a bright copy that is revealed as the line is sung. */
class LyricLineView(
    context: Context,
    private val line: LyricLine,
    textPx: Float,
    private val synced: Boolean
) : View(context) {
    val blank = line.text.isBlank()
    var rtl = !blank && TextDirectionHeuristics.FIRSTSTRONG_LTR.isRtl(line.text, 0, line.text.length)
        set(v) {
            field = v
            if (width > 0) pivotX = if (v) width.toFloat() else 0f
        }

    var amount = 0f
        private set
    var blur = 0f
        private set
    private var progress = 0f
    private var color = Color.WHITE
    private var appliedBlur = 0f

    private val padH = context.dp(4)
    private val padV = context.dp(10)
    private val feather = context.dp(18).toFloat()

    private val paint = TextPaint(TextPaint.ANTI_ALIAS_FLAG).apply {
        this.textSize = textPx
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private val fill = TextPaint(paint)
    private var layout: StaticLayout? = null

    init {
        if (synced) {
            scaleX = 0.86f
            scaleY = 0.86f
        }
    }

    fun setColorValue(c: Int) {
        color = c
        invalidate()
    }

    fun setProgress(p: Float) {
        if (p != progress && (abs(p - progress) > 0.002f || p == 0f || p == 1f)) {
            progress = p
            invalidate()
        }
    }

    fun setState(a: Float, b: Float) {
        if (synced) {
            amount = a
            val s = 0.86f + 0.14f * a
            scaleX = s
            scaleY = s
        }
        blur = b
        applyBlur(b)
        invalidate()
    }

    private fun applyBlur(px: Float) {
        if (Build.VERSION.SDK_INT < 31) return
        if (px < 0.5f) {
            if (appliedBlur != 0f) {
                setRenderEffect(null)
                appliedBlur = 0f
            }
        } else if (abs(px - appliedBlur) > 0.4f) {
            setRenderEffect(RenderEffect.createBlurEffect(px, px, Shader.TileMode.DECAL))
            appliedBlur = px
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        pivotX = if (rtl) w.toFloat() else 0f
        pivotY = h / 2f
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val tw = (w - padH * 2).coerceAtLeast(10)
        val h: Int
        if (blank) {
            layout = null
            h = context.dp(34)
        } else {
            var l = layout
            if (l == null || l.width != tw) {
                l = StaticLayout.Builder.obtain(line.text, 0, line.text.length, paint, tw)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_LTR)
                    .setLineSpacing(0f, 1.04f)
                    .setIncludePad(false)
                    .build()
                layout = l
            }
            h = l!!.height + padV * 2
        }
        setMeasuredDimension(w, h)
    }

    override fun onDraw(c: Canvas) {
        if (blank) {
            drawDots(c)
            return
        }
        val l = layout ?: return
        val text = line.text

        if (!synced) {
            paint.shader = null
            paint.color = color
            paint.alpha = (0.92f * 255).toInt()
            drawAll(c, l, text, paint)
            return
        }

        // dim copy (the part that has not been sung yet)
        paint.shader = null
        paint.color = color
        paint.alpha = ((0.30f + 0.30f * amount) * 255).toInt()
        drawAll(c, l, text, paint)

        if (amount < 0.01f || progress <= 0f) return

        // bright copy, revealed line by line from the start of the text with a soft edge
        var total = 0
        for (i in 0 until l.lineCount) total += l.getLineVisibleEnd(i) - l.getLineStart(i)
        if (total < 1) total = 1
        var cum = 0
        for (i in 0 until l.lineCount) {
            val s = l.getLineStart(i)
            val e = l.getLineVisibleEnd(i)
            val n = e - s
            if (n <= 0) continue
            val a = cum.toFloat() / total
            val b = (cum + n).toFloat() / total
            cum += n
            val local = ((progress - a) / (b - a)).coerceIn(0f, 1f)
            if (local <= 0f) continue
            val left = l.getLineLeft(i) + padH
            val right = l.getLineRight(i) + padH
            val base = (l.getLineBaseline(i) + padV).toFloat()
            fill.color = color
            fill.alpha = (amount * 255).toInt()
            if (local < 1f) {
                val w = right - left
                val clear = color and 0x00FFFFFF
                fill.shader = if (!rtl) {
                    val edge = left + w * local
                    LinearGradient(edge - feather, 0f, edge, 0f, color, clear, Shader.TileMode.CLAMP)
                } else {
                    val edge = right - w * local
                    LinearGradient(edge + feather, 0f, edge, 0f, color, clear, Shader.TileMode.CLAMP)
                }
            } else {
                fill.shader = null
            }
            c.drawText(text, s, e, left, base, fill)
        }
        fill.shader = null
    }

    private fun drawAll(c: Canvas, l: StaticLayout, text: String, p: TextPaint) {
        for (i in 0 until l.lineCount) {
            val s = l.getLineStart(i)
            val e = l.getLineVisibleEnd(i)
            if (e <= s) continue
            c.drawText(text, s, e, l.getLineLeft(i) + padH, (l.getLineBaseline(i) + padV).toFloat(), p)
        }
    }

    private fun drawDots(c: Canvas) {
        if (amount < 0.02f) return
        val r = context.dp(5).toFloat()
        val gap = r * 3.4f
        val cy = height / 2f
        for (k in 0..2) {
            val f = (progress * 3f - k).coerceIn(0f, 1f)
            fill.shader = null
            fill.color = color
            fill.alpha = ((0.30f + 0.70f * f) * amount * 255).toInt()
            val cx = if (rtl) width - padH - r - k * gap else padH + r + k * gap
            c.drawCircle(cx, cy, r * (0.85f + 0.15f * f), fill)
        }
    }
}
