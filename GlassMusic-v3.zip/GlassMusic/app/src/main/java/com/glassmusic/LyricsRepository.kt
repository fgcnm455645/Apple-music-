package com.glassmusic

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.roundToInt

/** Finds lyrics for a song: .lrc next to the file, then the local cache, then lrclib.net. */
object LyricsRepository {
    enum class Status { OK, NOT_FOUND, OFFLINE, INSTRUMENTAL }

    class Result(val status: Status, val lyrics: Lyrics? = null)

    private class Cand(val synced: String, val plain: String, val score: Double)

    private const val BASE = "https://lrclib.net/api"
    private val io = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    /**
     * [skip] > 0 picks the next-best version from the search results ("try another version").
     * [force] ignores the local cache.
     */
    fun load(ctx: Context, song: Song, skip: Int, force: Boolean, cb: (Result) -> Unit) {
        val app = ctx.applicationContext
        io.execute {
            val r = try {
                doLoad(app, song, skip, force)
            } catch (e: Exception) {
                Result(Status.OFFLINE)
            }
            main.post { cb(r) }
        }
    }

    private fun doLoad(ctx: Context, song: Song, skip: Int, force: Boolean): Result {
        val dir = File(ctx.filesDir, "lyrics").apply { mkdirs() }
        val cacheFile = File(dir, "${song.id}.txt")

        if (!force && skip == 0) {
            readSidecar(song)?.let { Lrc.parse(it) }?.let { return Result(Status.OK, it) }
            if (cacheFile.exists()) {
                Lrc.parse(cacheFile.readText())?.let { return Result(Status.OK, it) }
            }
        }

        var netError = false
        val cands = ArrayList<Cand>()
        val artistKnown = song.artist.isNotBlank() && song.artist != "Unknown Artist"

        // 1) exact match by title + artist + album + duration (best accuracy)
        if (skip == 0 && artistKnown && song.album.isNotBlank() && song.durationMs > 0) {
            try {
                val url = "$BASE/get?track_name=${enc(song.title)}&artist_name=${enc(song.artist)}" +
                    "&album_name=${enc(song.album)}&duration=${(song.durationMs / 1000.0).roundToInt()}"
                val body = httpGet(url)
                if (body != null) {
                    val o = JSONObject(body)
                    if (o.optBoolean("instrumental", false)) return Result(Status.INSTRUMENTAL)
                    val c = candOf(o, song, artistKnown)
                    if (c.synced.isNotBlank()) {
                        return save(cacheFile, c.synced) ?: Result(Status.NOT_FOUND)
                    }
                    if (c.plain.isNotBlank()) cands.add(c)
                }
            } catch (e: IOException) {
                netError = true
            } catch (e: Exception) {
            }
        }

        // 2) search
        val seen = HashSet<Long>()
        for (url in searchUrls(song, artistKnown)) {
            try {
                val body = httpGet(url) ?: continue
                val arr = JSONArray(body)
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val id = o.optLong("id", -1L)
                    if (id != -1L && !seen.add(id)) continue
                    if (o.optBoolean("instrumental", false)) continue
                    cands.add(candOf(o, song, artistKnown))
                }
            } catch (e: IOException) {
                netError = true
            } catch (e: Exception) {
            }
            if (cands.count { it.synced.isNotBlank() } >= 2) break
        }

        val threshold = if (skip == 0) 30.0 else -1000.0
        val syncedPool = cands.filter { it.synced.isNotBlank() && it.score >= threshold }.sortedByDescending { it.score }
        val plainPool = cands.filter { it.synced.isBlank() && it.plain.isNotBlank() && it.score >= threshold }
            .sortedByDescending { it.score }
        val pool = syncedPool + plainPool
        if (pool.isEmpty()) return Result(if (netError) Status.OFFLINE else Status.NOT_FOUND)

        val pick = pool[skip % pool.size]
        val text = if (pick.synced.isNotBlank()) pick.synced else pick.plain
        return save(cacheFile, text) ?: Result(Status.NOT_FOUND)
    }

    private fun save(file: File, text: String): Result? {
        val parsed = Lrc.parse(text) ?: return null
        try {
            file.writeText(text)
        } catch (e: Exception) {
        }
        return Result(Status.OK, parsed)
    }

    private fun candOf(o: JSONObject, song: Song, artistKnown: Boolean): Cand {
        val synced = if (o.isNull("syncedLyrics")) "" else o.optString("syncedLyrics", "")
        val plain = if (o.isNull("plainLyrics")) "" else o.optString("plainLyrics", "")
        val title = o.optString("trackName", "")
        val artist = o.optString("artistName", "")
        val dur = o.optDouble("duration", 0.0)
        return Cand(synced, plain, score(song, title, artist, dur, artistKnown))
    }

    private fun score(song: Song, title: String, artist: String, dur: Double, artistKnown: Boolean): Double {
        var s = 0.0
        val ct = clean(song.title)
        val rt = clean(title)
        if (ct.isNotEmpty() && rt.isNotEmpty()) {
            s += if (ct == rt) 40.0 else if (rt.contains(ct) || ct.contains(rt)) 20.0 else 0.0
        }
        if (artistKnown) {
            val ca = clean(song.artist)
            val ra = clean(artist)
            if (ca.isNotEmpty() && ra.isNotEmpty()) {
                s += if (ca == ra) 30.0 else if (ra.contains(ca) || ca.contains(ra)) 15.0 else 0.0
            }
        } else {
            s += 15.0
        }
        if (song.durationMs > 0 && dur > 0) {
            val d = abs(song.durationMs / 1000.0 - dur)
            s += when {
                d <= 2 -> 30.0
                d <= 5 -> 15.0
                d <= 10 -> 0.0
                else -> -25.0
            }
        }
        return s
    }

    private fun searchUrls(song: Song, artistKnown: Boolean): List<String> {
        val a = if (artistKnown) song.artist else ""
        val ct = stripDecor(song.title)
        val ca = stripDecor(a)
        val urls = LinkedHashSet<String>()
        urls.add("$BASE/search?track_name=${enc(song.title)}" + if (a.isNotEmpty()) "&artist_name=${enc(a)}" else "")
        urls.add("$BASE/search?track_name=${enc(ct)}" + if (ca.isNotEmpty()) "&artist_name=${enc(ca)}" else "")
        urls.add("$BASE/search?q=${enc((ct + " " + ca).trim())}")
        return urls.toList()
    }

    private val BRACKETS = Regex("""\s*[(\[].*?[)\]]""")
    private val FEAT = Regex("""\s+(feat|ft)\.?\s.*$""", RegexOption.IGNORE_CASE)
    private val SUFFIX = Regex("""\s+-\s+(remaster|live|mono|stereo|radio|single|version|bonus).*$""", RegexOption.IGNORE_CASE)
    private val NON_WORD = Regex("""[^\p{L}\p{N}]+""")

    private fun stripDecor(s: String): String =
        s.replace(BRACKETS, "").replace(FEAT, "").replace(SUFFIX, "").trim()

    private fun clean(s: String): String =
        stripDecor(s).lowercase().replace(NON_WORD, " ").trim()

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    /** Returns null on 404, throws IOException for network / server errors. */
    private fun httpGet(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 10000
            c.setRequestProperty("User-Agent", "GlassMusic/1.0 (personal Android music player)")
            val code = c.responseCode
            if (code == 404) return null
            if (code !in 200..299) throw IOException("HTTP $code")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Best effort: Android 11+ usually blocks reading .lrc files, so this only helps on some devices. */
    private fun readSidecar(song: Song): String? {
        if (song.path.isEmpty()) return null
        return try {
            val base = song.path.substringBeforeLast('.')
            listOf(".lrc", ".LRC").map { File(base + it) }.firstOrNull { it.isFile && it.canRead() }?.readText()
        } catch (e: Exception) {
            null
        }
    }
}
