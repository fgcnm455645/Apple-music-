package com.glassmusic

/** One lyric line. [timeMs] is the start time; blank [text] means an instrumental gap (shown as dots). */
data class LyricLine(val timeMs: Long, val text: String)

class Lyrics(val lines: List<LyricLine>, val synced: Boolean)

/** Forgiving LRC parser: multiple timestamps per line, [offset:], metadata tags, word tags and plain text fallback. */
object Lrc {
    private val TIME_TAG = Regex("""\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")
    private val WORD_TAG = Regex("""<\d{1,3}:\d{1,2}(?:[.:]\d{1,3})?>""")
    private val OFFSET_TAG = Regex("""^\[offset:\s*([+-]?\d+)\s*]""", RegexOption.IGNORE_CASE)
    private val SPACES = Regex("""\s+""")

    private fun toMs(m: MatchResult): Long {
        val min = m.groupValues[1].toLong()
        val sec = m.groupValues[2].toLong()
        val frac = m.groupValues[3]
        val ms = if (frac.isEmpty()) 0L else frac.padEnd(3, '0').take(3).toLong()
        return (min * 60 + sec) * 1000 + ms
    }

    fun parse(raw: String): Lyrics? {
        var offset = 0L
        val timed = ArrayList<LyricLine>()
        val plain = ArrayList<String>()
        for (rawLine in raw.lineSequence()) {
            val line = rawLine.trim().trimStart('\uFEFF')
            if (line.isEmpty()) continue
            val off = OFFSET_TAG.find(line)
            if (off != null) {
                offset = off.groupValues[1].toLongOrNull() ?: 0L
                continue
            }
            val times = ArrayList<Long>()
            var pos = 0
            while (true) {
                val m = TIME_TAG.find(line, pos) ?: break
                if (m.range.first != pos) break
                times.add(toMs(m))
                pos = m.range.last + 1
            }
            if (times.isEmpty()) {
                // [ar:..] [ti:..] style tags are ignored; everything else counts as plain text
                if (!line.startsWith("[")) plain.add(line)
                continue
            }
            val text = SPACES.replace(WORD_TAG.replace(line.substring(pos), ""), " ").trim()
            for (t in times) timed.add(LyricLine((t - offset).coerceAtLeast(0L), text))
        }

        if (timed.isEmpty()) {
            if (plain.isEmpty()) return null
            return Lyrics(plain.map { LyricLine(-1L, it) }, false)
        }

        val sorted = timed.sortedBy { it.timeMs }
        val out = ArrayList<LyricLine>()
        for (ln in sorted) {
            if (ln.text.isEmpty() && out.lastOrNull()?.text?.isEmpty() == true) continue
            out.add(ln)
        }
        while (out.isNotEmpty() && out.last().text.isEmpty()) out.removeAt(out.size - 1)
        if (out.isEmpty()) return null
        // long intro -> dots
        if (out.first().text.isNotEmpty() && out.first().timeMs >= 5000) out.add(0, LyricLine(0L, ""))
        // long gaps between two sung lines -> dots
        val fin = ArrayList<LyricLine>()
        for (i in out.indices) {
            val ln = out[i]
            fin.add(ln)
            if (ln.text.isNotEmpty() && i + 1 < out.size && out[i + 1].text.isNotEmpty()) {
                val est = (ln.text.length * 90L).coerceIn(1500L, 7000L)
                val at = ln.timeMs + est + 700
                if (out[i + 1].timeMs - at >= 5000) fin.add(LyricLine(at, ""))
            }
        }
        return Lyrics(fin, true)
    }
}
