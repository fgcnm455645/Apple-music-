package com.glassmusic

import android.graphics.Typeface
import android.text.TextUtils
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView

class HomePage(private val act: MainActivity) {
    private val rv = RecyclerView(act)
    private val adapter = HomeAdapter(act)
    val view: View get() = rv

    init {
        val lm = GridLayoutManager(act, 2)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int = adapter.spanAt(position)
        }
        rv.layoutManager = lm
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.overScrollMode = View.OVER_SCROLL_NEVER
        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                act.onListScrolled(0, dy, recyclerView.computeVerticalScrollOffset())
            }
        })

        // long press a tile and drag it to a new place; the order is remembered per mode
        val drag = ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
        ItemTouchHelper(object : ItemTouchHelper.Callback() {
            override fun getMovementFlags(recyclerView: RecyclerView, vh: RecyclerView.ViewHolder): Int =
                if (adapter.canDrag(vh.bindingAdapterPosition)) makeMovementFlags(drag, 0) else 0

            override fun onMove(
                recyclerView: RecyclerView,
                vh: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean = adapter.move(vh.bindingAdapterPosition, target.bindingAdapterPosition)

            override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {}

            override fun isLongPressDragEnabled(): Boolean = true

            override fun onSelectedChanged(vh: RecyclerView.ViewHolder?, actionState: Int) {
                super.onSelectedChanged(vh, actionState)
                if (actionState == ItemTouchHelper.ACTION_STATE_DRAG && vh != null) {
                    vh.itemView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    vh.itemView.animate().scaleX(1.07f).scaleY(1.07f).setDuration(160).start()
                }
            }

            override fun clearView(recyclerView: RecyclerView, vh: RecyclerView.ViewHolder) {
                super.clearView(recyclerView, vh)
                vh.itemView.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
                adapter.persistOrder()
            }
        }).attachToRecyclerView(rv)
    }

    /** Folders (or albums) shown on Home: chosen hidden folders are removed here only. */
    fun refresh() {
        val hidden = Prefs.hiddenFolders
        val mode = Prefs.homeMode
        val tiles: List<Folder> = if (mode == 1) {
            MusicRepository.albumsExcluding(hidden)
        } else {
            MusicRepository.folders.filter { !hidden.contains(it.path) }
        }
        // saved order first; anything new keeps its default place at the end
        val saved = Prefs.homeOrder(mode)
        val index = HashMap<String, Int>()
        saved.forEachIndexed { i, k -> index[k] = i }
        val ordered = tiles.sortedBy { index[it.path] ?: Int.MAX_VALUE }

        val list = ArrayList<Folder>()
        val favSongs = Prefs.favorites.mapNotNull { MusicRepository.byId[it] }
        if (favSongs.isNotEmpty()) list.add(Folder("fav://", "Favorites", favSongs))
        list.addAll(ordered)
        adapter.setData(list, mode)
    }

    fun retint() {
        adapter.notifyDataSetChanged()
    }

    fun offset(): Int = rv.computeVerticalScrollOffset()

    fun applyInsets() {
        rv.setPadding(act.dp(12), act.topInset, act.dp(12), act.contentBottomPad())
    }
}

private sealed class Row {
    object Title : Row()
    class Section(val text: String) : Row()
    class FolderRow(val folder: Folder) : Row()
}

private class SimpleVH(view: View) : RecyclerView.ViewHolder(view)

private class FolderVH(
    view: View,
    val cover: SquareImageView,
    val name: TextView,
    val count: TextView
) : RecyclerView.ViewHolder(view)

class HomeAdapter(private val act: MainActivity) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private var rows: MutableList<Row> = ArrayList()
    private var mode = 0

    fun setData(folders: List<Folder>, mode: Int) {
        this.mode = mode
        val r = ArrayList<Row>()
        r.add(Row.Title)
        if (folders.isNotEmpty()) {
            r.add(Row.Section(if (mode == 1) "Albums" else "Folders"))
            folders.forEach { r.add(Row.FolderRow(it)) }
        }
        rows = r
        notifyDataSetChanged()
    }

    fun spanAt(position: Int): Int = if (rows.getOrNull(position) is Row.FolderRow) 1 else 2

    /** Favorites stays first; every other tile can be dragged. */
    fun canDrag(position: Int): Boolean {
        val row = rows.getOrNull(position) as? Row.FolderRow ?: return false
        return row.folder.path != "fav://"
    }

    fun move(from: Int, to: Int): Boolean {
        if (!canDrag(from) || !canDrag(to)) return false
        val item = rows.removeAt(from)
        rows.add(to, item)
        notifyItemMoved(from, to)
        return true
    }

    fun persistOrder() {
        val keys = rows.filterIsInstance<Row.FolderRow>()
            .map { it.folder.path }
            .filter { it != "fav://" }
        Prefs.setHomeOrder(mode, keys)
    }

    override fun getItemCount() = rows.size

    override fun getItemViewType(position: Int): Int = when (rows[position]) {
        is Row.Title -> 0
        is Row.Section -> 1
        is Row.FolderRow -> 2
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val ctx = parent.context
        when (viewType) {
            0 -> {
                val tv = TextView(ctx).apply {
                    text = "Listen Now"
                    tsz(40f)
                    typeface = Typeface.DEFAULT_BOLD
                    setPadding(act.dp(8), act.dp(84), act.dp(8), act.dp(6))
                    layoutParams = RecyclerView.LayoutParams(-1, -2)
                }
                return SimpleVH(tv)
            }
            1 -> {
                val tv = TextView(ctx).apply {
                    tsz(22f)
                    typeface = Typeface.DEFAULT_BOLD
                    setPadding(act.dp(8), act.dp(22), act.dp(8), act.dp(10))
                    layoutParams = RecyclerView.LayoutParams(-1, -2)
                }
                return SimpleVH(tv)
            }
            else -> {
                val cover = SquareImageView(ctx).apply { round(act.dp(20).toFloat()) }
                val name = TextView(ctx).apply {
                    tsz(16f)
                    typeface = Typeface.DEFAULT_BOLD
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                }
                val count = TextView(ctx).apply {
                    tsz(13f)
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                }
                val tile = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = RecyclerView.LayoutParams(-1, -2).apply {
                        setMargins(act.dp(8), 0, act.dp(8), act.dp(16))
                    }
                    addView(cover, LinearLayout.LayoutParams(-1, -2))
                    addView(name, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(8) })
                    addView(count, LinearLayout.LayoutParams(-1, -2))
                }
                return FolderVH(tile, cover, name, count)
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val row = rows[position]
        when {
            row is Row.Title && holder is SimpleVH -> (holder.itemView as TextView).setTextColor(act.fg1())
            row is Row.Section && holder is SimpleVH -> {
                val tv = holder.itemView as TextView
                tv.text = row.text
                tv.setTextColor(act.fg1())
            }
            row is Row.FolderRow && holder is FolderVH -> {
                val folder = row.folder
                holder.name.text = folder.name
                holder.name.setTextColor(act.fg1())
                val n = folder.songs.size
                if (mode == 1 && folder.path != "fav://") {
                    val artists = folder.songs.map { it.artist }.distinct()
                    holder.count.text = if (artists.size == 1) artists[0] else "Various Artists"
                } else {
                    holder.count.text = if (n == 1) "1 song" else "$n songs"
                }
                holder.count.setTextColor(act.fg2())
                CoverLoader.load(act, folder.songs.firstOrNull(), act.dp(180), holder.cover)
                holder.itemView.setOnClickListener { act.openFolder(folder) }
            }
        }
    }
}
