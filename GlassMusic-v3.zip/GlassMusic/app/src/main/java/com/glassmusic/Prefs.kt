package com.glassmusic

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(context: Context) {
        if (!::sp.isInitialized) {
            sp = context.applicationContext.getSharedPreferences("glassmusic", Context.MODE_PRIVATE)
        }
    }

    var dynamicTheme: Boolean
        get() = sp.getBoolean("dynamic", true)
        set(v) { sp.edit().putBoolean("dynamic", v).apply() }

    var darkMode: Boolean
        get() = sp.getBoolean("dark", false)
        set(v) { sp.edit().putBoolean("dark", v).apply() }

    var useSystemTheme: Boolean
        get() = sp.getBoolean("system", false)
        set(v) { sp.edit().putBoolean("system", v).apply() }

    var liquidGlass: Boolean
        get() = sp.getBoolean("glass", true)
        set(v) { sp.edit().putBoolean("glass", v).apply() }

    var hideStatusBar: Boolean
        get() = sp.getBoolean("hidebar", false)
        set(v) { sp.edit().putBoolean("hidebar", v).apply() }

    var sortMode: Int
        get() = sp.getInt("sort", 0)
        set(v) { sp.edit().putInt("sort", v).apply() }

    var recents: List<Long>
        get() = (sp.getString("recents", "") ?: "").split(',').mapNotNull { it.toLongOrNull() }
        set(v) { sp.edit().putString("recents", v.joinToString(",")).apply() }

    var playerBg: Int
        get() = sp.getInt("playerbg", 0)
        set(v) { sp.edit().putInt("playerbg", v).apply() }

    /** 0 = folders, 1 = albums on the Home tab. */
    var homeMode: Int
        get() = sp.getInt("homemode", 0)
        set(v) { sp.edit().putInt("homemode", v).apply() }

    fun homeOrder(mode: Int): List<String> =
        (sp.getString("homeorder_$mode", "") ?: "").split('\n').filter { it.isNotEmpty() }

    fun setHomeOrder(mode: Int, keys: List<String>) {
        sp.edit().putString("homeorder_$mode", keys.joinToString("\n")).apply()
    }

    var collapseBars: Boolean
        get() = sp.getBoolean("collapse", true)
        set(v) { sp.edit().putBoolean("collapse", v).apply() }

    var hiddenFolders: Set<String>
        get() = (sp.getString("hidden", "") ?: "").split('\n').filter { it.isNotEmpty() }.toSet()
        set(v) { sp.edit().putString("hidden", v.joinToString("\n")).apply() }

    var favorites: Set<Long>
        get() = (sp.getString("favs", "") ?: "").split(',').mapNotNull { it.toLongOrNull() }.toSet()
        set(v) { sp.edit().putString("favs", v.joinToString(",")).apply() }

    fun toggleFavorite(id: Long): Boolean {
        val f = favorites.toMutableSet()
        val added = if (f.contains(id)) { f.remove(id); false } else { f.add(id); true }
        favorites = f
        return added
    }

    /** Per-song lyrics delay in ms (positive = lyrics appear later). */
    fun lyricOffset(id: Long): Int = sp.getInt("lofs_$id", 0)

    fun setLyricOffset(id: Long, ms: Int) {
        sp.edit().apply { if (ms == 0) remove("lofs_$id") else putInt("lofs_$id", ms) }.apply()
    }

    fun addRecent(id: Long) {
        val list = recents.toMutableList()
        list.remove(id)
        list.add(0, id)
        recents = list.take(12)
    }
}
