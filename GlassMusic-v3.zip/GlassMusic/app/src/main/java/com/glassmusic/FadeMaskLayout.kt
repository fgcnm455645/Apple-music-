package com.glassmusic

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.widget.FrameLayout

/** Layout whose content fades from transparent (top) to opaque (bottom). */
class FadeMaskLayout(context: Context) : FrameLayout(context) {
    var fadeStart = 0.45f
    var fadeEnd = 0.80f
    /** false: transparent at the top, opaque at the bottom. true: the opposite. */
    var invert = false
    private val paint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }

    override fun dispatchDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val sc = canvas.saveLayer(0f, 0f, w, h, null)
        super.dispatchDraw(canvas)
        paint.shader = LinearGradient(
            0f, h * fadeStart, 0f, h * fadeEnd,
            if (invert) 0xFF000000.toInt() else 0x00000000, if (invert) 0x00000000 else 0xFF000000.toInt(), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        canvas.restoreToCount(sc)
    }
}
