package com.glassmusic

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewTreeObserver
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

interface InsetsAware {
    fun applyInsets()
    fun retint() {}
    fun onRemoved() {}
}

private fun circleBackground(color: Int) = GradientDrawable().apply {
    shape = GradientDrawable.OVAL
    setColor(color)
}

/** Plain song list pushed on top of the tabs: search results or the play queue. */
class ListPage(
    private val act: MainActivity,
    titleText: String,
    songs: List<Song>,
    private val search: Boolean,
    onClick: (List<Song>, Int) -> Unit
) : FrameLayout(act), InsetsAware {

    private val bgv = act.newBackground(this)
    private val rv = RecyclerView(act)
    private val adapter = SongAdapter(act, 56)
    private val title = TextView(act)
    private val all = songs
    private var searchField: EditText? = null

    init {
        addView(bgv, LayoutParams(-1, -1))

        val header = LinearLayout(act)
        header.orientation = LinearLayout.VERTICAL
        header.setPadding(act.dp(19), act.dp(4), act.dp(19), act.dp(10))
        if (search) {
            val et = EditText(act)
            et.hint = "Songs, artists, albums"
            et.tsz(17f)
            et.isSingleLine = true
            et.imeOptions = EditorInfo.IME_ACTION_SEARCH
            et.setPadding(act.dp(18), act.dp(12), act.dp(18), act.dp(12))
            et.doAfterTextChanged { filter(it?.toString().orEmpty()) }
            searchField = et
            act.themed(this) {
                et.setTextColor(act.fg1())
                et.setHintTextColor(act.fg2())
                et.background = GradientDrawable().apply {
                    setColor(if (act.onLightBg()) Color.argb(26, 0, 0, 0) else Color.argb(60, 255, 255, 255))
                    cornerRadius = 999f
                }
            }
            header.addView(et, LinearLayout.LayoutParams(-1, -2))
        } else {
            header.addView(View(act), LinearLayout.LayoutParams(-1, act.dp(2)))
        }

        adapter.header = header
        adapter.onSongClick = onClick
        adapter.submit(songs)
        rv.layoutManager = LinearLayoutManager(act)
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.overScrollMode = OVER_SCROLL_NEVER
        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                act.onListScrolled(-1, dy, recyclerView.computeVerticalScrollOffset())
            }
        })
        addView(rv, LayoutParams(-1, -1))

        title.text = titleText
        title.tsz(24f)
        title.typeface = Typeface.DEFAULT_BOLD
        title.gravity = Gravity.CENTER
        act.themed(this) { title.setTextColor(act.fg1()) }
        addView(title, LayoutParams(-1, -2, Gravity.TOP))


        applyInsets()

        if (search) {
            rv.postDelayed({
                searchField?.requestFocus()
                val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(searchField, InputMethodManager.SHOW_IMPLICIT)
            }, 350)
        }
    }

    private fun filter(q: String) {
        val t = q.trim().lowercase()
        adapter.submit(
            if (t.isEmpty()) all
            else all.filter {
                it.title.lowercase().contains(t) ||
                    it.artist.lowercase().contains(t) ||
                    it.album.lowercase().contains(t)
            }
        )
    }

    override fun applyInsets() {
        val top = maxOf(act.topInset + act.dp(10), act.dp(43))
        (title.layoutParams as LayoutParams).topMargin = top + act.dp(16)
        title.requestLayout()
        val bottom = maxOf(act.contentBottomPad(), act.imeInset + act.dp(16))
        rv.setPadding(0, top + act.dp(61 + 8), 0, bottom)
    }

    override fun retint() {
        adapter.notifyDataSetChanged()
    }

    override fun onRemoved() {
        act.dropThemed(this)
    }
}

/** Apple Music style folder page: full-width cover fading into the cover color, then the track list. */
class FolderPage(
    private val act: MainActivity,
    private val folder: Folder
) : FrameLayout(act), InsetsAware {

    private val bgv = CoverBackgroundView(act)
    private val rv = RecyclerView(act)
    private val adapter = SongAdapter(act, 56, true)
    private val cover = ImageView(act)
    private val playText = TextView(act)
    private val playIcon = ImageView(act)

    // invisible placeholders: they keep the room of the two round buttons, which the Compose layer
    // draws as liquid glass on top of them (same look as the back and search buttons)
    private val shufflePh = View(act)
    private val addPh = View(act)
    private val loc = IntArray(2)
    private val preDraw = ViewTreeObserver.OnPreDrawListener {
        report()
        true
    }

    fun shuffleAll() {
        Playback.play(act, folder.songs, 0, true)
    }

    fun addAll() {
        Playback.addToQueue(act, folder.songs)
    }

    private fun report() {
        val ok = shufflePh.isAttachedToWindow && addPh.isAttachedToWindow && shufflePh.width > 0
        if (!ok) {
            act.reportFolderButtons(this, 0f, 0f, 0f, 0f, 0f, false)
            return
        }
        shufflePh.getLocationInWindow(loc)
        val sx = loc[0].toFloat()
        val sy = loc[1].toFloat()
        addPh.getLocationInWindow(loc)
        act.reportFolderButtons(this, sx, sy, loc[0].toFloat(), loc[1].toFloat(), shufflePh.width.toFloat(), true)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        viewTreeObserver.addOnPreDrawListener(preDraw)
    }

    override fun onDetachedFromWindow() {
        viewTreeObserver.removeOnPreDrawListener(preDraw)
        super.onDetachedFromWindow()
    }

    override fun onRemoved() {
        act.reportFolderButtons(this, 0f, 0f, 0f, 0f, 0f, false)
    }

    init {
        val g = act.currentGradient()
        bgv.setColors(g[0], g[1], false)
        bgv.setShade(0x40000000)
        addView(bgv, LayoutParams(-1, -1))

        val screenW = resources.displayMetrics.widthPixels

        // the cover fades out with alpha over the blurred cover behind it, so no edge is visible
        cover.scaleType = ImageView.ScaleType.CENTER_CROP
        val coverFrame = FadeMaskLayout(act)
        coverFrame.invert = true
        coverFrame.fadeStart = 0.40f
        coverFrame.fadeEnd = 1.0f
        coverFrame.addView(cover, FrameLayout.LayoutParams(-1, -1))

        val title = TextView(act)
        title.text = folder.name
        title.tsz(28f)
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.WHITE)
        title.gravity = Gravity.CENTER
        title.maxLines = 2
        title.ellipsize = TextUtils.TruncateAt.END

        val totalMin = (folder.songs.sumOf { it.durationMs } / 60000L).toInt()
        val n = folder.songs.size
        val subtitle = TextView(act)
        subtitle.text = (if (n == 1) "1 song" else "$n songs") + " \u2022 $totalMin min"
        subtitle.tsz(16f)
        subtitle.setTextColor(Color.argb(200, 255, 255, 255))
        subtitle.gravity = Gravity.CENTER

        shufflePh.visibility = View.INVISIBLE
        addPh.visibility = View.INVISIBLE
        val shuffleBtn = shufflePh
        val addBtn = addPh

        playIcon.setImageResource(R.drawable.ic_cu_play)
        playText.text = "Play"
        playText.tsz(19f)
        playText.typeface = Typeface.DEFAULT_BOLD
        val accent = ColorEngine.accent(ColorEngine.DEFAULT)
        playText.setTextColor(accent)
        playIcon.imageTintList = ColorStateList.valueOf(accent)
        val playBtn = LinearLayout(act)
        playBtn.orientation = LinearLayout.HORIZONTAL
        playBtn.gravity = Gravity.CENTER
        playBtn.background = GradientDrawable().apply {
            setColor(Color.argb(238, 255, 255, 255))
            cornerRadius = 999f
        }
        playBtn.addView(playIcon, LinearLayout.LayoutParams(act.dp(20), act.dp(20)))
        playBtn.addView(playText, LinearLayout.LayoutParams(-2, -2).apply { marginStart = act.dp(8) })
        playBtn.setOnClickListener { Playback.play(act, folder.songs, 0) }

        val buttons = LinearLayout(act)
        buttons.orientation = LinearLayout.HORIZONTAL
        buttons.gravity = Gravity.CENTER_VERTICAL
        buttons.addView(shuffleBtn, LinearLayout.LayoutParams(act.dp(62), act.dp(62)))
        buttons.addView(playBtn, LinearLayout.LayoutParams(0, act.dp(62), 1f).apply {
            marginStart = act.dp(12)
            marginEnd = act.dp(12)
        })
        buttons.addView(addBtn, LinearLayout.LayoutParams(act.dp(62), act.dp(62)))

        val info = LinearLayout(act)
        info.orientation = LinearLayout.VERTICAL
        info.gravity = Gravity.CENTER_HORIZONTAL
        info.setPadding(act.dp(19), 0, act.dp(19), act.dp(14))
        info.addView(title, LinearLayout.LayoutParams(-1, -2))
        info.addView(subtitle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(2) })
        info.addView(buttons, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(18) })

        val header = LinearLayout(act)
        header.orientation = LinearLayout.VERTICAL
        header.addView(coverFrame, LinearLayout.LayoutParams(screenW, screenW))
        header.addView(info, LinearLayout.LayoutParams(-1, -2).apply { topMargin = -act.dp(70) })

        val first = folder.songs.firstOrNull()
        CoverLoader.load(act, first, 1024, cover)
        if (first != null) {
            CoverLoader.color(act, first) { c ->
                if (c != null) {
                    val gg = ColorEngine.gradient(c, act.isDark())
                    bgv.setColors(gg[0], gg[1], true)
                    val a = ColorEngine.accent(c)
                    playText.setTextColor(a)
                    playIcon.imageTintList = ColorStateList.valueOf(a)
                }
            }
            CoverLoader.blurred(act, first) { b -> bgv.setCover(b, true) }
        }

        adapter.header = header
        adapter.onSongClick = { list, i -> Playback.play(act, list, i) }
        adapter.submit(folder.songs)
        rv.layoutManager = LinearLayoutManager(act)
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.overScrollMode = OVER_SCROLL_NEVER
        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                act.onListScrolled(-1, dy, recyclerView.computeVerticalScrollOffset())
            }
        })
        addView(rv, LayoutParams(-1, -1))


        applyInsets()
    }

    override fun applyInsets() {
        val top = maxOf(act.topInset + act.dp(10), act.dp(43))
        rv.setPadding(0, 0, 0, act.contentBottomPad())
    }
}
