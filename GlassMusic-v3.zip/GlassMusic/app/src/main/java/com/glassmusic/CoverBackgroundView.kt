package com.glassmusic

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.TransitionDrawable
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView

/** Gradient background with an optional smooth blurred cover on top (cross-fades between songs). */
class CoverBackgroundView(context: Context) : FrameLayout(context) {
    private val grad = GradientBackgroundView(context)
    private val img = ImageView(context)
    private val shade = View(context)
    private var shownBitmap: Bitmap? = null

    init {
        addView(grad, LayoutParams(-1, -1))
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.alpha = 0f
        val cm = ColorMatrix()
        cm.setSaturation(1.35f)
        img.colorFilter = ColorMatrixColorFilter(cm)
        addView(img, LayoutParams(-1, -1))
        addView(shade, LayoutParams(-1, -1))
    }

    fun setColors(top: Int, bottom: Int, animate: Boolean) {
        grad.setColors(top, bottom, animate)
    }

    /** [blurred] is an already blurred small bitmap, or null to show only the gradient. */
    fun setCover(blurred: Bitmap?, animate: Boolean) {
        if (blurred === shownBitmap) return
        shownBitmap = blurred
        if (blurred == null) {
            img.animate().cancel()
            if (animate) img.animate().alpha(0f).setDuration(500).start() else img.alpha = 0f
            return
        }
        val newDrawable: Drawable = BitmapDrawable(resources, blurred)
        val old = img.drawable
        if (animate && old != null && img.alpha > 0f) {
            val td = TransitionDrawable(arrayOf(old, newDrawable))
            td.isCrossFadeEnabled = true
            img.setImageDrawable(td)
            td.startTransition(600)
        } else {
            img.setImageDrawable(newDrawable)
        }
        img.animate().cancel()
        if (animate) img.animate().alpha(1f).setDuration(500).start() else img.alpha = 1f
    }

    fun setShade(color: Int) {
        shade.setBackgroundColor(color)
    }
}
