package com.glassmusic

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.util.Size
import android.widget.ImageView
import androidx.palette.graphics.Palette
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/** Loads song covers (embedded art first) with a memory cache, plus dominant colors. */
object CoverLoader {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val colors = ConcurrentHashMap<Long, Int>()
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun load(context: Context, song: Song?, px: Int, view: ImageView) {
        if (song == null) {
            view.tag = null
            view.setImageResource(R.drawable.cover_placeholder)
            return
        }
        val key = "${song.id}@$px"
        view.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            view.setImageBitmap(hit)
            return
        }
        view.setImageResource(R.drawable.cover_placeholder)
        val app = context.applicationContext
        pool.execute {
            val bmp = fetch(app, song, px)
            if (bmp != null) cache.put(key, bmp)
            main.post {
                if (view.tag == key && bmp != null) view.setImageBitmap(bmp)
            }
        }
    }

    fun bitmap(context: Context, song: Song, px: Int, callback: (Bitmap?) -> Unit) {
        val key = "${song.id}@$px"
        val hit = cache.get(key)
        if (hit != null) {
            callback(hit)
            return
        }
        val app = context.applicationContext
        pool.execute {
            val bmp = fetch(app, song, px)
            if (bmp != null) cache.put(key, bmp)
            main.post { callback(bmp) }
        }
    }

    private val blurCache = ConcurrentHashMap<Long, Bitmap>()

    /** Smooth blurred version of the cover, small in size (meant to be scaled up as a background). */
    fun blurred(context: Context, song: Song, callback: (Bitmap?) -> Unit) {
        val known = blurCache[song.id]
        if (known != null) {
            callback(known)
            return
        }
        val app = context.applicationContext
        pool.execute {
            val src = fetch(app, song, 160)
            var out: Bitmap? = null
            if (src != null) {
                try {
                    out = Blur.blur(src, 96, 9)
                    blurCache[song.id] = out
                } catch (e: Exception) {
                    out = null
                }
            }
            main.post { callback(out) }
        }
    }

    fun color(context: Context, song: Song, callback: (Int?) -> Unit) {
        val known = colors[song.id]
        if (known != null) {
            callback(known)
            return
        }
        val app = context.applicationContext
        pool.execute {
            val key = "${song.id}@128"
            var bmp = cache.get(key)
            if (bmp == null) {
                bmp = fetch(app, song, 128)
                if (bmp != null) cache.put(key, bmp)
            }
            var c: Int? = null
            if (bmp != null) {
                c = Palette.from(bmp).maximumColorCount(16).generate().dominantSwatch?.rgb
                if (c != null) colors[song.id] = c
            }
            main.post { callback(c) }
        }
    }

    private fun fetch(context: Context, song: Song, px: Int): Bitmap? {
        try {
            return context.contentResolver.loadThumbnail(song.uri, Size(px, px), null)
        } catch (e: Exception) {
        }
        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(context, song.uri)
            val data = mmr.embeddedPicture ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= px) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            return BitmapFactory.decodeByteArray(data, 0, data.size, opts)
        } catch (e: Exception) {
            return null
        } finally {
            try {
                mmr.release()
            } catch (e: Exception) {
            }
        }
    }
}
