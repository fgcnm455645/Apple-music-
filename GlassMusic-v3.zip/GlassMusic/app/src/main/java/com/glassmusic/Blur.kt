package com.glassmusic

import android.graphics.Bitmap

/** Small CPU blur: scale down, then run a few separable box blurs (approximates a Gaussian). */
object Blur {
    fun blur(src: Bitmap, size: Int, radius: Int, passes: Int = 3): Bitmap {
        val small = Bitmap.createScaledBitmap(src, size, size, true)
        val w = small.width
        val h = small.height
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        repeat(passes) {
            boxH(px, w, h, radius)
            boxV(px, w, h, radius)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    private fun boxH(px: IntArray, w: Int, h: Int, r: Int) {
        val row = IntArray(w)
        val div = 2 * r + 1
        for (y in 0 until h) {
            System.arraycopy(px, y * w, row, 0, w)
            var sa = 0; var sr = 0; var sg = 0; var sb = 0
            for (i in -r..r) {
                val c = row[i.coerceIn(0, w - 1)]
                sa += c ushr 24; sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
            }
            for (x in 0 until w) {
                px[y * w + x] = ((sa / div) shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = row[(x + r + 1).coerceAtMost(w - 1)]
                val sub = row[(x - r).coerceAtLeast(0)]
                sa += (add ushr 24) - (sub ushr 24)
                sr += ((add shr 16) and 255) - ((sub shr 16) and 255)
                sg += ((add shr 8) and 255) - ((sub shr 8) and 255)
                sb += (add and 255) - (sub and 255)
            }
        }
    }

    private fun boxV(px: IntArray, w: Int, h: Int, r: Int) {
        val col = IntArray(h)
        val div = 2 * r + 1
        for (x in 0 until w) {
            for (y in 0 until h) col[y] = px[y * w + x]
            var sa = 0; var sr = 0; var sg = 0; var sb = 0
            for (i in -r..r) {
                val c = col[i.coerceIn(0, h - 1)]
                sa += c ushr 24; sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
            }
            for (y in 0 until h) {
                px[y * w + x] = ((sa / div) shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = col[(y + r + 1).coerceAtMost(h - 1)]
                val sub = col[(y - r).coerceAtLeast(0)]
                sa += (add ushr 24) - (sub ushr 24)
                sr += ((add shr 16) and 255) - ((sub shr 16) and 255)
                sg += ((add shr 8) and 255) - ((sub shr 8) and 255)
                sb += (add and 255) - (sub and 255)
            }
        }
    }
}
