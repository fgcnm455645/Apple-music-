package com.glassmusic

import android.net.Uri

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val folderPath: String,
    val dateAdded: Long,
    val durationMs: Long,
    val uri: Uri,
    val path: String = "",
    val trackNo: Int = 0
) {
    val folderName: String
        get() = folderPath.substringAfterLast('/').ifEmpty { "Unknown" }
}

data class Folder(val path: String, val name: String, val songs: List<Song>)
