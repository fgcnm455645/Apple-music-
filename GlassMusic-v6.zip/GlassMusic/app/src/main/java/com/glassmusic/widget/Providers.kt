package com.glassmusic.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.media3.common.Player
import com.glassmusic.Playback
import java.util.concurrent.atomic.AtomicBoolean

/** All widgets: refresh + play/pause/next/previous through the app's own player. */
open class BaseWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetRenderer.updateAll(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        WidgetRenderer.updateAll(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action ?: return
        if (action != ACTION_TOGGLE && action != ACTION_NEXT && action != ACTION_PREV) return

        val pending: BroadcastReceiver.PendingResult = goAsync()
        val finished = AtomicBoolean(false)
        val finish: () -> Unit = {
            if (finished.compareAndSet(false, true)) {
                try {
                    pending.finish()
                } catch (e: Exception) {
                }
            }
        }
        Handler(Looper.getMainLooper()).postDelayed({ finish() }, 8000)

        Playback.whenReady(context) { c ->
            try {
                when (action) {
                    ACTION_TOGGLE -> if (c.isPlaying) {
                        c.pause()
                    } else {
                        if (c.mediaItemCount > 0 && c.playbackState == Player.STATE_IDLE) c.prepare()
                        c.play()
                    }
                    ACTION_NEXT -> c.seekToNext()
                    ACTION_PREV -> c.seekToPrevious()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                finish()
            }
        }
    }

    companion object {
        const val ACTION_TOGGLE = "com.glassmusic.widget.ACTION_TOGGLE"
        const val ACTION_NEXT = "com.glassmusic.widget.ACTION_NEXT"
        const val ACTION_PREV = "com.glassmusic.widget.ACTION_PREV"
    }
}

class Widget2x2Provider : BaseWidgetProvider()

class Widget2x2MiniProvider : BaseWidgetProvider()

class Widget2x1Provider : BaseWidgetProvider()

class Widget4x2Provider : BaseWidgetProvider()
