package com.glassmusic.widget

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.Size
import androidx.media3.common.C
import androidx.media3.common.Player
import com.glassmusic.MainActivity
import java.io.File
import java.util.concurrent.Executors

/** What the widgets show about the current song. */
data class MediaInfo(
    val hasMedia: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val art: Bitmap? = null,
    val playing: Boolean = false,
    val openIntent: PendingIntent? = null,
    val album: String = "",
    val durationMs: Long = 0L,
    val positionMs: Long = 0L,
    val readAt: Long = 0L
) {
    /** Changes with every song (used for the blur / color caches). */
    val key: String
        get() {
            val a = art
            val sample = if (a != null) a.getPixel(a.width / 3, a.height / 3) else 0
            return "$title|$artist|${a?.width}x${a?.height}|$sample"
        }
}

class PlaybackSnap(val playing: Boolean, val positionMs: Long, val durationMs: Long)

/**
 * Connects the widgets to the app's own player: the playback service pushes every change here,
 * the widgets read it (no notification access needed). The last song is also saved to disk so the
 * widgets still show it after the app process has been killed.
 */
object WidgetBridge {
    private class Snap(
        val id: String,
        val title: String,
        val artist: String,
        val album: String,
        val durationMs: Long,
        val positionMs: Long,
        val playing: Boolean,
        val at: Long
    )

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    @Volatile private var snap: Snap? = null
    @Volatile private var art: Bitmap? = null
    @Volatile private var artId: String? = null
    @Volatile private var savedLoaded = false
    private var ticking = false
    private var appCtx: Context? = null

    private const val PREFS = "widget_state"
    private const val ART_FILE = "widget_art.png"

    private val tick = object : Runnable {
        override fun run() {
            val s = snap
            val ctx = appCtx
            if (s != null && s.playing && ctx != null) {
                val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
                if (pm.isInteractive) WidgetRenderer.tickProgress(ctx)
                main.postDelayed(this, 4000)
            } else {
                ticking = false
            }
        }
    }

    /** Called by the playback service once the player exists. */
    fun attach(service: Context, player: Player) {
        val app = service.applicationContext
        appCtx = app
        player.addListener(object : Player.Listener {
            override fun onEvents(p: Player, events: Player.Events) {
                if (events.containsAny(
                        Player.EVENT_MEDIA_ITEM_TRANSITION,
                        Player.EVENT_MEDIA_METADATA_CHANGED,
                        Player.EVENT_IS_PLAYING_CHANGED,
                        Player.EVENT_PLAYBACK_STATE_CHANGED,
                        Player.EVENT_PLAY_WHEN_READY_CHANGED,
                        Player.EVENT_POSITION_DISCONTINUITY,
                        Player.EVENT_TIMELINE_CHANGED
                    )
                ) publish(app, p)
            }
        })
        publish(app, player)
    }

    private fun publish(app: Context, p: Player) {
        val item = p.currentMediaItem
        val md = p.mediaMetadata
        val id = item?.mediaId.orEmpty()
        val uri = item?.localConfiguration?.uri
        val dur = p.duration.let { if (it == C.TIME_UNSET || it < 0L) 0L else it }
        val s = Snap(
            id = id,
            title = md.title?.toString().orEmpty(),
            artist = (md.artist ?: md.albumArtist)?.toString().orEmpty(),
            album = md.albumTitle?.toString().orEmpty(),
            durationMs = dur,
            positionMs = p.currentPosition.coerceAtLeast(0L),
            playing = p.isPlaying,
            at = SystemClock.elapsedRealtime()
        )
        snap = s
        if (s.playing && !ticking) {
            ticking = true
            main.postDelayed(tick, 4000)
        }
        io.execute {
            try {
                if (id.isEmpty()) {
                    art = null
                    artId = null
                } else if (id != artId) {
                    art = loadArt(app, uri)
                    artId = id
                    saveArt(app, art)
                }
                persist(app, s)
                WidgetRenderer.updateAll(app)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /** Called from the widget renderer thread. */
    fun read(ctx: Context): MediaInfo {
        val open = PendingIntent.getActivity(
            ctx, 2,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        var s = snap
        if (s == null) {
            s = loadSaved(ctx)
            if (s == null) return MediaInfo(openIntent = open)
        }
        val has = s.id.isNotEmpty() || s.title.isNotEmpty()
        if (!has) return MediaInfo(openIntent = open)
        return MediaInfo(
            hasMedia = true,
            title = s.title,
            artist = s.artist,
            art = art,
            playing = s.playing,
            openIntent = open,
            album = s.album,
            durationMs = s.durationMs,
            positionMs = s.positionMs,
            readAt = s.at
        )
    }

    /** Light read for the progress ticker. */
    fun playback(): PlaybackSnap? {
        val s = snap ?: return null
        var pos = s.positionMs
        if (s.playing) pos += SystemClock.elapsedRealtime() - s.at
        if (s.durationMs > 0L && pos > s.durationMs) pos = s.durationMs
        return PlaybackSnap(s.playing, pos, s.durationMs)
    }

    // ---------------------------------------------------------------- saved state

    private fun persist(ctx: Context, s: Snap) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("id", s.id)
            .putString("title", s.title)
            .putString("artist", s.artist)
            .putString("album", s.album)
            .putLong("dur", s.durationMs)
            .putLong("pos", s.positionMs)
            .apply()
    }

    private fun loadSaved(ctx: Context): Snap? {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val id = sp.getString("id", null) ?: return null
        if (!savedLoaded) {
            savedLoaded = true
            if (art == null) {
                val f = File(ctx.filesDir, ART_FILE)
                if (f.exists()) art = BitmapFactory.decodeFile(f.absolutePath)
            }
        }
        return Snap(
            id = id,
            title = sp.getString("title", "").orEmpty(),
            artist = sp.getString("artist", "").orEmpty(),
            album = sp.getString("album", "").orEmpty(),
            durationMs = sp.getLong("dur", 0L),
            positionMs = sp.getLong("pos", 0L),
            playing = false,
            at = SystemClock.elapsedRealtime()
        )
    }

    private fun saveArt(ctx: Context, bmp: Bitmap?) {
        val f = File(ctx.filesDir, ART_FILE)
        try {
            if (bmp == null) {
                f.delete()
            } else {
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadArt(ctx: Context, uri: Uri?): Bitmap? {
        if (uri == null) return null
        val raw: Bitmap? = try {
            ctx.contentResolver.loadThumbnail(uri, Size(512, 512), null)
        } catch (e: Exception) {
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(ctx, uri)
                val data = mmr.embeddedPicture
                if (data != null) BitmapFactory.decodeByteArray(data, 0, data.size) else null
            } catch (e2: Exception) {
                null
            } finally {
                try {
                    mmr.release()
                } catch (e3: Exception) {
                }
            }
        }
        return raw?.copy(Bitmap.Config.ARGB_8888, false)
    }
}
