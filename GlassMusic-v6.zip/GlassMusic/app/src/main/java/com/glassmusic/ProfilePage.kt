package com.glassmusic

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.widget.doAfterTextChanged

/** The profile page: a photo (picked from the gallery) and a name. */
fun openProfilePage(act: MainActivity) {
    act.pushOverlay(SubPage(act, "Profile") { page, col ->
        val size = act.dp(150)

        // ------------------------------------------------ photo
        val avatar = ImageView(act)
        avatar.round(size / 2f)

        fun showPhoto() {
            val bmp = act.profilePhoto()
            if (bmp != null) {
                avatar.setPadding(0, 0, 0, 0)
                avatar.imageTintList = null
                avatar.scaleType = ImageView.ScaleType.CENTER_CROP
                avatar.setImageBitmap(bmp)
            } else {
                val pad = act.dp(42)
                avatar.setPadding(pad, pad, pad, pad)
                avatar.scaleType = ImageView.ScaleType.FIT_CENTER
                avatar.setImageResource(R.drawable.ic_cu_person)
                avatar.imageTintList = ColorStateList.valueOf(act.fg2())
            }
        }
        act.themed(page) {
            avatar.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(act.surface())
            }
            showPhoto()
        }
        act.onProfileChanged = { showPhoto() }
        avatar.setOnClickListener { act.pickProfilePhoto() }

        val avatarBox = FrameLayout(act)
        avatarBox.addView(avatar, FrameLayout.LayoutParams(size, size, Gravity.CENTER_HORIZONTAL))
        col.addView(avatarBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(18) })

        // ------------------------------------------------ name
        val name = EditText(act)
        name.hint = "Your name"
        name.tsz(20f)
        name.gravity = Gravity.CENTER
        name.isSingleLine = true
        name.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        name.setText(Prefs.profileName)
        name.setPadding(act.dp(18), act.dp(14), act.dp(18), act.dp(14))
        name.doAfterTextChanged { Prefs.profileName = it?.toString().orEmpty().trim() }
        act.themed(page) {
            name.setTextColor(act.fg1())
            name.setHintTextColor(act.fg2())
            name.background = GradientDrawable().apply {
                setColor(act.surface())
                cornerRadius = act.dp(15).toFloat()
            }
        }
        col.addView(name, LinearLayout.LayoutParams(-1, -2).apply {
            marginStart = act.dp(19)
            marginEnd = act.dp(19)
            topMargin = act.dp(22)
        })

        // ------------------------------------------------ actions
        val card = settingsCard(act, page)
        card.addView(navRow(act, page, "Choose Photo", "Pick a picture from your gallery") {
            act.pickProfilePhoto()
        })
        card.addView(rowDivider(act, page))
        card.addView(navRow(act, page, "Remove Photo", null) {
            act.removeProfilePhoto()
        })
        col.addView(card)
    })
}
