package com.glassmusic

import android.content.res.ColorStateList
import android.graphics.Typeface
import android.text.TextUtils
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HomePage(private val act: MainActivity) {
    private val rv = RecyclerView(act)
    private val adapter = HomeAdapter(act)
    val view: View get() = rv

    init {
        val lm = GridLayoutManager(act, 2)
        lm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int = adapter.spanAt(position)
        }
        rv.layoutManager = lm
        rv.adapter = adapter
        rv.clipToPadding = false
        rv.overScrollMode = View.OVER_SCROLL_NEVER
        rv.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                act.onListScrolled(0, dy, recyclerView.computeVerticalScrollOffset())
            }
        })
    }

    /** Folders shown on Home: chosen hidden folders are removed here only. */
    fun refresh() {
        val hidden = Prefs.hiddenFolders
        val list = ArrayList<Folder>()
        val favSongs = Prefs.favorites.mapNotNull { MusicRepository.byId[it] }
        if (favSongs.isNotEmpty()) list.add(Folder("fav://", "Favorites", favSongs))
        list.addAll(MusicRepository.folders.filter { !hidden.contains(it.path) })
        adapter.setData(list)
    }

    fun retint() {
        adapter.notifyDataSetChanged()
    }

    fun offset(): Int = rv.computeVerticalScrollOffset()

    fun applyInsets() {
        rv.setPadding(act.dp(12), act.topInset, act.dp(12), act.contentBottomPad())
    }
}

private sealed class Row {
    object Title : Row()
    class Section(val text: String) : Row()
    class FolderRow(val folder: Folder) : Row()
}

private class SimpleVH(view: View) : RecyclerView.ViewHolder(view)

private class FolderVH(
    view: View,
    val cover: SquareImageView,
    val name: TextView,
    val count: TextView
) : RecyclerView.ViewHolder(view)

class HomeAdapter(private val act: MainActivity) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private var rows: List<Row> = emptyList()

    fun setData(folders: List<Folder>) {
        val r = ArrayList<Row>()
        r.add(Row.Title)
        if (folders.isNotEmpty()) {
            r.add(Row.Section("Folders"))
            folders.forEach { r.add(Row.FolderRow(it)) }
        }
        rows = r
        notifyDataSetChanged()
    }

    fun spanAt(position: Int): Int = if (rows.getOrNull(position) is Row.FolderRow) 1 else 2

    override fun getItemCount() = rows.size

    override fun getItemViewType(position: Int): Int = when (rows[position]) {
        is Row.Title -> 0
        is Row.Section -> 1
        is Row.FolderRow -> 2
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val ctx = parent.context
        when (viewType) {
            0 -> {
                val tv = TextView(ctx).apply {
                    text = "Listen Now"
                    tsz(40f)
                    typeface = Typeface.DEFAULT_BOLD
                    setPadding(act.dp(8), act.dp(84), act.dp(8), act.dp(6))
                    layoutParams = RecyclerView.LayoutParams(-1, -2)
                }
                return SimpleVH(tv)
            }
            1 -> {
                val tv = TextView(ctx).apply {
                    tsz(22f)
                    typeface = Typeface.DEFAULT_BOLD
                    setPadding(act.dp(8), act.dp(22), act.dp(8), act.dp(10))
                    layoutParams = RecyclerView.LayoutParams(-1, -2)
                }
                return SimpleVH(tv)
            }
            else -> {
                val cover = SquareImageView(ctx).apply { round(act.dp(20).toFloat()) }
                val name = TextView(ctx).apply {
                    tsz(16f)
                    typeface = Typeface.DEFAULT_BOLD
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                }
                val count = TextView(ctx).apply {
                    tsz(13f)
                    maxLines = 1
                }
                val tile = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = RecyclerView.LayoutParams(-1, -2).apply {
                        setMargins(act.dp(8), 0, act.dp(8), act.dp(16))
                    }
                    addView(cover, LinearLayout.LayoutParams(-1, -2))
                    addView(name, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(8) })
                    addView(count, LinearLayout.LayoutParams(-1, -2))
                }
                return FolderVH(tile, cover, name, count)
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val row = rows[position]
        when {
            row is Row.Title && holder is SimpleVH -> (holder.itemView as TextView).setTextColor(act.fg1())
            row is Row.Section && holder is SimpleVH -> {
                val tv = holder.itemView as TextView
                tv.text = row.text
                tv.setTextColor(act.fg1())
            }
            row is Row.FolderRow && holder is FolderVH -> {
                val folder = row.folder
                holder.name.text = folder.name
                holder.name.setTextColor(act.fg1())
                val n = folder.songs.size
                holder.count.text = if (n == 1) "1 song" else "$n songs"
                holder.count.setTextColor(act.fg2())
                CoverLoader.load(act, folder.songs.firstOrNull(), act.dp(180), holder.cover)
                holder.itemView.setOnClickListener { act.openFolder(folder) }
            }
        }
    }
}
