package com.glassmusic

import android.content.Context
import android.view.View
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.emptyBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.backdrop.catalog.components.LiquidBottomTab
import com.kyant.backdrop.catalog.components.LiquidBottomTabs
import com.kyant.backdrop.catalog.components.LiquidButton
import com.kyant.backdrop.catalog.components.LiquidToggle
import com.kyant.backdrop.catalog.components.LocalIsLensCopy
import com.kyant.shapes.Capsule
import kotlin.math.max
import kotlin.math.roundToInt

/** State read by the Compose glass layer; written by MainActivity. */
class BarsUi {
    var tab by mutableIntStateOf(0)
    var collapsed by mutableStateOf(false)
    var overlayCount by mutableIntStateOf(0)
    var playerOpen by mutableStateOf(false)
    var hasSong by mutableStateOf(false)
    var title by mutableStateOf("")
    var artist by mutableStateOf("")
    var cover by mutableStateOf<ImageBitmap?>(null)
    var isPlaying by mutableStateOf(false)
    var onLight by mutableStateOf(true)
    var fg by mutableIntStateOf(0xFF111114.toInt())
    var topInsetPx by mutableFloatStateOf(0f)
    var bottomInsetPx by mutableFloatStateOf(0f)

    /** true while the search page is open (the glass lens then rests on the search button) */
    var searchOpen by mutableStateOf(false)

    /** the profile photo (null = plain person icon) */
    var profileImage by mutableStateOf<ImageBitmap?>(null)

    /** 0 = player closed (bars visible), 1 = player fully open (bars hidden); animated by PlayerScreen. */
    var playerFrac by mutableFloatStateOf(0f)

    // the two round buttons of a folder page, drawn as glass above the list
    var folderVisible by mutableStateOf(false)
    var folderShuffleX by mutableFloatStateOf(0f)
    var folderShuffleY by mutableFloatStateOf(0f)
    var folderAddX by mutableFloatStateOf(0f)
    var folderAddY by mutableFloatStateOf(0f)
    var folderSize by mutableFloatStateOf(0f)
}

class BarActions(
    val selectTab: (Int) -> Unit,
    val openSearch: () -> Unit,
    val showPlayer: () -> Unit,
    val prev: () -> Unit,
    val playPause: () -> Unit,
    val next: () -> Unit,
    val back: () -> Unit,
    val sort: () -> Unit,
    val profile: () -> Unit,
    val expand: () -> Unit,
    val folderShuffle: () -> Unit,
    val folderAdd: () -> Unit
)

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t

/** Bars fade in once the player is below 70% open, the mini player below 30% (they come back late, like a hand-off). */
private fun barsAlphaOf(frac: Float) = ((0.7f - frac) / 0.7f).coerceIn(0f, 1f)

private fun miniAlphaOf(frac: Float) = ((0.3f - frac) / 0.3f).coerceIn(0f, 1f)

private val tabIcons = intArrayOf(R.drawable.ic_fa_house, R.drawable.ic_cu_albums, R.drawable.ic_cu_gear, R.drawable.ic_cu_search)
private val tabLabels = arrayOf("Home", "Library", "Settings", "Search")
// glyph sizes (design px at 1080 wide) measured from the original app
private val tabGlyphPx = floatArrayOf(91f, 88f, 82f, 70f)

/**
 * Glass layer drawn on top of the View-based app: tab bar, search, mini player and top buttons.
 * Sizes come from 1080px-wide screenshots of the original app and are scaled to the real width.
 */
@Composable
fun GlassOverlay(backdrop: Backdrop, ui: BarsUi, act: BarActions) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val w = constraints.maxWidth.toFloat()
        val s = w / 1080f
        fun dpOf(px: Float): Dp = with(density) { px.toDp() }

        val p by animateFloatAsState(
            if (ui.collapsed) 1f else 0f,
            tween(340, easing = FastOutSlowInEasing),
            label = "bars"
        )
        val fg = Color(ui.fg)
        val container =
            if (ui.onLight) Color(0xFFFAFAFA).copy(0.4f) else Color(0xFF121212).copy(0.4f)

        val side = 50f * s
        val gap = 27f * s
        val barH = 201f * s
        val fab = 202f * s
        val mini = 138f * s
        val circle = 138f * s
        val midGap = 75f * s
        val base = max(ui.bottomInsetPx + 26f * s, 116f * s)
        val top = max(ui.topInsetPx + 26f * s, 113f * s)
        val topBtn = 160f * s

        if (ui.playerFrac < 0.7f) {
            // ---------------------------------------------------- folder page glass buttons
            if (ui.folderVisible) {
                val fs = dpOf(ui.folderSize)
                LiquidButton(
                    onClick = { act.folderShuffle() },
                    backdrop = backdrop,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset { IntOffset(ui.folderShuffleX.roundToInt(), ui.folderShuffleY.roundToInt()) }
                        .size(fs)
                        .graphicsLayer { alpha = barsAlphaOf(ui.playerFrac) },
                    isInteractive = true,
                    surfaceColor = container,
                    height = fs,
                    horizontalPadding = 0.dp
                ) {
                    Image(
                        painterResource(R.drawable.ic_cu_shuffle),
                        null,
                        Modifier.size(dpOf(68f * s)),
                        colorFilter = ColorFilter.tint(fg)
                    )
                }
                LiquidButton(
                    onClick = { act.folderAdd() },
                    backdrop = backdrop,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset { IntOffset(ui.folderAddX.roundToInt(), ui.folderAddY.roundToInt()) }
                        .size(fs)
                        .graphicsLayer { alpha = barsAlphaOf(ui.playerFrac) },
                    isInteractive = true,
                    surfaceColor = container,
                    height = fs,
                    horizontalPadding = 0.dp
                ) {
                    Image(
                        painterResource(R.drawable.ic_cu_plus),
                        null,
                        Modifier.size(dpOf(64f * s)),
                        colorFilter = ColorFilter.tint(fg)
                    )
                }
            }

            // ---------------------------------------------------- mini player
            if (ui.hasSong && ui.playerFrac < 0.3f) {
                val left = side + lerpF(0f, circle + midGap, p)
                val bottom = lerpF(base + barH + 22f * s, base, p)
                MiniPlayer(
                    backdrop, ui, act, container, fg, s,
                    extra = (1f - p * 2f).coerceIn(0f, 1f),
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .offset { IntOffset(left.roundToInt(), -bottom.roundToInt()) }
                        .width(dpOf(w - 2f * left))
                        .height(dpOf(mini))
                        .graphicsLayer { alpha = miniAlphaOf(ui.playerFrac) }
                )
            }

            // ---------------------------------------------------- search (separate circle only while the bar is collapsing / collapsed)
            if (p > 0.02f) {
                val size = lerpF(fab, circle, p)
                val x = w - side - size
                val searchAlpha = if (p >= 0.5f) 1f else p * 2f
                LiquidButton(
                    onClick = { act.openSearch() },
                    backdrop = backdrop,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .offset { IntOffset(x.roundToInt(), -base.roundToInt()) }
                        .size(dpOf(size))
                        .graphicsLayer { alpha = searchAlpha * barsAlphaOf(ui.playerFrac) },
                    isInteractive = true,
                    surfaceColor = container,
                    height = dpOf(size),
                    horizontalPadding = 0.dp
                ) {
                    Image(
                        painterResource(R.drawable.ic_cu_search),
                        null,
                        Modifier.size(dpOf(62f * s)),
                        colorFilter = ColorFilter.tint(fg)
                    )
                }
            }

            // ---------------------------------------------------- one capsule: Home, Library, Settings, Search
            if (p < 0.5f) {
                val fullW = w - 2f * side
                val tabsW = lerpF(fullW, circle, p)
                val tabsH = lerpF(barH, circle, p)
                val a = (1f - p * 2.2f).coerceIn(0f, 1f)
                LiquidBottomTabs(
                    selectedTabIndex = { if (ui.searchOpen) 3 else ui.tab },
                    onTabSelected = { index ->
                        if (index == 3) {
                            if (!ui.searchOpen) act.openSearch()
                        } else if (ui.searchOpen || ui.tab != index) {
                            act.selectTab(index)
                        }
                    },
                    backdrop = backdrop,
                    tabsCount = 4,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .offset { IntOffset(side.roundToInt(), -base.roundToInt()) }
                        .width(dpOf(tabsW))
                        .graphicsLayer { alpha = a * barsAlphaOf(ui.playerFrac) },
                    barHeight = dpOf(tabsH),
                    isLightTheme = ui.onLight,
                    accentColor = fg,
                    containerColor = container
                ) {
                    repeat(4) { index ->
                        LiquidBottomTab({
                            if (index == 3) act.openSearch() else act.selectTab(index)
                        }) {
                            val isLens = LocalIsLensCopy.current
                            val c = if (isLens) fg else fg.copy(alpha = 0.62f)
                            Image(
                                painterResource(tabIcons[index]),
                                null,
                                Modifier.size(dpOf(tabGlyphPx[index] * s)),
                                colorFilter = ColorFilter.tint(c)
                            )
                            BasicText(
                                tabLabels[index],
                                style = TextStyle(
                                    color = c,
                                    fontSize = with(density) { (27f * s).toSp() },
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                }
            }

            // ---------------------------------------------------- collapsed tab circle
            if (p > 0.45f) {
                val a = ((p - 0.5f) * 2f).coerceIn(0f, 1f)
                LiquidButton(
                    onClick = { act.expand() },
                    backdrop = backdrop,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .offset { IntOffset(side.roundToInt(), -base.roundToInt()) }
                        .size(dpOf(circle))
                        .graphicsLayer { alpha = a * barsAlphaOf(ui.playerFrac) },
                    isInteractive = true,
                    surfaceColor = container,
                    height = dpOf(circle),
                    horizontalPadding = 0.dp
                ) {
                    Image(
                        painterResource(tabIcons[ui.tab.coerceIn(0, 2)]),
                        null,
                        Modifier.size(dpOf(tabGlyphPx[ui.tab.coerceIn(0, 2)] * s * 0.82f)),
                        colorFilter = ColorFilter.tint(fg)
                    )
                }
            }

            // ---------------------------------------------------- top buttons
            val topIcon: Int
            val topAction: () -> Unit
            val topAtEnd: Boolean
            var showTop = true
            if (ui.overlayCount > 0) {
                topIcon = R.drawable.ic_io_back
                topAction = act.back
                topAtEnd = false
            } else if (ui.tab == 1) {
                topIcon = R.drawable.ic_cu_filter
                topAction = act.sort
                topAtEnd = true
            } else if (ui.tab == 0) {
                topIcon = R.drawable.ic_cu_person
                topAction = act.profile
                topAtEnd = true
            } else {
                topIcon = R.drawable.ic_cu_person
                topAction = act.profile
                topAtEnd = true
                showTop = false
            }
            if (showTop) {
                val x = if (topAtEnd) w - side - topBtn else side
                LiquidButton(
                    onClick = topAction,
                    backdrop = backdrop,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset { IntOffset(x.roundToInt(), top.roundToInt()) }
                        .size(dpOf(topBtn))
                        .graphicsLayer { alpha = barsAlphaOf(ui.playerFrac) },
                    isInteractive = true,
                    surfaceColor = container,
                    height = dpOf(topBtn),
                    horizontalPadding = 0.dp
                ) {
                    val photo = ui.profileImage
                    if (photo != null && topIcon == R.drawable.ic_cu_person) {
                        Image(
                            photo,
                            null,
                            Modifier
                                .size(dpOf(topBtn - 12f * s))
                                .clip(androidx.compose.foundation.shape.CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Image(
                            painterResource(topIcon),
                            null,
                            Modifier.size(dpOf(68f * s)),
                            colorFilter = ColorFilter.tint(fg)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniPlayer(
    backdrop: Backdrop,
    ui: BarsUi,
    act: BarActions,
    container: Color,
    fg: Color,
    s: Float,
    extra: Float,
    modifier: Modifier
) {
    val density = LocalDensity.current
    fun dpOf(px: Float): Dp = with(density) { px.toDp() }
    Row(
        modifier
            .drawBackdrop(
                backdrop = backdrop,
                shape = { Capsule() },
                effects = {
                    vibrancy()
                    blur(2f.dp.toPx())
                    lens(12f.dp.toPx(), 24f.dp.toPx())
                },
                onDrawSurface = { drawRect(container) }
            )
            .clickable { act.showPlayer() }
            .padding(start = dpOf(53f * s), end = dpOf(86f * s)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val cover = ui.cover
        Box(
            Modifier
                .size(dpOf(86f * s))
                .clip(RoundedCornerShape(dpOf(20f * s)))
                .then(Modifier)
        ) {
            if (cover != null) {
                Image(cover, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
        }
        Column(
            Modifier
                .weight(1f)
                .padding(start = dpOf(22f * s), end = dpOf(8f * s))
        ) {
            BasicText(
                ui.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = TextStyle(
                    color = fg,
                    fontSize = with(density) { (44f * s).toSp() },
                    fontWeight = FontWeight.Medium
                )
            )
            BasicText(
                ui.artist,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = TextStyle(
                    color = fg.copy(alpha = 0.62f),
                    fontSize = with(density) { (38f * s).toSp() }
                )
            )
        }
        if (extra > 0f) {
            Image(
                painterResource(R.drawable.ic_cu_rewind),
                null,
                Modifier
                    .size(dpOf(64f * s))
                    .graphicsLayer { alpha = extra }
                    .clickable { act.prev() },
                colorFilter = ColorFilter.tint(fg)
            )
            Box(Modifier.width(dpOf(80f * s)))
        }
        Image(
            painterResource(if (ui.isPlaying) R.drawable.ic_cu_pause else R.drawable.ic_cu_play),
            null,
            Modifier
                .size(dpOf(56f * s))
                .clickable { act.playPause() },
            colorFilter = ColorFilter.tint(fg)
        )
        if (extra > 0f) {
            Box(Modifier.width(dpOf(80f * s)))
            Image(
                painterResource(R.drawable.ic_cu_forward),
                null,
                Modifier
                    .size(dpOf(64f * s))
                    .graphicsLayer { alpha = extra }
                    .clickable { act.next() },
                colorFilter = ColorFilter.tint(fg)
            )
        }
    }
}

/** A glass toggle (iOS 26 style) to be placed inside a View-based row. */
fun makeGlassToggle(context: Context, initial: Boolean, onChange: (Boolean) -> Unit): View {
    val v = ComposeView(context)
    v.setContent {
        var checked by remember { mutableStateOf(initial) }
        Box(Modifier.size(104.dp, 58.dp), contentAlignment = Alignment.Center) {
            LiquidToggle(
                selected = { checked },
                onSelect = {
                    checked = it
                    onChange(it)
                },
                backdrop = emptyBackdrop()
            )
        }
    }
    return v
}
